function [XNew,fitness,sumVio,newNEval,newConst,has_change]=localSearch(numEval,x0,leftbound,rightbound,S0,k0,index,nEvalEveryPeriod,val1,val2,val3,testFlag,mfr_numPeaks,mfr_numRegions,mp_changeType,mfr_changeType,con_par,rTimes_con,rTimes_len)
s = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(s);
format long;
% RandStream.setDefaultStream(s);
global NConst;
global NEval;
global n_var;
global n_con;
global DELTA;
global DELTA_1;
global lb;
global ub;
global S;
global Problem;
global k;
global flag;
global test;
global Period;
global val_1;
global val_2;
global val_3;
global Flag;
global numPeaks;
global numRegions;
global mpb_changeType;
global mfrb_changeType;
global conHeight;
global times_len;
global times_con;
times_len=rTimes_len;
times_con=rTimes_con;
conHeight=con_par;
numPeaks=mfr_numPeaks;
numRegions=mfr_numRegions;
mpb_changeType=mp_changeType;
mfrb_changeType=mfr_changeType;
Flag=testFlag;
val_1=val1;
val_2=val2;
val_3=val3;
flag=0.;
DELTA=1.0e-12;
DELTA_1=1.0e12;
NConst=0;
S=S0;
k=k0;
Problem=index;
Period=nEvalEveryPeriod;
if (Problem<=8003&&Problem>=3001&&mod(Problem,1000)==3)
    n_con=4;
elseif (Problem<=8003&&Problem>=3001&&mod(Problem,1000)==1)
    n_con=3;
elseif Problem==1||Problem==4||Problem==6||Problem==17
    n_con=0;
elseif Problem==13
    n_con=1;
elseif Problem==101
    n_con=1;
elseif Problem>=10000
    n_con=1;
else
    n_con=2;
end
if Problem<=18||(Problem<=8003&&Problem>=3001)
    n_var=2;
else
    n_var=size(x0,2);
end
if Problem<=18||(Problem<=8003&&Problem>=3001)
    lb=[0,0];
    ub=[3,4];
else
  % for i=1:n_var
    lb=leftbound;
    ub=rightbound;
  %  end
end

NEval=numEval;
test=mod(NEval,Period);

switch Problem
    case {1,4,6,17}
        options=optimset('Algorithm','sqp','GradObj','off','GradConstr','off','Display','off','TolFun',1e-4,'MaxFunEvals',50);
        [X,FVAL,EXITFLAG,OUTPUT]=fmincon(@myFun,x0,[],[],[],[],lb,ub,[],options);
    otherwise       
        if Problem<1000 && Problem>=100
            options=optimset('Algorithm','sqp','GradObj','off','GradConstr','off','TolCon',0.015,'OutputFcn', @outFun,'Display','off');
        else
            options=optimset('Algorithm','sqp','GradObj','off','GradConstr','off','TolCon',0,'OutputFcn', @outFun,'Display','off','TolFun',1e-4,'MaxFunEvals',50);%'MaxFunEvals');
        end
        [X,FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN]=fmincon(@myFun,x0,[],[],[],[],lb,ub,@mycon,options);
end
XNew=X;
fitness=FVAL;
newNEval=NEval;
sumVio=OUTPUT.constrviolation;
newConst=NConst;
has_change=flag;
end