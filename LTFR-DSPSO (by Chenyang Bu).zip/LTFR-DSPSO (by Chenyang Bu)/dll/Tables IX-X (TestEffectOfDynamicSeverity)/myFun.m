function [fitness] = myFun( x )%,g

fitness=EvaluateF(x);
% 
%  disp('fitness');
%  x
%   disp(fitness);
%g=EvaluateGradObj(x,fitness);
end
function fitness=EvaluateF(x)
global NEval;

global Problem;
global flag;
global n_var;
global Period;
global numPeaks;
global numRegions;
global mpb_changeType;
global mfrb_changeType;
 global times_len;
global times_con;
%Problem=17;
%for i=1:3
NEval=NEval+1;
if floor((NEval+20)/Period)>floor(NEval/Period)%mod((NEval+20),Period)==0
    flag=1.0;
    % hold off;
end
%end
% disp('Problem');
% disp(Problem);
% X(1,x);
% X(2,x);
% disp('test over');

if Problem<=16||(Problem<=8003&&Problem>=3001)
    fitness=-1*(X(1,x)+X(2,x));
elseif Problem==17||Problem==18
    fitness=-3*exp(-1*sqrt(sqrt((X(1,x))^2+(X(2,x))^2)));
elseif Problem==101
    %disp('test');
    fitness=5.0*(X(1,x)+X(2,x)+X(3,x)+X(4,x))-5.0*(X(1,x)*X(1,x)+X(2,x)*X(2,x)+X(3,x)*X(3,x)+X(4,x)*X(4,x));
    %disp('test1');
    %fitness
elseif Problem==21||Problem==22
    f1 = 0.;
    f2 = 1.;
    f3 = 0.;
    for j=1:n_var
        %       X(j,x)
        %       cos(X(j,x))
        %       cos(X(j,x))^4;
        f1 = f1 + (cos (X(j,x)))^4;
        f2 = f2 * cos (X(j,x)) * cos (X(j,x));
        f3 = f3 + ( (j )) * X(j,x) * X(j,x);
        
        % f1 = f1 + (cos (x(j)))^4
        %       f2 = f2 * cos (x(j)) * cos (x(j))
        %       f3 = f3 + ( (j )) * x(j) *x(j)
    end
    fitness=-abs ((f1 - 2 * f2) / sqrt (f3));
elseif Problem>=10000   

    fitness=-evaluateF(n_var,numPeaks,Period,mpb_changeType,NEval,x,0,times_con,times_len,Problem);
  % disp('fitness:');
  % disp(fitness);
end

end
function g=EvaluateGradObj(x,fit)
global DELTA;
global n_var;
global DELTA_1;
for j=1:(n_var)
    xj=x(j);
    x(j)=x(j)+DELTA;
    x_dash=EvaluateF(x);
    x(j)=xj;
    g(j)=(x_dash-fit)*DELTA_1;
end
end
function value=X(index,x)
% disp('X');disp(index);
% x(index)
% p_i(index)
% q_i(index)
global Problem;
global k;
global changeStep;
global Period;
global NEval;
% changeStep
% NEval
% Period
changeStep=floor(NEval/Period);
%if Problem<=18
%  value=p_i(index)*(x(index)+q_i(index));
if Problem==101
    % k
    % changeStep
    % x(index)
    value=cos(k*pi*changeStep/2.0)*x(index);
else
    value=p_i(index)*(x(index)+q_i(index));
end
end
function value=p_i(index)
global Problem;
global NEval;
global Period;
global Flag;
global k;
changeStep=floor(NEval/Period);
switch Problem
    case 1
        if index==1
            value=sin(k*pi*changeStep+pi/2);
        else
            value=1;
        end
    case 2
        if index==1
            value=sin(k*pi*changeStep+pi/2);
        else
            value=1;
        end
    case 3
        value=1.0;
    case 4
        value=1.0;
    case {5,6,11,5001,5003}
        if mod(changeStep,2)==0
            if index==1
                value=sin(k*pi*changeStep/2+pi/2);
            else
                if changeStep==0
                    value=0.0;
                else
                    value=sin(k*pi*(changeStep-2)/2+pi/2);
                end
            end
        else
            if index==1
                value=sin(k*pi*(changeStep-1)/2+pi/2);
            else
                value=sin(k*pi*(changeStep-1)/2+pi/2);
            end
        end
    case {7,3001,3003}
        value=1;
    case {8,8001,8003}
        if index==1
            value=sin(k*pi*changeStep+pi/2);
        else
            value=1;
        end
    case 9
        value=1;
    case {10,4001,4003}
        if index==1
            value=sin(k*pi*changeStep+pi/2);
        else
            value=1;
        end
    case {12,13,14,15}
        if index==1
            value=sin(pi*changeStep+pi/2);
        else
            value=1;
        end
    case {16,7001,7003}
        value=1;
    case {17,18}
        value=-1;
    case {21,22}
        value=1;
    otherwise
        if abs(Flag-1)<0.01
            if index==1
                value=sin(k*pi*changeStep+pi/2);
            else
                value=1;
            end
        elseif abs(Flag-2)<0.01
            if mod(changeStep,2)==0
                if index==1
                    value=sin(k*pi*changeStep/2+pi/2);
                else
                    if changeStep==0
                        value=0.0;
                    else
                        value=sin(k*pi*(changeStep-2)/2+pi/2);
                    end
                end
            else
                if index==1
                    value=sin(k*pi*(changeStep-1)/2+pi/2);
                else
                    value=sin(k*pi*(changeStep-1)/2+pi/2);
                end
            end
        elseif abs(Flag-0.0)<0.01
            value=1;
        end
        
end
% disp('p');
% disp(index);
% disp(value);
end
function value=q_i(index)
global Problem;
global NEval;
global k;
global Period;
global ub;
global lb;
% disp('k'+k);
%k=0.5
changeStep=floor(NEval/Period);
switch Problem
    case {1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,3001,3003,4001,4003,5001,5003,7001,7003,8001,8003}
        value=0.0;
    case 4
        value=1.0;
    case 17
        if index==1
            %value=-1*(1.470561702+0.858958496*cos(k*pi*changeStep));
            value=-1*(1.4706+0.859*cos(k*pi*changeStep));
        else
            % value=-1*(3.442094786232+0.858958496*sin(k*pi*changeStep));
            value=-1*(3.442+0.859*sin(k*pi*changeStep));
        end
    case 18
        if index==1
            % value=-1*(1.470561702+0.858958496*cos(k*pi*changeStep));
            value=-1*(1.4706+0.859*cos(k*pi*changeStep));
        else
            %value=-1*(3.442094786232+0.858958496*sin(k*pi*changeStep));
            value=-1*(3.442+0.859*sin(k*pi*changeStep));
        end
    case 21
        value=0.0;
    case 22
        value=-changeStep*(ub(index)-lb(index))/k;
    otherwise 
        value=0.0;
end
% disp('q');disp(index);
% disp(value);
end