function [ c,ceq ] = mycon( x )
global DELTA;
global DELTA_1;
DELTA=1.0e-12;
DELTA_1=1.0e12;
c=EvaluateC(x);
ceq=[];
% disp(['con']);
% disp(x);
% disp(c);
%GC=EvaluateNabla(x,c);
end
function c=EvaluateC(x)
global NConst;
global Problem;
global n_var;
global val_1;
global val_2;
global val_3;
global Period;
global numPeaks;
global NEval;
global numRegions;
global mpb_changeType;
global mfrb_changeType;
global conHeight;
global times_len;
global times_con;
NConst=NConst+1;
if(Problem<10000)
tmp1=Y(1,x);
tmp2=Y(2,x);
end
switch Problem
    case 12
        c(1)=2*Y(1,x)+3*Y(2,x)-9;
        tmp1=Y(1,x);
        tmp2=Y(2,x);
        if (tmp1<=1&&tmp1>=0&&2<=tmp2&&tmp2<=3)||(tmp1<=3&&tmp1>=2)
            c(2)=-1;
        else
            c(2)=1;
        end
    case 13
        c(1)=2*Y(1,x)+3*Y(2,x)-9;
    case 14
        c(1)=2*Y(1,x)+3*Y(2,x)-9;
        tmp1=Y(1,x);
        tmp2=Y(2,x);
        if (tmp1<=1&&tmp1>=0)||(2<=tmp1&&tmp1<=3)
            c(2)=-1;
        else
            c(2)=1;
        end
    case 15
        tmp1=Y(1,x);
        tmp2=Y(2,x);
        if (tmp1<=0.5&&tmp1>=0)||(2.5<=tmp1&&tmp1<=3)
            c(1)=-1;
        else
            c(1)=1;
        end
        %tmp1=Y(1,x);
        %tmp2=Y(2,x);
        %         if (tmp1<=1&&tmp1>=0&&2<=tmp2&&tmp2<=3)||(tmp1<=3&&tmp1>=2)
        %             c(2)=-1;
        %         else
        %             c(2)=1;
        %         end
        c(2)=2*tmp1+3*tmp2-9;
    case 101
        c(1) = 2.0 * Y(1,x) + 2.0 * Y(2,x) + Y(10,x) + Y(11,x) - 10;
        c(2) = 2.0 * Y(1,x) + 2.0 * Y(3,x) + Y(10,x) + Y(12,x) - 10.;
        c(3) = 2.0 * Y(2,x) + 2.0 * Y(3,x) + Y(11,x) + Y(12,x) - 10.;
        c(4) = -8.0 * Y(1,x) + Y(10,x);
        c(5) = -8.0 * Y(2,x) + Y(11,x);
        c(6) = -8.0 * Y(3,x) + Y(12,x);
        c(7) = -2.0 * Y(4,x) - Y(5,x) + Y(10,x);
        c(8) = -2.0 * Y(6,x) - Y(7,x) + Y(11,x);
        c(9) = -2.0 * Y(8,x) - Y(9,x) + Y(12,x);
    case {3001,5001,4001,7001,8001,6001}
        c(1)=-2*Y(1,x).^4+8*(Y(1,x).^3)-8*(Y(1,x).^2)+Y(2,x)-2;
        c(2)=-4*(Y(1,x).^4)+32*(Y(1,x).^3)-88*(Y(1,x).^2)+96*Y(1,x)+Y(2,x)-36;
        c(3)=val_1-Y(2,x);
        %c(4)=Y(1,x)-val_2;
    case {3003,4003,5003,6003,8003,7003,3010,3011,3020,3021}
        m1 =0.611603206382;
        m2= 1.637497;
        m3= 2.32952019747762;
        n1= 3.442094786232;
        n2 =2.712499;
        n3 =3.17849307411774;
        val=[m1,(n1-val_1);m2,(n2-val_2);m3,(n3-val_3)];
        c(1)=-2*Y(1,x).^4+8*(Y(1,x).^3)-8*(Y(1,x).^2)+Y(2,x)-2;
        c(2)=-4*(Y(1,x).^4)+32*(Y(1,x).^3)-88*(Y(1,x).^2)+96*Y(1,x)+Y(2,x)-36;
        c(2)=(val(2,2)-val(1,2))/(val(2,1)-val(1,1))*(tmp1-val(1,1))+val(1,2)-Y(2,x);
		c(3)=(val(2,2)-val(3,2))/(val(2,1)-val(3,1))*(tmp1-val(3,1))+val(3,2)-Y(2,x);       
    case {21,22}
        tmp1=1.0;
        tmp2=0.0;
        for i=1:n_var
            tmp1=tmp1*Y(i,x);
            tmp2=tmp2+Y(i,x);
        end
        
        c(1)=0.75-tmp1;
        c(2)=-tmp2;
    case{10000,10001}
        c(1)=evaluateF(n_var,numRegions,Period,mfrb_changeType,NEval,x,1,times_con,times_len,Problem);
        c(1)=conHeight-c(1);
    otherwise
        c(1)=-2*Y(1,x).^4+8*(Y(1,x).^3)-8*(Y(1,x).^2)+Y(2,x)-2;
        c(2)=-4*(Y(1,x).^4)+32*(Y(1,x).^3)-88*(Y(1,x).^2)+96*Y(1,x)+Y(2,x)-36;
end
end

function GC=EvaluateNabla(x,c)
global n_var;
global n_con;
global DELTA;
global DELTA_1;
GC=zeros(n_con,n_var);
for j=1:(n_var)
    xj=x(j);
    x(j)=x(j)+DELTA;
    c_dash=EvaluateC(x);
    x(j)=xj;
    for i=1:(n_con)
        GC(i,j)=(c_dash(i)-c(i))*DELTA_1;
    end
end
end
function value=Y(index,x)
global Problem;
if Problem==101
    value=x(index);
else
    value=r_i(index)*(x(index)+s_i(index));
end
end
function value=r_i(index)
value=1.0;
end
function value=s_i(index)
global S;
global ub;
global lb;
global Problem;
global NEval;
global Period;
changeStep=floor(NEval/Period);

switch Problem
    case {7,8,3001,3003,8001,8003}
        if index==1
            value=0.0;
        else
            value=2-changeStep*(ub(2)-lb(2))/S;
        end
    case 9
        if index==1
            value=0.0;
        else
            value=2;
        end
    case {10,11,16,4001,4003,5001,5003,7001,7003}
        if index==1
            value=0.0;
        else
            value=changeStep*(ub(2)-lb(2))/S;
        end
    case {2,3,5,12,13,14,15,18}
        value=0.0;
    case {21,22}
        value=-changeStep*(ub(index)-lb(index))/S;
    case {3010}%cyclic change
        if index==1
            value=0.0;
        else
            value=(ub(2)-lb(2))/S*sin(pi/2*changeStep);
        end
    case {3011}
         if index==1
            value=0.0;
        else
            value=2-(ub(2)-lb(2))/S*sin(pi/2*changeStep);
         end
    case {3020}
        if index==1
            value=0.0;
        else
            value=(ub(2)-lb(2))/S*exp(-0.1*changeStep*sin(pi/2*changeStep));
        end
    case {3021}
        if index==1
            value=0.0;
        else
            value=2-(ub(2)-lb(2))/S*exp(-0.1*changeStep*sin(pi/2*changeStep));
        end
        
end

end
