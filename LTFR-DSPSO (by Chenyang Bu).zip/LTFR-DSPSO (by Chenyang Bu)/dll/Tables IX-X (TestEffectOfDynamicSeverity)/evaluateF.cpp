#define TestEffectofDynamicSeverity
// #define TestOutput

#include "matrix.h"
#include "mex.h"
//#if (_MSC_VER >= 1600)
//#define __STDC_UTF_16__
//#endif
#ifdef _DEBUG // �ڴ�й©���֧�֡�
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <malloc.h>    // ��� malloc.h �� crtdbg.h ˳���µ� Debug Assertion Failed, "Corrupted pointer passed to _freea" ��
#include <crtdbg.h>
#ifndef DBG_NEW
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#define new DBG_NEW
#endif
#endif  // _DEBUG
#include <iostream>
#include <string.h>

#include <math.h>

#define EALIB
//#define M_PI 3.14159265358979323846

#define _USE_MATH_DEFINES
#include<stdlib.h>
#include<time.h>
#include<cmath>
#include<string>
#define M_PI 3.1415926535897932384626433832795028841971

#define PI acos(-1.0) ///3.14159265358979323846
#define E exp(1.0)  // 2.71828182845904523536
#include <sstream>

#include <fstream>
#include<climits>
#include <iomanip>
#include <vector>
#include <map>
using namespace std;
/// \defgroup rbd_common RBD common library
///@{

/// \file include.h
/// Set options and and details of include files.

#ifndef INCLUDE_LIB
#define INCLUDE_LIB

//#define use_namespace                   // define name spaces

//#define SETUP_C_SUBSCRIPTS              // allow element access via A[i][j]

//#define OPT_COMPATIBLE                  // for use with opt++

// Activate just one of the following 3 statements

//#define SimulateExceptions              // use simulated exceptions
#define UseExceptions                   // use C++ exceptions
//#define DisableExceptions               // do not use exceptions


//#define TEMPS_DESTROYED_QUICKLY         // for compilers that delete
// temporaries too quickly

//#define TEMPS_DESTROYED_QUICKLY_R       // the same thing but applied
// to return from functions only

//#define DO_FREE_CHECK                   // check news and deletes balance

#define USING_DOUBLE                    // elements of type double
//#define USING_FLOAT                   // elements of type float

#define bool_LIB 0                      // for compatibility with my older libraries

//#define ios_format_flags ios::fmtflags  // for Gnu 3 and Intel for Linux


#define _STANDARD_                    // using standard library

//#define use_float_h                   // use float.h for precision data


//#define HAS_INT64                     // if unsigned _int64 is recognised
// used by newran03

// comment out next line if Exception causes a problem
#define TypeDefException

//*********************** end of options set by user ********************


// for Gnu C++ version 3
#if defined __GNUG__ && __GNUG__ >= 3
#define _STANDARD_                   // use standard library
#define ios_format_flags ios::fmtflags
#endif

// for Intel C++ for Linux
#if defined __ICC
#define _STANDARD_                   // use standard library
#define ios_format_flags ios::fmtflags
#endif

// for Microsoft Visual C++ 7 and above (and Intel simulating these)
#if defined _MSC_VER && _MSC_VER >= 1300
#define _STANDARD_                   // use standard library
#endif


#ifdef _STANDARD_                       // using standard library
#include <cstdlib>
#if defined _MSC_VER && _MSC_VER == 1200
#include <limits>              // for VC++6
#endif
#ifdef WANT_STREAM
#include <iostream>
#include <iomanip>
#endif
#ifdef WANT_MATH
#include <cmath>
#endif
#ifdef WANT_STRING
#include <cstring>
#endif
#ifdef WANT_TIME
#include <ctime>
#endif
#ifdef WANT_FSTREAM
#include <fstream>
#endif
using namespace std;
#else

#define DEFAULT_HEADER                  // use AT&T style header
// if no other compiler is recognised

#ifdef _MSC_VER                         // Microsoft
#include <stdlib.h>

//   reactivate these statements to run under MSC version 7.0
//   typedef int jmp_buf[9];
//   extern "C"
//   {
//      int __cdecl setjmp(jmp_buf);
//      void __cdecl longjmp(jmp_buf, int);
//   }

#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#include <float.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#ifdef __ZTC__                          // Zortech
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.hpp>
#include <iomanip.hpp>
#define flush ""                  // not defined in iomanip?
#endif
#ifdef WANT_MATH
#include <math.h>
#include <float.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#if defined __BCPLUSPLUS__ || defined __TURBOC__  // Borland or Turbo
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#include <float.h>            // Borland has both float and values
// but values.h returns +INF for
// MAXDOUBLE in BC5
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#ifdef __GNUG__                         // Gnu C++
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#include <float.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#ifdef __WATCOMC__                      // Watcom C/C++
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#include <float.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif


#ifdef macintosh                        // MPW C++ on the Mac
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <float.h>
#include <math.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif

#ifdef use_float_h                      // use float.h for precision values
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <float.h>
#include <math.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#undef DEFAULT_HEADER
#endif


#ifdef DEFAULT_HEADER                   // for example AT&T
#define ATandT
#include <stdlib.h>
#ifdef WANT_STREAM
#include <iostream.h>
#include <iomanip.h>
#endif
#ifdef WANT_MATH
#include <math.h>
#define SystemV                         // use System V
#include <values.h>
#endif
#ifdef WANT_STRING
#include <string.h>
#endif
#ifdef WANT_TIME
#include <time.h>
#endif
#ifdef WANT_FSTREAM
#include <fstream.h>
#endif
#endif                                  // DEFAULT_HEADER

#endif                                  // _STANDARD_

#ifdef use_namespace
namespace RBD_COMMON {
#endif
    
    
#ifdef USING_FLOAT                      // set precision type to float
    typedef float Real;
    typedef double long_Real;
#endif
    
#ifdef USING_DOUBLE                     // set precision type to double
    typedef double Real;
    typedef long double long_Real;
#endif
    
    
    // This is for (very old) compilers that do not have bool automatically defined
    
#ifndef bool_LIB
#define bool_LIB 0
    
    class bool
    {
        int value;
    public:
        bool(const int b) { value = b ? 1 : 0; }
        bool(const void* b) { value = b ? 1 : 0; }
        bool() {}
        operator int() const { return value; }
        int operator!() const { return !value; }
    };
    
    
    const bool true = 1;
    const bool false = 0;
    
#endif
    
    
#ifdef use_namespace
}
#endif


#ifdef use_namespace
namespace RBD_COMMON {}
namespace RBD_LIBRARIES                 // access all my libraries
{
    using namespace RBD_COMMON;
}
#endif


#endif


///@}










/// \ingroup newran
///@{

/// \file extreal.h
/// "Extended real" - header file.


#ifndef EXTREAL_LIB
#define EXTREAL_LIB 0

#ifdef use_namespace
namespace RBD_COMMON {
#endif
    
    /************************ extended real class ***************************/
    
    enum EXT_REAL_CODE
    { Finite, PlusInfinity, MinusInfinity, Indefinite, Missing };
    
    class ExtReal
    {
        Real value;
        EXT_REAL_CODE c;
    public:
            ExtReal operator+(const ExtReal&) const;
            ExtReal operator-(const ExtReal&) const;
            ExtReal operator*(const ExtReal&) const;
            ExtReal operator-() const;
            ExtReal(Real v) { c=Finite; value=v; }
            ExtReal(const EXT_REAL_CODE& cx) { c = cx; }
            ExtReal() { c = Missing; }
            Real Value() const { return value; }
            bool IsReal() const { return c==Finite; }
            EXT_REAL_CODE Code() const { return c; }
            //   friend ostream& operator<<(ostream& os, const ExtReal& er);
    };
    
#ifdef use_namespace
}
#endif


#endif

// body file: extreal.cpp

///@}
/// \ingroup newran
///@{

/// \file extreal.cpp
/// "Extended real" - body file.


#define WANT_FSTREAM

#ifdef use_namespace
namespace RBD_COMMON {
#endif
    
    ExtReal ExtReal::operator+(const ExtReal& er) const
    {
        if (c==Finite && er.c==Finite) return ExtReal(value+er.value);
        if (c==Missing || er.c==Missing) return ExtReal(Missing);
        if (c==Indefinite || er.c==Indefinite) return ExtReal(Indefinite);
        if (c==PlusInfinity)
        {
            if (er.c==MinusInfinity) return ExtReal(Indefinite);
            return *this;
        }
        if (c==MinusInfinity)
        {
            if (er.c==PlusInfinity) return ExtReal(Indefinite);
            return *this;
        }
        return er;
    }
    
    ExtReal ExtReal::operator-(const ExtReal& er) const
    {
        if (c==Finite && er.c==Finite) return ExtReal(value-er.value);
        if (c==Missing || er.c==Missing) return ExtReal(Missing);
        if (c==Indefinite || er.c==Indefinite) return ExtReal(Indefinite);
        if (c==PlusInfinity)
        {
            if (er.c==PlusInfinity) return ExtReal(Indefinite);
            return *this;
        }
        if (c==MinusInfinity)
        {
            if (er.c==MinusInfinity) return ExtReal(Indefinite);
            return *this;
        }
        return er;
    }
    
    ExtReal ExtReal::operator*(const ExtReal& er) const
    {
        if (c==Finite && er.c==Finite) return ExtReal(value*er.value);
        if (c==Missing || er.c==Missing) return ExtReal(Missing);
        if (c==Indefinite || er.c==Indefinite) return ExtReal(Indefinite);
        if (c==Finite)
        {
            if (value==0.0) return ExtReal(Indefinite);
            if (value>0.0) return er;
            return (-er);
        }
        if (er.c==Finite)
        {
            if (er.value==0.0) return ExtReal(Indefinite);
            if (er.value>0.0) return *this;
            return -(*this);
        }
        if (c==PlusInfinity) return er;
        return (-er);
    }
    
    ExtReal ExtReal::operator-() const
    {
        switch (c)
        {
            case Finite:        return ExtReal(-value);
            case PlusInfinity:  return ExtReal(MinusInfinity);
            case MinusInfinity: return ExtReal(PlusInfinity);
            case Indefinite:    return ExtReal(Indefinite);
            case Missing:       return ExtReal(Missing);
        }
        return 0.0;
    }
    
    /*ostream& operator<<(ostream& os, const ExtReal& er)
     * {
     * switch (er.c)
     * {
     * case Finite:        os << er.value;         break;
     * case PlusInfinity:  os << "plus-infinity";  break;
     * case MinusInfinity: os << "minus-infinity"; break;
     * case Indefinite:    os << "indefinite";     break;
     * case Missing:       os << "missing";        break;
     * }
     * return os;
     * }*/
    
#ifdef use_namespace
}
#endif

///@}







/// \ingroup rbd_common
///@{

/// \file myexcept.h
/// Exception handler.
/// The low level classes for
/// - my exception class hierarchy
/// - the functions needed for my simulated exceptions
/// - the Tracer mechanism
/// - routines for checking whether new and delete calls are balanced
///


// A set of classes to simulate exceptions in C++
//
//   Partially copied from Carlos Vidal s article in the C users  journal
//   September 1992, pp 19-28
//
//   Operations defined
//      Try {     }
//      Throw ( exception object )
//      ReThrow
//      Catch ( exception class ) {      }
//      CatchAll {      }
//      CatchAndThrow
//
//   All catch lists must end with a CatchAll or CatchAndThrow statement
//   but not both.
//
//   When exceptions are finally implemented replace Try, Throw(E), Rethrow,
//   Catch, CatchAll, CatchAndThrow by try, throw E, throw, catch,
//   catch(...), and {}.
//
//   All exception classes must be derived from BaseException, have no
//   non-static variables and must include the statement
//
//      static unsigned long Select;
//
//   Any constructor in one of these exception classes must include
//
//      Select = BaseException::Select;
//
//   For each exceptions class, EX_1, some .cpp file must include
//
//      unsigned long EX_1::Select;
//


#ifndef EXCEPTION_LIB
#define EXCEPTION_LIB


#ifdef use_namespace
namespace RBD_COMMON {
#endif
    
    
    void Terminate();
    
    
    //********** classes for setting up exceptions and reporting ************//
    
    class BaseException;
    
    class Tracer                             // linked list showing how
    {                                        // we got here
        const char* entry;
        Tracer* previous;
    public:
        Tracer(const char*);
        ~Tracer();
        void ReName(const char*);
        static void PrintTrace();             // for printing trace
        static void AddTrace();               // insert trace in exception record
        static Tracer* last;                  // points to Tracer list
        friend class BaseException;
    };
    
    
    class BaseException                          // The base exception class
    {
    protected:
        static char* what_error;              // error message
        static int SoFar;                     // no. characters already entered
        static int LastOne;                   // last location in error buffer
    public:
        static void AddMessage(const char* a_what);
        // messages about exception
        static void AddInt(int value);        // integer to error message
        static unsigned long Select;          // for identifying exception
        BaseException(const char* a_what = 0);
        static const char* what() { return what_error; }
        // for getting error message
    };
    
#ifdef TypeDefException
    typedef BaseException Exception;        // for compatibility with my older libraries
#endif
    
    inline Tracer::Tracer(const char* e)
    : entry(e), previous(last) { last = this; }
    
    inline Tracer::~Tracer() { last = previous; }
    
    inline void Tracer::ReName(const char* e) { entry=e; }
    
#ifdef SimulateExceptions                // SimulateExceptions
    
#include <setjmp.h>
    
    
    //************* the definitions of Try, Throw and Catch *****************//
    
    
    
    
    class JumpBase         // pointer to a linked list of jmp_buf s
    {
    public:
        static JumpItem *jl;
        static jmp_buf env;
    };
    
    class JumpItem         // an item in a linked list of jmp_buf s
    {
    public:
        JumpItem *ji;
        jmp_buf env;
        Tracer* trace;                     // to keep check on Tracer items
        Janitor* janitor;                  // list of items for cleanup
        JumpItem() : ji(JumpBase::jl), trace(0), janitor(0)
        { JumpBase::jl = this; }
        ~JumpItem() { JumpBase::jl = ji; }
    };
    
    void Throw();
    
    inline void Throw(const BaseException&) { Throw(); }
    
#define Try                                             \
    if (!setjmp( JumpBase::jl->env )) {                  \
            JumpBase::jl->trace = Tracer::last;               \
            JumpItem JI387256156;
            
#define ReThrow Throw()
            
#define Catch(EXCEPTION)                                \
    } else if (BaseException::Select == EXCEPTION::Select) {
        
#define CatchAll } else
        
#define CatchAndThrow  } else Throw();
        
        
        //****************** cleanup heap following Throw ***********************//
        
        class Janitor
        {
        protected:
            static bool do_not_link;                  // set when new is called
            bool OnStack;                             // false if created by new
        public:
            Janitor* NextJanitor;
            virtual void CleanUp() {}
            Janitor();
            virtual ~Janitor();
        };
        
        
        // The tiresome old trick for initializing the Janitor class
        // this is needed for classes derived from Janitor which have objects
        // declared globally
        
        class JanitorInitializer
        {
        public:
            JanitorInitializer();
        private:
            static int ref_count;
        };
        
        static JanitorInitializer JanInit;
        
#endif                                // end of SimulateExceptions
        
#ifdef UseExceptions
        
#define Try try
#define Throw(E) throw E
#define ReThrow throw
#define Catch catch
#define CatchAll catch(...)
#define CatchAndThrow {}
        
#endif                                // end of UseExceptions
        
        
#ifdef DisableExceptions              // Disable exceptions
        
#define Try {
#define ReThrow Throw()
#define Catch(EXCEPTION) } if (false) {
#define CatchAll } if (false)
#define CatchAndThrow }
        
        inline void Throw() { Terminate(); }
        inline void Throw(const BaseException&) { Terminate(); }
        
        
#endif                                // end of DisableExceptions
        
#ifndef SimulateExceptions            // ! SimulateExceptions
        
        class Janitor                         // a dummy version
        {
        public:
            virtual void CleanUp() {}
            Janitor() {}
            virtual ~Janitor() {}
        };
        
#endif                                // end of ! SimulateExceptions
        
        
        //******************** FREE_CHECK and NEW_DELETE ***********************//
        
#ifdef DO_FREE_CHECK                          // DO_FREE_CHECK
        // Routines for tracing whether new and delete calls are balanced
        
        class FreeCheck;
        
        class FreeCheckLink
        {
        protected:
            FreeCheckLink* next;
            void* ClassStore;
            FreeCheckLink();
            virtual void Report()=0;                   // print details of link
            friend class FreeCheck;
        };
        
        class FCLClass : public FreeCheckLink         // for registering objects
        {
            char* ClassName;
            FCLClass(void* t, char* name);
            void Report();
            friend class FreeCheck;
        };
        
        class FCLRealArray : public FreeCheckLink     // for registering real arrays
        {
            char* Operation;
            int size;
            FCLRealArray(void* t, char* o, int s);
            void Report();
            friend class FreeCheck;
        };
        
        class FCLIntArray : public FreeCheckLink     // for registering int arrays
        {
            char* Operation;
            int size;
            FCLIntArray(void* t, char* o, int s);
            void Report();
            friend class FreeCheck;
        };
        
        
        class FreeCheck
        {
            static FreeCheckLink* next;
            static int BadDelete;
        public:
            static void Register(void*, char*);
            static void DeRegister(void*, char*);
            static void RegisterR(void*, char*, int);
            static void DeRegisterR(void*, char*, int);
            static void RegisterI(void*, char*, int);
            static void DeRegisterI(void*, char*, int);
            static void Status();
            friend class FreeCheckLink;
            friend class FCLClass;
            friend class FCLRealArray;
            friend class FCLIntArray;
        };
        
#define FREE_CHECK(Class)                                                  \
        public:                                                                    \
                void* operator new(size_t size)                                         \
        {                                                                       \
                                                                                        void* t = ::operator new(size); FreeCheck::Register(t,#Class);       \
                                                                                                return t;                                                            \
        }                                                                       \
                void operator delete(void* t)                                           \
        { FreeCheck::DeRegister(t,#Class); ::operator delete(t); }
        
        
#ifdef SimulateExceptions         // SimulateExceptions
        
#define NEW_DELETE(Class)                                                  \
        public:                                                                    \
                void* operator new(size_t size)                                         \
        {                                                                       \
                                                                                        do_not_link=true;                                                    \
                                                                                        void* t = ::operator new(size); FreeCheck::Register(t,#Class);       \
                                                                                                return t;                                                            \
        }                                                                       \
                void operator delete(void* t)                                           \
        { FreeCheck::DeRegister(t,#Class); ::operator delete(t); }
        
        
#endif                           // end of SimulateExceptions
        
        
#define MONITOR_REAL_NEW(Operation, Size, Pointer)                         \
        FreeCheck::RegisterR(Pointer, Operation, Size);
#define MONITOR_INT_NEW(Operation, Size, Pointer)                          \
        FreeCheck::RegisterI(Pointer, Operation, Size);
#define MONITOR_REAL_DELETE(Operation, Size, Pointer)                      \
        FreeCheck::DeRegisterR(Pointer, Operation, Size);
#define MONITOR_INT_DELETE(Operation, Size, Pointer)                       \
        FreeCheck::DeRegisterI(Pointer, Operation, Size);
        
#else                            // DO_FREE_CHECK not defined
        
#define FREE_CHECK(Class) public:
#define MONITOR_REAL_NEW(Operation, Size, Pointer) {}
#define MONITOR_INT_NEW(Operation, Size, Pointer) {}
#define MONITOR_REAL_DELETE(Operation, Size, Pointer) {}
#define MONITOR_INT_DELETE(Operation, Size, Pointer) {}
        
        
#ifdef SimulateExceptions         // SimulateExceptions
        
        
#define NEW_DELETE(Class)                                                  \
        public:                                                                    \
                void* operator new(size_t size)                                    \
        { do_not_link=true; void* t = ::operator new(size); return t; }    \
                void operator delete(void* t) { ::operator delete(t); }
        
#endif                            // end of SimulateExceptions
        
#endif                            // end of ! DO_FREE_CHECK
        
#ifndef SimulateExceptions        // ! SimulateExceptions
        
#define NEW_DELETE(Class) FREE_CHECK(Class)
        
#endif                            // end of ! SimulateExceptions
        
        
        //********************* derived exceptions ******************************//
        
        class Logic_error : public BaseException
        {
        public:
            static unsigned long Select;
            Logic_error(const char* a_what = 0);
        };
        
        class Runtime_error : public BaseException
        {
        public:
            static unsigned long Select;
            Runtime_error(const char* a_what = 0);
        };
        
        class Domain_error : public Logic_error
        {
        public:
            static unsigned long Select;
            Domain_error(const char* a_what = 0);
        };
        
        class Invalid_argument : public Logic_error
        {
        public:
            static unsigned long Select;
            Invalid_argument(const char* a_what = 0);
        };
        
        class Length_error : public Logic_error
        {
        public:
            static unsigned long Select;
            Length_error(const char* a_what = 0);
        };
        
        class Out_of_range : public Logic_error
        {
        public:
            static unsigned long Select;
            Out_of_range(const char* a_what = 0);
        };
        
        //class Bad_cast : public Logic_error
        //{
        //public:
        //   static unsigned long Select;
        //   Bad_cast(const char* a_what = 0);
        //};
        
        //class Bad_typeid : public Logic_error
        //{
        //public:
        //   static unsigned long Select;
        //   Bad_typeid(const char* a_what = 0);
        //};
        
        class Range_error : public Runtime_error
        {
        public:
            static unsigned long Select;
            Range_error(const char* a_what = 0);
        };
        
        class Overflow_error : public Runtime_error
        {
        public:
            static unsigned long Select;
            Overflow_error(const char* a_what = 0);
        };
        
        class Bad_alloc : public BaseException
        {
        public:
            static unsigned long Select;
            Bad_alloc(const char* a_what = 0);
        };
        
#ifdef use_namespace
}
#endif


#endif                            // end of EXCEPTION_LIB


// body file: myexcept.cpp


///@}


/// \ingroup rbd_common
///@{

/// \file myexcept.cpp
/// Exception handler.
/// The low level classes for
/// - my exception class hierarchy
/// - the functions needed for my simulated exceptions
/// - the Tracer mechanism
/// - routines for checking whether new and delete calls are balanced
///

// Copyright (C) 1993,4,6: R B Davies


#define WANT_STREAM                    // include.h will get stream fns
#define WANT_STRING

#ifdef use_namespace
namespace RBD_COMMON {
#endif
    
    
    //#define REG_DEREG                    // for print out uses of new/delete
    //#define CLEAN_LIST                   // to print entries being added to
    // or deleted from cleanup list
    
#ifdef SimulateExceptions
    
    void Throw()
    {
        for (Janitor* jan = JumpBase::jl->janitor; jan; jan = jan->NextJanitor)
            jan->CleanUp();
        JumpItem* jx = JumpBase::jl->ji;    // previous jumpbase;
        if ( !jx ) { Terminate(); }         // jl was initial JumpItem
        JumpBase::jl = jx;                  // drop down a level; cannot be in front
        // of previous line
        Tracer::last = JumpBase::jl->trace;
        longjmp(JumpBase::jl->env, 1);
    }
    
#endif                                 // end of simulate exceptions
    
    
    unsigned long BaseException::Select;
    char* BaseException::what_error;
    int BaseException::SoFar;
    int BaseException::LastOne;
    
    BaseException::BaseException(const char* a_what)
    {
        Select++; SoFar = 0;
        if (!what_error)                   // make space for exception message
        {
            LastOne = 511;
            what_error = new char[512];
            if (!what_error)                // fail to make space
            {
                LastOne = 0;
                what_error = (char *)"No heap space for exception message\n";
            }
        }
        AddMessage("\n\nAn exception has been thrown\n");
        AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    void BaseException::AddMessage(const char* a_what)
    {
        if (a_what)
        {
            int l = strlen(a_what); int r = LastOne - SoFar;
            if (l < r) { strcpy(what_error+SoFar, a_what); SoFar += l; }
            else if (r > 0)
            {
                strncpy(what_error+SoFar, a_what, r);
                what_error[LastOne] = 0;
                SoFar = LastOne;
            }
        }
    }
    
    void BaseException::AddInt(int value)
    {
        bool negative;
        if (value == 0) { AddMessage("0"); return; }
        else if (value < 0) { value = -value; negative = true; }
        else negative = false;
        int n = 0; int v = value;        // how many digits will we need?
        while (v > 0) { v /= 10; n++; }
        if (negative) n++;
        if (LastOne-SoFar < n) { AddMessage("***"); return; }
        
        SoFar += n; n = SoFar; what_error[n] = 0;
        while (value > 0)
        {
            int nv = value / 10; int rm = value - nv * 10;  value = nv;
            what_error[--n] = (char)(rm + '0');
        }
        if (negative) what_error[--n] = '-';
        return;
    }
    
    void Tracer::PrintTrace()
    {
        cout << "\n";
        for (Tracer* et = last; et; et=et->previous)
            cout << "  * " << et->entry << "\n";
    }
    
    void Tracer::AddTrace()
    {
        if (last)
        {
            BaseException::AddMessage("Trace: ");
            BaseException::AddMessage(last->entry);
            for (Tracer* et = last->previous; et; et=et->previous)
            {
                BaseException::AddMessage("; ");
                BaseException::AddMessage(et->entry);
            }
            BaseException::AddMessage(".\n");
        }
    }
    
#ifdef SimulateExceptions
    
    
    Janitor::Janitor()
    {
        if (do_not_link)
        {
            do_not_link = false; NextJanitor = 0; OnStack = false;
#ifdef CLEAN_LIST
            cout << "Not added to clean-list " << (unsigned long)this << "\n";
#endif
        }
        else
        {
            OnStack = true;
#ifdef CLEAN_LIST
            cout << "Add to       clean-list " << (unsigned long)this << "\n";
#endif
            NextJanitor = JumpBase::jl->janitor; JumpBase::jl->janitor=this;
        }
    }
    
    Janitor::~Janitor()
    {
        // expect the item to be deleted to be first on list
        // but must be prepared to search list
        if (OnStack)
        {
#ifdef CLEAN_LIST
            cout << "Delete from  clean-list " << (unsigned long)this << "\n";
#endif
            Janitor* lastjan = JumpBase::jl->janitor;
            if (this == lastjan) JumpBase::jl->janitor = NextJanitor;
            else
            {
                for (Janitor* jan = lastjan->NextJanitor; jan;
                jan = lastjan->NextJanitor)
                {
                    if (jan==this)
                    { lastjan->NextJanitor = jan->NextJanitor; return; }
                    lastjan=jan;
                }
                
                Throw(BaseException(
                        "Cannot resolve memory linked list\nSee notes in myexcept.cpp for details\n"
                        ));
                
                
                // This message occurs when a call to ~Janitor() occurs, apparently
                // without a corresponding call to Janitor(). This could happen if my
                // way of deciding whether a constructor is being called by new
                // fails.
                
                // It may happen if you are using my simulated exceptions and also have
                // your compiler s exceptions turned on.
                
                // It can also happen if you have a class derived from Janitor
                // which does not include a copy constructor [ eg X(const &X) ].
                // Possibly also if delete is applied an object on the stack (ie not
                // called by new). Otherwise, it is a bug in myexcept or your compiler.
                // If you do not #define TEMPS_DESTROYED_QUICKLY you will get this
                // error with Microsoft C 7.0. There are probably situations where
                // you will get this when you do define TEMPS_DESTROYED_QUICKLY. This
                // is a bug in MSC. Beware of "operator" statements for defining
                // conversions; particularly for converting from a Base class to a
                // Derived class.
                
                // You may get away with simply deleting this error message and Throw
                // statement if you can not find a better way of overcoming the
                // problem. In any case please tell me if you get this error message,
                // particularly for compilers apart from Microsoft C 7.0.
                
                
            }
        }
    }
    
    JumpItem* JumpBase::jl;              // will be set to zero
    jmp_buf JumpBase::env;
    bool Janitor::do_not_link;           // will be set to false
    
    
    int JanitorInitializer::ref_count;
    
    JanitorInitializer::JanitorInitializer()
    {
        if (ref_count++ == 0) new JumpItem;
        // need JumpItem at head of list
    }
    
#endif                              // end of SimulateExceptions
    
    Tracer* Tracer::last;               // will be set to zero
    
    
    void Terminate()
    {
        cout << "\n\nThere has been an exception with no handler - exiting";
        const char* what = BaseException::what();
        if (what) cout << what << "\n";
        exit(1);
    }
    
    
    
#ifdef DO_FREE_CHECK
    // Routines for tracing whether new and delete calls are balanced
    
    FreeCheckLink::FreeCheckLink() : next(FreeCheck::next)
    { FreeCheck::next = this; }
    
    FCLClass::FCLClass(void* t, char* name) : ClassName(name) { ClassStore=t; }
    
    FCLRealArray::FCLRealArray(void* t, char* o, int s)
    : Operation(o), size(s) { ClassStore=t; }
    
    FCLIntArray::FCLIntArray(void* t, char* o, int s)
    : Operation(o), size(s) { ClassStore=t; }
    
    FreeCheckLink* FreeCheck::next;
    int FreeCheck::BadDelete;
    
    void FCLClass::Report()
    { cout << "   " << ClassName << "   " << (unsigned long)ClassStore << "\n"; }
    
    void FCLRealArray::Report()
    {
        cout << "   " << Operation << "   " << (unsigned long)ClassStore <<
                "   " << size << "\n";
    }
    
    void FCLIntArray::Report()
    {
        cout << "   " << Operation << "   " << (unsigned long)ClassStore <<
                "   " << size << "\n";
    }
    
    void FreeCheck::Register(void* t, char* name)
    {
        FCLClass* f = new FCLClass(t,name);
        if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
        cout << "Registering   " << name << "   " << (unsigned long)t << "\n";
#endif
    }
    
    void FreeCheck::RegisterR(void* t, char* o, int s)
    {
        FCLRealArray* f = new FCLRealArray(t,o,s);
        if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
        cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
    }
    
    void FreeCheck::RegisterI(void* t, char* o, int s)
    {
        FCLIntArray* f = new FCLIntArray(t,o,s);
        if (!f) { cout << "Out of memory in FreeCheck\n"; exit(1); }
#ifdef REG_DEREG
        cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
    }
    
    void FreeCheck::DeRegister(void* t, char* name)
    {
        FreeCheckLink* last = 0;
#ifdef REG_DEREG
        cout << "Deregistering " << name << "   " << (unsigned long)t << "\n";
#endif
        for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
        {
            if (fcl->ClassStore==t)
            {
                if (last) last->next = fcl->next; else next = fcl->next;
                delete fcl; return;
            }
            last = fcl;
        }
        cout << "\nRequest to delete non-existent object of class and location:\n";
        cout << "   " << name << "   " << (unsigned long)t << "\n";
        BadDelete++;
        Tracer::PrintTrace();
        cout << "\n";
    }
    
    void FreeCheck::DeRegisterR(void* t, char* o, int s)
    {
        FreeCheckLink* last = 0;
#ifdef REG_DEREG
        cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
        for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
        {
            if (fcl->ClassStore==t)
            {
                if (last) last->next = fcl->next; else next = fcl->next;
                if (s >= 0 && ((FCLRealArray*)fcl)->size != s)
                {
                    cout << "\nArray sizes do not agree:\n";
                    cout << "   " << o << "   " << (unsigned long)t
                            << "   " << ((FCLRealArray*)fcl)->size << "   " << s << "\n";
                    Tracer::PrintTrace();
                    cout << "\n";
                }
                delete fcl; return;
            }
            last = fcl;
        }
        cout << "\nRequest to delete non-existent real array:\n";
        cout << "   " << o << "   " << (unsigned long)t << "   " << s << "\n";
        BadDelete++;
        Tracer::PrintTrace();
        cout << "\n";
    }
    
    void FreeCheck::DeRegisterI(void* t, char* o, int s)
    {
        FreeCheckLink* last = 0;
#ifdef REG_DEREG
        cout << o << "   " << s << "   " << (unsigned long)t << "\n";
#endif
        for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next)
        {
            if (fcl->ClassStore==t)
            {
                if (last) last->next = fcl->next; else next = fcl->next;
                if (s >= 0 && ((FCLIntArray*)fcl)->size != s)
                {
                    cout << "\nArray sizes do not agree:\n";
                    cout << "   " << o << "   " << (unsigned long)t
                            << "   " << ((FCLIntArray*)fcl)->size << "   " << s << "\n";
                    Tracer::PrintTrace();
                    cout << "\n";
                }
                delete fcl; return;
            }
            last = fcl;
        }
        cout << "\nRequest to delete non-existent int array:\n";
        cout << "   " << o << "   " << (unsigned long)t << "   " << s << "\n";
        BadDelete++;
        Tracer::PrintTrace();
        cout << "\n";
    }
    
    void FreeCheck::Status()
    {
        if (next)
        {
            cout << "\nObjects of the following classes remain undeleted:\n";
            for (FreeCheckLink* fcl = next; fcl; fcl = fcl->next) fcl->Report();
            cout << "\n";
        }
        else cout << "\nNo objects remain undeleted\n\n";
        if (BadDelete)
        {
            cout << "\nThere were " << BadDelete <<
                    " requests to delete non-existent items\n\n";
        }
    }
    
#endif                            // end of DO_FREE_CHECK
    
    // derived exception bodies
    
    Logic_error::Logic_error(const char* a_what) : BaseException()
    {
        Select = BaseException::Select;
        AddMessage("Logic error:- "); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Runtime_error::Runtime_error(const char* a_what)
    : BaseException()
    {
        Select = BaseException::Select;
        AddMessage("Runtime error:- "); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Domain_error::Domain_error(const char* a_what) : Logic_error()
    {
        Select = BaseException::Select;
        AddMessage("domain error\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Invalid_argument::Invalid_argument(const char* a_what) : Logic_error()
    {
        Select = BaseException::Select;
        AddMessage("invalid argument\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Length_error::Length_error(const char* a_what) : Logic_error()
    {
        Select = BaseException::Select;
        AddMessage("length error\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Out_of_range::Out_of_range(const char* a_what) : Logic_error()
    {
        Select = BaseException::Select;
        AddMessage("out of range\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    //Bad_cast::Bad_cast(const char* a_what) : Logic_error()
    //{
    //   Select = BaseException::Select;
    //   AddMessage("bad cast\n"); AddMessage(a_what);
    //   if (a_what) Tracer::AddTrace();
    //}
    
    //Bad_typeid::Bad_typeid(const char* a_what) : Logic_error()
    //{
    //   Select = BaseException::Select;
    //   AddMessage("bad type id.\n"); AddMessage(a_what);
    //   if (a_what) Tracer::AddTrace();
    //}
    
    Range_error::Range_error(const char* a_what) : Runtime_error()
    {
        Select = BaseException::Select;
        AddMessage("range error\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Overflow_error::Overflow_error(const char* a_what) : Runtime_error()
    {
        Select = BaseException::Select;
        AddMessage("overflow error\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    Bad_alloc::Bad_alloc(const char* a_what) : BaseException()
    {
        Select = BaseException::Select;
        AddMessage("bad allocation\n"); AddMessage(a_what);
        if (a_what) Tracer::AddTrace();
    }
    
    
    
    
    unsigned long Logic_error::Select;
    unsigned long Runtime_error::Select;
    unsigned long Domain_error::Select;
    unsigned long Invalid_argument::Select;
    unsigned long Length_error::Select;
    unsigned long Out_of_range::Select;
    //unsigned long Bad_cast::Select;
    //unsigned long Bad_typeid::Select;
    unsigned long Range_error::Select;
    unsigned long Overflow_error::Select;
    unsigned long Bad_alloc::Select;
    
#ifdef use_namespace
}
#endif


///@}













#ifndef STRCUTDEC_H_INCLUDED
#define STRCUTDEC_H_INCLUDED



/*************************************************************************
 * Project: Library of Evolutionary Algoriths
 *************************************************************************
 * Author: Changhe Li & Ming Yang
 * Email: changhe.lw@google.com Or yangming0702@gmail.com
 * Language: C++
 *************************************************************************
 *  This file is part of EAlib. This library is free software;
 *  you can redistribute it and/or modify it under the terms of the
 *  GNU General Public License as published by the Free Software
 *  Foundation; either version 2, or (at your option) any later version.
 *************************************************************************/
// Created: 11 May 2011
// Last modified:
// struct and macro declaration

// types of problems
/*#define PRO_STATIC      0X01
 * #define PRO_DYNAMIC     0x02
 * #define PRO_MULTI_OBJ   0x04
 * #define PRO_CONSTRAINT  0x08
 */


#define MAX_NAME_LENGTH 250


enum Compare{MIN_OPT=0,MAX_OPT};

enum Encoding{C_DECIMAL=0, C_BINARY, C_INTEGER, C_STRING, C_UNSER_DEFINED};

enum ProCategory{CAT_STATIC,CAT_DYNAMIC,CAT_MULTIOBJ,CAT_CONSTRAINT};


/// TODO, the boundary class is not generic, only support problems in continuous space

template<typename T>
        struct Boundary{						//***************************************************//
    T upper;							//Dimension boudary in the landscape
    T lower;							//**************************************************//
    Encoding m_coding;
    bool m_flag;                        // flag of rigid boundary
    Boundary():m_coding(C_DECIMAL),m_flag(true){};
    Boundary(bool flag):m_coding(C_DECIMAL),m_flag(flag){};
    void setBoundary(const T rLower, const T rUpper){
        lower=rLower;
        upper=rUpper;
    };
    
    Boundary & operator=(const Boundary<T> &rBound){
        if(this==&rBound) return *this;
        upper=rBound.upper;
        lower=rBound.lower;
        return *this;
    };
};

//***********************Enviroment change types in GDBG system ******************************//
enum ChangeType{CT_SmallStep=0, CT_LargeStep,CT_Recurrent,CT_Chaotic,CT_RecurrentNoisy,
//added by Chenyang Bu <2015/1/23>
CT_Linear,CT_Cyclic,CT_None,CT_Random,CT_Decay
};

struct SChangeType{
    ChangeType type;
    int counter;
    SChangeType & operator=(const SChangeType & rCT){
        if(this==&rCT)  return *this;
        type=rCT.type;
        counter=rCT.counter;
        return *this;
    };
};

enum ProblemTag{
    //Benchmark problems
    Sphere=0,Sphere_Noisy,S_Sphere,R_Sphere,RS_Sphere,S_Sphere_CEC05, Sphere_Noisy_CEC05
            ,Rastrigin,Rastrigin_Noisy,S_Rastrigin,R_Rastrigin,RS_Rastrigin,S_Rastrigin_CEC05,RS_Rastrigin_CEC05
            ,Weierstrass,RS_Weierstrass,R_Weierstrass,RS_Weierstrass_CEC05
            ,Griewank,R_Griewank,RS_Griewank, RS_Griewank_noBounds_CEC05, Griewank_Rosenbrock_F13_CEC05, S_Griewank_Rosenbrock_F13_CEC05
            ,Ackley,Ackley_Noisy,S_Ackley,R_Ackley,RS_Ackley,RS_Ackley_Bound_CEC05
            ,Step
            ,Quartic_Noisy
            ,Scaffer_F6, Expanded_Scaffer_F6_CEC05, Noncont_Expanded_Scaffer_F6_CEC05, RS_Expanded_Scaffer_F6_CEC05
            ,Rosenbrock,S_Rosenbrock,S_Rosenbrock_CEC05
            ,Schwefel_2_13_CEC05
            ,Schwefel_2_22,Schwefel_2_22_Noisy,S_Schwefel_2_22,R_Schwefel_2_22,RS_Schwefel_2_22
            ,Schwefel,Schwefel_Noisy,S_Schwefel,R_Schwefel,RS_Schwefel
            ,Schwefel_1_2,Schwefel_1_2_Noisy,S_Schwefel_1_2,S_Schwefel_1_2_Noisy,R_Schwefel_1_2,RS_Schwefel_1_2, S_Schwefel_1_2_CEC05, S_Schwefel_1_2_Noisy_CEC05
            ,Schwefel_2_21
            ,Schwefel_2_6_Bound_CEC05
            ,Penalized_1
            ,Penalized_2
            ,Noncont_Rastrigin
            ,RS_Elliptic_CEC05,Elliptic
            ,Com,R_Com,Com_CEC05,H_Com_CEC05,H_Com_Noisy_CEC05
            ,RH_Com_CEC05,RH_Com_NarrowBasin_CEC05,RH_Com_Bound_CEC05
            ,RH_Com_F21_CEC05, RH_Com_HighConNumMatrix_F22_CEC05, Noncont_RH_Com_F23_CEC05, RH_Com_F24_CEC05, RH_Com_noBounds_F25_CEC05
            ,M_global1,M_global2,M_global3,M_global4,M_global5
            ,S_Sphere_CEC08,Schwefel_2_21_CEC08,S_Rosenbrock_CEC08,S_Rastrigin_CEC08,S_Griewank_CEC08,S_Ackley_CEC08
            //,Inverted_Shubert,Langermann
            
            ///real-world problems
            ,RW_Gear_Train,RW_ParEst_FMSoundWaves
            
            ///Dynamic Problems
            ,CompositionDBG_DOP,RotationDBG_DOP,MovingPeak_DOP,MovingFeasibleRegions_DOP,DF1_DOP,Binary_DOP
};
enum AlgorithmTag{
    //PSO
    ALG_SPSO=0,ALG_SPSO07,ALG_SLPSO,ALG_APSO,ALG_CPSOH,
    //DE
    ALG_SDE,ALG_CRDE,
    //GA
    ALG_SGA_REAL,
    //dynamic optimization
    ALG_CPSO, ALG_CPSOR,ALG_CDER,ALG_ESCA, ALG_SPSO_Parrott,ALG_rSPSO,ALG_mCPSO,ALG_mQSO,ALG_PSO_CP,ALG_HmSO,ALG_SOS,ALG_DynDE,
    ALG_CPSORL,ALG_CPSORC,ALG_mPSO,ALG_mDE,ALG_CPSOD,
    //DE
    ALG_Ming_DE, ALG_SaPDE, ALG_JADE, ALG_jDE, ALG_SaDE, ALG_dynNPDE, ALG_cDE,
    //CMAES
    ALG_CMAES,
    ALG_CLPSO,
    ALG_HRCGA
};




struct Gene{
    unsigned int m_length;
    Encoding  m_coding;
    void *mp_value;
};

enum PopInitMethod{POP_INIT_UNIFORM=0,POP_INIT_ORTHONORM,POP_INIT_CENTER,POP_INIT_USER_DEFINED};

enum ConvgProgeMode{PROGR_MEAN=0, PROGR_MEDEAN,PROGR_WORST, PROGR_BEST};
// the mode of the convergence speed graph,e.g., PROGR_MEAN denotes the mean value of all runs

enum SolutionValidation{VALIDATION_IGNORE=0,VALIDATION_REINITIALIZE,VALIDATION_REMAP,VALIDATION_SETTOBOUND};
//means of handling a solution that is out of the search space in continuous space

enum GAMutationStrategy{MUTAT_POLYNOMIAL,MUTAT_NORMAL};
enum GASelectionStrategy{SEL_TOURNAMENT=0,SEL_ROULETTE_WHEEL};

enum DEMutationStratgy{DE_rand_1, DE_best_1,DE_targetToBest_1,DE_best_2,DE_rand_2,DE_randToBest_1,DE_targetToRand_1};
enum DistanceMode{DIS_EUCLIDEAN=0,DIS_MANHATTAN,DIS_HAMMING};

enum MigrationMode{Migration_Best=0,Migration_Worst,Migration_Random};
enum MigrationTopology{Migration_Ring=0,Migration_Broadcast};

#endif // STRCUTDEC_H_INCLUDED






// newran.h ------------------------------------------------------------

// NEWRAN02B - 22 July 2002

#ifndef NEWRAN_LIB
#define NEWRAN_LIB 0

//******************* utilities and definitions *************************




#ifdef use_namespace
namespace NEWRAN { using namespace RBD_COMMON; }
namespace RBD_LIBRARIES { using namespace NEWRAN; }
namespace NEWRAN {
#endif
    
    typedef Real (*PDF)(Real);                // probability density function
    
    Real ln_gamma(Real);                      // log gamma function
    
    //**************** uniform random number generator **********************
    
    
    
    class Random                              // uniform random number generator
    {
        double seed;                    // seed
        //unsigned long iseed;          // for Mother
        Real Buffer[128];               // for mixing random numbers
        Real Raw();                     // unmixed random numbers
        void operator=(const Random&) {}       // private so can't access
        
    public:
        Random(double s);             // set seed (0 < seed < 1)
        double Get();                   // get seed
        virtual Real Next();                   // get new value
        virtual char* Name();                  // identification
        virtual Real Density(Real) const;      // used by PosGen & Asymgen
        Random() {}                            // do nothing
        virtual ~Random() {}                   // make destructors virtual
        virtual ExtReal Mean() const { return 0.5; }
        // mean of distribution
        virtual ExtReal Variance() const { return 1.0/12.0; }
        // variance of distribution
        virtual void tDelete() {}              // delete components of sum
        virtual int nelems() const { return 1; }
        
        
    };
    
    
    //****************** uniform random number generator *********************
    
    class Uniform : public Random
    {
        void operator=(const Uniform&) {}      // private so can't access
        
    public:
        char* Name();                          // identification
        Uniform(double s):Random(s) {}                           // set value
        Real Next() { return Random::Next(); }
        ExtReal Mean() const { return 0.5; }
        ExtReal Variance() const { return 1.0/12.0; }
        Real Density(Real x) const { return (x < 0.0 || x > 1.0) ? 0 : 1.0; }
    };
    
    
    //************************* return constant ******************************
    
    class Constant : public Random
    {
        void operator=(const Constant&) {}     // private so can't access
        Real value;                            // value to be returned
        
    public:
            char* Name();                          // identification
            Constant(Real v) { value=v; }          // set value
            //   Real Next();
            Real Next() { return value; }
            ExtReal Mean() const { return value; }
            ExtReal Variance() const { return 0.0; }
    };
    
    //**************** positive random number generator **********************
    
    class PosGen : public Random              // generate positive rv
    {
        void operator=(const PosGen&) {}       // private so can't access
        
    protected:
            Real xi, *sx, *sfx;
            bool NotReady;
            void Build(bool);                      // called on first call to Next
            
    public:
            char* Name();                          // identification
            PosGen(double s);           // constructor
            ~PosGen();                             // destructor
            Real Next();                           // to get a single new value
            ExtReal Mean() const { return (ExtReal)Missing; }
            ExtReal Variance() const { return (ExtReal)Missing; }
    };
    
    //**************** symmetric random number generator **********************
    
    class SymGen : public PosGen              // generate symmetric rv
    {
        void operator=(const SymGen&) {}       // private so can't access
        
    public:
            SymGen(double s):PosGen(s){};
            char* Name();                          // identification
            Real Next();                           // to get a single new value
    };
    
    //**************** normal random number generator **********************
    
    class Normal : public SymGen              // generate standard normal rv
    {
        void operator=(const Normal&) {}       // private so can't access
        
        Real Nxi, *Nsx, *Nsfx;          // so we need initialise only once
        long count;                     // assume initialised to 0
        
    public:
            char* Name();                          // identification
            Normal(double s);
            ~Normal();
            Real Density(Real) const;              // normal density function
            ExtReal Mean() const { return 0.0; }
            ExtReal Variance() const { return 1.0; }
            Real  NextNonStand(Real rmean,Real rvariance);
    };
    
    //**************** Cauchy random number generator **********************
    
    class Cauchy : public SymGen              // generate standard cauchy rv
    {
        void operator=(const Cauchy&) {}       // private so can't access
        
    public:
            Cauchy(double s):SymGen(s){};
            char* Name();                          // identification
            Real Density(Real) const;              // Cauchy density function
            ExtReal Mean() const { return Indefinite; }
            ExtReal Variance() const { return PlusInfinity; }
            Real NextNonStand(Real rmean,Real rvariance);
    };
    
    //**************** Exponential random number generator **********************
    
    class Exponential : public PosGen         // generate standard exponential rv
    {
        void operator=(const Exponential&) {}  // private so can't access
        
    public:
            Exponential(double s):PosGen(s){};
            char* Name();   // identification
            Real Density(Real) const;              // Exponential density function
            ExtReal Mean() const { return 1.0; }
            ExtReal Variance() const { return 1.0; }
    };
    
    //**************** asymmetric random number generator **********************
    
    class AsymGen : public Random             // generate asymmetric rv
    {
        void operator=(const AsymGen&) {}      // private so can't access
        Real xi, *sx, *sfx; int ic;
        bool NotReady;
        void Build();                          // called on first call to Next
        
    protected:
            Real mode;
            
    public:
            char* Name();                          // identification
            AsymGen(Real,double s);                         // constructor (Real=mode)
            ~AsymGen();                            // destructor
            Real Next();                           // to get a single new value
            ExtReal Mean() const { return (ExtReal)Missing; }
            ExtReal Variance() const { return (ExtReal)Missing; }
    };
    
    class  Levy : public AsymGen{
        void operator=(const Levy&) {}  // private so can't access
        
    public:
            Real sc;
            Levy(Real,double s);
            char* Name();                    // identification
            Real Density(Real) const;              // Levy density function
            ExtReal Mean() const { return Indefinite; }
            ExtReal Variance() const { return Indefinite; }
    };
    
    
#ifdef use_namespace
}
#endif

#endif

// body file: newran.cpp



// newran.cpp -----------------------------------------------------------

// NEWRAN02B - 22 July 2002

#define WANT_STREAM
#define WANT_MATH
#ifdef use_namespace
namespace NEWRAN {
#endif
    
    
    
    //**************************** utilities ******************************
    inline Real square(Real x) { return x*x; }
    inline ExtReal square(const ExtReal& x) { return x*x; }
    
    static void ErrorNoSpace() { Throw(Bad_alloc("Newran: out of space")); }
    
    //************************* end of definitions ************************
    
    
    Real Random::Raw()                           // get new uniform random number
    {
        // m = 2147483647 = 2^31 - 1; a = 16807;
        // 127773 = m div a; 2836 = m mod a
        long iseed = (long)seed;
        long hi = iseed / 127773L;                 // integer division
        long lo = iseed - hi * 127773L;            // modulo
        iseed = 16807 * lo - 2836 * hi;
        if (iseed <= 0) iseed += 2147483647L;
        seed = (double)iseed; return seed*4.656612875e-10;
    }
    
    Real Random::Density(Real) const
    { Throw(Logic_error("density function not defined")); return 0.0; }
    
#ifdef _MSC_VER
    static void DoNothing(int) {}
#endif
    
    Real Random::Next()                          // get new mixed random number
    {
        if (!seed)
            Throw(Logic_error("Random number generator not initialised"));
        int i = (int)(Raw()*128);               // 0 <= i < 128
#ifdef _MSC_VER
        DoNothing(i); DoNothing(i);
#endif
        Real f = Buffer[i]; Buffer[i] = Raw();  // Microsoft release gets this wrong
        return f;
        
        // return Mother(&iseed);
    }
    
    double Random::Get()                  // get random number seed
    { return seed/2147483648UL; }
    
    Random::Random(double s)            // set random number seed
    // s must be between 0 and 1
    {
        if (s>=1.0 || s<=0.0)
            Throw(Logic_error("Newran: seed out of range"));
        //iseed = 2147483648L * s;         // for Mother
        seed = (long)(s*2147483648UL);
        for (int i = 0; i<128; i++) Buffer[i] = Raw();
    }
    
    
    PosGen::PosGen(double s):Random(s)                             // Constructor
    {
#ifdef MONITOR
        cout << "constructing PosGen\n";
#endif
        NotReady=true;
    }
    
    PosGen::~PosGen()
    {
        if (!NotReady)
        {
#ifdef MONITOR
            cout << "freeing PosGen arrays\n";
#endif
            delete [] sx; delete [] sfx;
        }
#ifdef MONITOR
        cout << "destructing PosGen\n";
#endif
    }
    
    void PosGen::Build(bool sym)                 // set up arrays
    {
#ifdef MONITOR
        cout << "building PosGen arrays\n";
#endif
        int i;
        NotReady=false;
        sx=new Real[60]; sfx=new Real[60];
        if (!sx || !sfx) ErrorNoSpace();
        Real sxi=0.0; Real inc = sym ? 0.01 : 0.02;
        for (i=0; i<60; i++)
        {
            sx[i]=sxi; Real f1=Density(sxi); sfx[i]=f1;
            if (f1<=0.0) goto L20;
            sxi+=inc/f1;
        }
        Throw(Runtime_error("Newran: area too large"));
        L20:
            if (i<50) Throw(Runtime_error("Newran: area too small"));
            xi = sym ? 2*i : i;
            return;
    }
    
    Real PosGen::Next()
    {
        Real ak,y; int ir;
        if (NotReady) Build(false);
        do
        {
            Real r1=Random::Next();
            ir = (int)(r1*xi); Real sxi=sx[ir];
            ak=sxi+(sx[ir+1]-sxi)*Random::Next();
            y=sfx[ir]*Random::Next();
        }
        while ( y>=sfx[ir+1] && y>=Density(ak) );
        return ak;
    }
    
    Real SymGen::Next()
    {
        Real s,ak,y; int ir;
        if (NotReady) Build(true);
        do
        {
            s=1.0;
            Real r1=Random::Next();
            if (r1>0.5) { s=-1.0; r1=1.0-r1; }
            ir = (int)(r1*xi); Real sxi=sx[ir];
            ak=sxi+(sx[ir+1]-sxi)*Random::Next();
            y=sfx[ir]*Random::Next();
        }
        while ( y>=sfx[ir+1] && y>=Density(ak) );
        return s*ak;
    }
    
    AsymGen::AsymGen(Real modex,double s):Random(s)                 // Constructor
    {
#ifdef MONITOR
        cout << "constructing AsymGen\n";
#endif
        mode=modex; NotReady=true;
    }
    
    void AsymGen::Build()                        // set up arrays
    {
#ifdef MONITOR
        cout << "building AsymGen arrays\n";
#endif
        int i;
        NotReady=false;
        sx=new Real[121]; sfx=new Real[121];
        if (!sx || !sfx)  ErrorNoSpace();
        Real sxi=mode;
        for (i=0; i<120; i++)
        {
            sx[i]=sxi; Real f1=Density(sxi); sfx[i]=f1;
            if (f1<=0.0) goto L20;
            sxi+=0.01/f1;
        }
        Throw(Runtime_error("Newran: area too large (a)"));
        L20:
            ic=i-1; sx[120]=sxi; sfx[120]=0.0;
            sxi=mode;
            for (; i<120; i++)
            {
                sx[i]=sxi; Real f1=Density(sxi); sfx[i]=f1;
                if (f1<=0.0) goto L30;
                sxi-=0.01/f1;
            }
            Throw(Runtime_error("Newran: area too large (b)"));
            L30:
                if (i<100)  Throw(Runtime_error("Newran: area too small"));
                xi=i;
                return;
    }
    
    Real AsymGen::Next()
    {
        Real ak,y; int ir1;
        if (NotReady) Build();
        do
        {
            Real r1=Random::Next();
            int ir=(int)(r1*xi); Real sxi=sx[ir];
            ir1 = (ir==ic) ? 120 : ir+1;
            ak=sxi+(sx[ir1]-sxi)*Random::Next();
            y=sfx[ir]*Random::Next();
        }
        while ( y>=sfx[ir1] && y>=Density(ak) );
        return ak;
    }
    
    AsymGen::~AsymGen()
    {
        if (!NotReady)
        {
#ifdef MONITOR
            cout << "freeing AsymGen arrays\n";
#endif
            delete [] sx; delete [] sfx;
        }
#ifdef MONITOR
        cout << "destructing AsymGen\n";
#endif
    }
    
    Normal::Normal(double s):SymGen(s),count(0)
    {
        if (count) { NotReady=false; xi=Nxi; sx=Nsx; sfx=Nsfx; }
        else { Build(true); Nxi=xi; Nsx=sx; Nsfx=sfx; }
        count++;
    }
    
    Normal::~Normal()
    {
        count--;
        if (count) NotReady=true;                     // disable freeing arrays
    }
    
    Real Normal::Density(Real x) const               // normal density
    { return (fabs(x)>8.0) ? 0 : 0.398942280 * exp(-x*x / 2); }
    
    Real  Normal::NextNonStand(Real rmean,Real rvariance){
        
        Real X = Next();
        Real stddev = sqrt( rvariance );
        
        return rmean + stddev * X;
    }
    
    Real Cauchy::Density(Real x) const               // Cauchy density function
    { return (fabs(x)>1.0e15) ? 0 : 0.31830988618 / (1.0+x*x); }
    
    Real  Cauchy::NextNonStand(Real rmean,Real rvariance){
        
        Real X = Next();
        Real stddev = sqrt( rvariance );
        
        return rmean + stddev * X;
    }
    
    Real Exponential::Density(Real x) const          // Negative exponential
    { return  (x > 40.0 || x < 0.0) ? 0.0 : exp(-x); }
    
    
    // Identification routines for each class - may not work on all compilers?
    
    char* Random::Name()            { return (char*)"Random";           }
    char* Uniform::Name()           { return (char*)"Uniform";          }
    char* Constant::Name()          { return (char*)"Constant";         }
    char* PosGen::Name()            { return (char*)"PosGen";           }
    char* SymGen::Name()            { return (char*)"SymGen";           }
    char* AsymGen::Name()           { return (char*)"AsymGen";          }
    char* Normal::Name()            { return (char*)"Normal";           }
    char* Cauchy::Name()            { return (char*)"Cauchy";           }
    char* Exponential::Name()       { return (char*)"Exponential";      }
    char* Levy::Name()		{ return (char*)"Levy";      }
    
    
    Levy::Levy(Real c,double s):AsymGen(c/3,s){
        sc=c;
    }
    Real Levy::Density(Real x) const{
        if(x<=0.0) return 0.0;
        Real y;
        y=sqrt(0.5*sc/3.14159265358979323846)*exp(-0.5*sc/x)/pow(x,1.5);
        return (fabs(x)>1.0e15) ? 0 :y;
    }
    
    
    
#ifdef use_namespace
}
#endif




extern  string gProName[],gAlgName[];
extern map<string, ProblemTag>gProblem;
extern map<string, AlgorithmTag>gAlgorithm;
extern bool **gAlgPro;


using namespace std;

class Problem{
public:
            char ma_name[MAX_NAME_LENGTH+1];
            stringstream m_proPar;
protected:
            /// problem ID
            int m_id;
            int m_dimNumber;
            
            Compare m_problemType;
            Encoding  m_encoding;
            ProCategory m_cat;
            
            //warning: take care this varibale, the memory will be allocate when the problem is instantiated
            void **m_searchRange;
            
            int m_evals;
            int m_objectives;
            int m_objIdx;				// current objective index
            double *mp_bestSoFar;						// TODU :here only for single objective problem
public:
            Problem();
            Problem(const int rId, const int rDimNumber,const  Encoding rEncoding, const ProCategory rCat, char *rName=0);
            /// can not be instantiate
            virtual ~Problem()=0;
            
            Problem& operator=(const Problem & rP);
            
            int getId() const{
                return m_id;
            };
            int getDimNumber() const{
                return m_dimNumber;
            };
            Compare getProblemType() const{
                return m_problemType;
            };
            Encoding getEncoding() const{
                return  m_encoding;
            };
            ProCategory getProblemCat()const{
                return m_cat;
            };
            
            int getEvaluations() const{
                return m_evals;
            };
            int getObjIndex() const{
                return m_objIdx;
            }
            void setObjIndex(const int idx){
                m_objIdx=idx;
            }
            void setObjNumber(const int ObjNum){
                m_objectives=ObjNum;
            }
            void resetEvaluations(){
                m_evals=0;
            }
            double getBestSolutionSoFar(const int objIdx=0){
                
                return mp_bestSoFar[objIdx];
            }
            template<typename T>
                    void setSearchRange(const T rLower, const T rUpper){
                for(int i=0;i<m_dimNumber;i++)
                    ( (Boundary<T> *) m_searchRange[i])->setBoundary(rLower,rUpper);
            }
            template<typename T>
                    void setSearchRange(const T *const rLower, const T * const rUpper){
                if(sizeof(rLower)/(sizeof(T))!=m_dimNumber||sizeof(rUpper)/(sizeof(T))!=m_dimNumber){
                    Throw(Out_of_range("the number of dimensions must be ....."));
                    exit(0);
                }
                for(int i=0;i<m_dimNumber;i++)     ( (Boundary<T> *) m_searchRange[i])->setBoundary(rLower[i],rUpper[i]);
            }
            template<typename T>
                    void getSearchRange(T &rLower, T &rUpper, const int rD){
                rLower=((Boundary<T> *) m_searchRange[rD])->lower;
                
                rUpper=( (Boundary<T> *) m_searchRange[rD])->upper;
            }
            template<typename T>
                    bool getBoundaryFlag(const int rD){
                return ((Boundary<T> *) m_searchRange[rD])->m_flag;
            }
            void setProblemType(const Compare rT){
                m_problemType=rT;
            }
            
            int getObjectives(){ return m_objectives;}
            virtual double evaluate( double const *s, bool rFlag=true ){return 0.;}
            virtual double evaluate( bool const  *s, bool rFlag=true ){return 0.;}
            virtual bool getObjGlobalOpt(double *rObj, int rNumObj=1){ return false;}
            virtual void reset(){}
protected:
    virtual void  freeMemory();
    void allocateMemory(int const rDim);
    virtual void parameterSetting(Problem * rDP);
    void setEvaluations(int value);
    void increaseEvaluations();
    
};



class Algorithm;


template<typename T> Problem * createFunction( int rId,  int rDimNumber, char *rName) {
    return new T( rId,  rDimNumber, rName);
}
typedef map<string, Problem * (*)( int rId,  int rDimNumber, char *rName) > BasicFunc;



class Global
{
public:
    static int  g_dimNumber;                       // number of dimensions: could be number of nodes in TSP, number of items in Knapsack problem
    
    static Cauchy *gp_cauchyPro;							// cauchy random number for algorithm
    static Normal *gp_normalPro;							// gaussian random number for algorithm
    static Uniform *gp_uniformPro;							// random number of uniform distribution for algorithm
    static Levy *gp_levyPro;
    //Chenyang Bu <23/1/2015>
    static Cauchy *mfr_gp_cauchyPro;							// cauchy random number for algorithm
    static Normal *mfr_gp_normalPro;							// gaussian random number for algorithm
    static Uniform *mfr_gp_uniformPro;							// random number of uniform distribution for algorithm
    static Levy *mfr_gp_levyPro;
    //end of Chenyang Bu
    static Cauchy *gp_cauchyAlg;							// cauchy random number for algorithm
    static Normal *gp_normalAlg;							// gaussian random number for algorithm
    static Uniform *gp_uniformAlg;							// random number of uniform distribution for algorithm
    static Levy *gp_levyAlg;
    
    static ProblemTag g_proNumber;                          // Problem no.
    static AlgorithmTag g_algNumber;                        // algorithm no.
    static Problem *gp_problem;                             // global pointer to the problem to be solved
    
    static Algorithm* gp_algorithm;                           // global pointer to the algorithm
    
    static float g_sigma;                                   // temporal varible
    
    static int g_tEvals;                                     // total fitness evaluations for a single run
    static int g_numRuns;                                    //  the number of runs
    static int g_changeFre;                                  // the number of fitness evals during a single change, which is equal to g_tEvals for static optimization problems
    static int g_sampleFre;                                 // the frequency to record an results for an algorithm's performance evaluation
    static int g_runIdx;                                    // the indx of current run
    
    static int g_gPopsize;                                   // the global population size
    static int g_subSize;                                   // the  size of sub-populations
    static float g_overlapDegree;                             // for multi-population methods in DOPs
    
    static float g_diversityDegree;                         // for CPSOR algorithm
    
};
void gInitializeRandomArray(int * a,const int &dim,const bool mode=true);	// generate a set of radom numbers from 0-(dim-1) without repeat
int gSign(const double x);
int gRandInt(const int min, const int max,const bool mode=true);
double gRandFloat(const double min, const double max,const bool mode=true);
void gDeleteRandAlg();
void gDeleteRandPro();
void gCreateRandAlg(double seed);
void gCreateRandPro(double seed);
bool gIsTerminate();
bool gIsDynamicAlg();
template <class T>
        void gCopy(T* destination, const T* source,const int  dim){
    //copy function
    if(destination==source) return;
    for(int i=0;i<dim;i++)
        destination[i]=const_cast<T*>(source)[i];
}
template <class T>
        void gCopy(vector<T> destination,  vector<T>  source,const int  dim){
    //copy function
    for(int i=0;i<dim;i++)
        destination[i]=source[i];
}

inline double gChaoticValue(const double x, const double min, const double max, const double rChaoticConstant=1.0){
    // return a value calculated by logistics function
    if(min>max) return -1;
    double chaotic_value;
    chaotic_value=(x-min)/(max-min);
    chaotic_value=rChaoticConstant*chaotic_value*(1-chaotic_value);
    return min+chaotic_value*(max-min);
    
}
template <class T>
        T gExtremum(T * v,const int size,const Compare type){
    // return min or max value of set V
    T extreme;
    extreme=v[0];
    int index=0;
    if(type==MAX_OPT){
        for(int i=1;i<size;i++){
            if(v[i]>extreme) {
                extreme=v[i];
                index=i;
            }
        }
    }
    else if(type==MIN_OPT){
        for(int i=1;i<size;i++){
            if(v[i]<extreme) {
                extreme=v[i];
                index=i;
            }
        }
    }
    return extreme;
}

template <class T>
        int gPartition(int low,int high,T arr[])
{
    T high_vac,low_vac,pivot;
    pivot=arr[low];
    while(high>low){
        high_vac=arr[high];
        
        while(pivot<=high_vac){
            if(high<=low) break;
            high--;
            high_vac=arr[high];
        }
        
        arr[low]=high_vac;
        low_vac=arr[low];
        while(pivot>=low_vac){
            if(high<=low) break;
            low++;
            low_vac=arr[low];
        }
        arr[high]=low_vac;
    }
    arr[low]=pivot;
    
    return low;
}
template <class T>
        void gQuickSort(int low,int high,T arr[])
{
    int Piv_index;
    if(low<high){
        Piv_index=gPartition(low,high,arr);
        gQuickSort(low,Piv_index-1,arr);
        gQuickSort(Piv_index+1,high,arr);
    }
}

template<class T>
        void gQuickSort(const T &data,int *index, int i, int j){
    
    if (i>=j) return;
    int left = i+1;
    int right = j;
    int pivot=i;
    
    while(left<right){
        while(data[index[left]]<data[index[pivot]]&& left<right)         left++;
        while(data[index[right]]>=data[index[pivot]]&&left<right)          right--;
        
        if(left<right){
            int t=index[left];
            index[left]=index[right];
            index[right]=t;
        }
    }
    
    if(data[index[left]]>data[index[pivot]])  left--;
    
    if(data[index[left]]<data[index[pivot]]){
        int t=index[left];
        index[left]=index[pivot];
        index[pivot]=t;
    }
    
    pivot=left;
    
    gQuickSort(data, index, i, pivot-1);
    gQuickSort(data, index, pivot+1, j);
}
template<class T>
        int gFind(T * data, T item, const int size){
    int i=0;
    for(i=0;i<size;i++){
        if(data[i]==item){
            return i;
        }
    }
    return -1;
}









/// Add problems here. Note: the orders must be same as appeared in ProblemTag in StructDec.h
string gProName[]={
    "Sphere","Sphere_Noisy","S_Sphere","R_Sphere","RS_Sphere","S_Sphere_CEC05", "Sphere_Noisy_CEC05"
            ,"Rastrigin","Rastrigin_Noisy","S_Rastrigin","R_Rastrigin","RS_Rastrigin","S_Rastrigin_CEC05","RS_Rastrigin_CEC05"
            ,"Weierstrass","RS_Weierstrass","R_Weierstrass","RS_Weierstrass_CEC05"
            ,"Griewank","R_Griewank","RS_Griewank", "RS_Griewank_noBounds_CEC05", "Griewank_Rosenbrock_F13_CEC05", "S_Griewank_Rosenbrock_F13_CEC05"
            ,"Ackley","Ackley_Noisy","S_Ackley","R_Ackley","RS_Ackley","RS_Ackley_Bound_CEC05"
            ,"Step"
            ,"Quartic_Noisy"
            ,"Scaffer_F6", "Expanded_Scaffer_F6_CEC05", "Noncont_Expanded_Scaffer_F6_CEC05", "RS_Expanded_Scaffer_F6_CEC05"
            ,"Rosenbrock","S_Rosenbrock","S_Rosenbrock_CEC05"
            ,"Schwefel_2_13_CEC05"
            ,"Schwefel_2_22","Schwefel_2_22_Noisy","S_Schwefel_2_22","R_Schwefel_2_22","RS_Schwefel_2_22"
            ,"Schwefel","Schwefel_Noisy","S_Schwefel","R_Schwefel","RS_Schwefel"
            ,"Schwefel_1_2","Schwefel_1_2_Noisy","S_Schwefel_1_2","S_Schwefel_1_2_Noisy","R_Schwefel_1_2","RS_Schwefel_1_2", "S_Schwefel_1_2_CEC05", "S_Schwefel_1_2_Noisy_CEC05"
            ,"Schwefel_2_21"
            ,"Schwefel_2_6_Bound_CEC05"
            ,"Penalized_1"
            ,"Penalized_2"
            ,"Noncont_Rastrigin"
            ,"RS_Elliptic_CEC05","Elliptic"
            ,"Com","R_Com","Com_CEC05","H_Com_CEC05","H_Com_Noisy_CEC05"
            ,"RH_Com_CEC05","RH_Com_NarrowBasin_CEC05","RH_Com_Bound_CEC05"
            ,"RH_Com_F21_CEC05", "RH_Com_HighConNumMatrix_F22_CEC05", "Noncont_RH_Com_F23_CEC05", "RH_Com_F24_CEC05", "RH_Com_noBounds_F25_CEC05"
            ,"M_global1","M_global2","M_global3","M_global4","M_global5"
            ,"S_Sphere_CEC08","Schwefel_2_21_CEC08","S_Rosenbrock_CEC08","S_Rastrigin_CEC08","S_Griewank_CEC08","S_Ackley_CEC08"
            ,"RW_Gear_Train","RW_ParEst_FMSoundWaves"
            ,"CompositionDBG_DOP","RotationDBG_DOP","MovingPeak_DOP","DF1_DOP","Binary_DOP"};
            
            /// Add new algorithms here. Note: the orders must be same as appeared in AlgorithmTag in StructDec.h
            string gAlgName[]={
                //PSO
                "SPSO","SPSO07","SLPSO","APSO","CPSOH",
                //DE
                "SDE","CRDE",
                //GA
                "SGA_REAL",
                //dynamic optimization
                "CPSO", "CPSOR","CDER","ESCA","SPSO_Parrott","rSPSO","mCPSO","mQSO","PSO_CP","HmSO","SOS","DynDE",
                "CPSORL","CPSORC","mPSO","mDE","CPSOD",
                //Ming_DE
                "Ming_DE", "SaPDE", "JADE",  "jDE", "SaDE", "dynNPDE", "cDE",
                //CMAES
                "CMAES",
                "CLPSO",
                "HRCGA"
            };
            
            map<string, ProblemTag>gProblem;
            map<string, AlgorithmTag>gAlgorithm;
            bool **gAlgPro;
            
            BasicFunc gFunctionInstance;
            
            int  Global::g_dimNumber;
            
            Cauchy *Global::gp_cauchyPro;
            Normal *Global::gp_normalPro;
            Uniform *Global::gp_uniformPro;
            Levy *Global::gp_levyPro;
            //Chenyang Bu
            Cauchy *Global::mfr_gp_cauchyPro;
            Normal *Global::mfr_gp_normalPro;
            Uniform *Global::mfr_gp_uniformPro;
            Levy *Global::mfr_gp_levyPro;
            //end of Chenyang Bu
            Cauchy *Global::gp_cauchyAlg;
            Normal *Global::gp_normalAlg;
            Uniform *Global::gp_uniformAlg;
            Levy *Global::gp_levyAlg;
            
            ProblemTag Global::g_proNumber;
            AlgorithmTag  Global::g_algNumber;
            Problem *Global::gp_problem=0;
            Algorithm *Global::gp_algorithm=0;
            
            float Global::g_sigma=0.0001;
            
            int Global::g_numRuns;
            int Global::g_tEvals;
            int Global::g_changeFre;
            int Global::g_sampleFre;
            int Global::g_runIdx=0;
            
            int Global::g_gPopsize=10;
            int Global::g_subSize;
            float Global::g_overlapDegree;
            float Global::g_diversityDegree;
            
            
#ifdef DEMON_EALIB
            extern bool g_computThrdTermination;
#endif
            void gInitializeRandomArray(int * a,const int &dim,const bool mode){
                int * temp=new int[dim];
                for(int i=0;i<dim;i++)	temp[i]=i;
                int d=dim;
                for(int i=0;i<dim;i++){
                    int t;
                    if(mode)t=	(int)(d*Global::gp_uniformAlg->Next());
                    else t=	(int)(d*Global::mfr_gp_uniformPro->Next());
                    a[i]=temp[t];
                    for(int k=t;k<d-1;k++)
                        temp[k]=temp[k+1];
                    d--;
                }
                delete []temp;
            }
            
            int gSign(const double x){
                if(x>0) return 1;
                else if(x<0) return -1;
                else return 0;
            }
            
            int gRandInt( const int min, const int max,const bool mode){
                if(mode)
                    return static_cast<int>(min+(max-min)*Global::gp_uniformAlg->Next());
                else
                    return static_cast<int>(min+(max-min)*Global::gp_uniformPro->Next());
            }
            double gRandFloat(const double min, const double max,const bool mode){
                if(mode)
                    return min+(max-min)*Global::gp_uniformAlg->Next();
                else
                    return min+(max-min)*Global::gp_uniformPro->Next();
                
            }
            void gCreateRandPro(double seed){
                
                Global::gp_cauchyPro=new Cauchy(seed);
                Global::gp_normalPro=new Normal(seed);
                Global::gp_uniformPro=new Uniform(seed);
                Global::gp_levyPro=new Levy(1.4,seed);
                //Chenyang Bu
                Global::mfr_gp_cauchyPro=new Cauchy(1.-seed);
                Global::mfr_gp_normalPro=new Normal(1.-seed);
                Global::mfr_gp_uniformPro=new Uniform(1.-seed);
                Global::mfr_gp_levyPro=new Levy(1.4,1.-seed);
                //end of Chenyang Bu
            }
            void gCreateRandAlg(double seed){
                
                Global::gp_cauchyAlg=new Cauchy(seed);
                Global::gp_normalAlg=new Normal(seed);
                Global::gp_uniformAlg=new Uniform(seed);
                Global::gp_levyAlg=new Levy(1.4,seed);;
                
            }
            void gDeleteRandPro(){
                
                if(Global::gp_cauchyPro ){delete  Global::gp_cauchyPro; Global::gp_cauchyPro=0;}
                if(Global::gp_normalPro) {delete 	Global::gp_normalPro; Global::gp_normalPro=0;}
                if(Global::gp_uniformPro){delete 	Global::gp_uniformPro; Global::gp_uniformPro=0;}
                if(	Global::gp_levyPro){delete 	Global::gp_levyPro; 	Global::gp_levyPro=0;}
                delete Global::mfr_gp_cauchyPro;
                delete Global::mfr_gp_normalPro;
                delete Global::mfr_gp_uniformPro;
                delete Global::mfr_gp_levyPro;
                
                Global::mfr_gp_cauchyPro=0;
                Global::mfr_gp_normalPro=0;
                Global::mfr_gp_uniformPro=0;
                Global::mfr_gp_levyPro=0;
                
            }
            
            
            void gDeleteRandAlg(){
                
                if(Global::gp_cauchyAlg){delete 	Global::gp_cauchyAlg; Global::gp_cauchyAlg=0;}
                if( Global::gp_normalAlg){delete 	Global::gp_normalAlg; Global::gp_normalAlg=0;}
                if(	Global::gp_uniformAlg){delete 	Global::gp_uniformAlg; 	Global::gp_uniformAlg=0;}
                if(Global::gp_levyAlg){delete 	Global::gp_levyAlg; Global::gp_levyAlg=0;}
            }
            
            bool gIsTerminate(){
#ifdef EALIB
                if(Global::gp_problem->getEvaluations()>=Global::g_tEvals) return true;
                else return false;
#endif
                
#ifdef DEMON_EALIB
                if(g_computThrdTermination) return true;
                else return false;
#endif
            }
            
            
            
            
            
            Problem::Problem():m_searchRange(0),m_evals(0),m_objectives(0){
                //ctor
                ma_name[0]='\0';
                m_id=-1;
                m_dimNumber=-1;
                mp_bestSoFar=0;
                
            }
            Problem::Problem(const int rId, const int rDimNumber,const  Encoding rEncoding, const ProCategory rCat, char *rName):m_id(rId),
                    m_dimNumber(rDimNumber),m_problemType(MIN_OPT),m_encoding(rEncoding),m_cat(rCat),m_evals(0),m_objectives(1),m_objIdx(0){
                
                //m_searchRange=new void* [m_dimNumber];
                if(rName!=0){
                    if(strlen(rName)<=MAX_NAME_LENGTH){
                        strcpy(ma_name,rName);
                    }else{
                        Throw(Length_error(rName));
                        exit(0);
                        
                    }
                    
                }else{
                    
                    ma_name[0]='\0';
                }
                Global::g_dimNumber=rDimNumber;
                
                allocateMemory(rDimNumber);
                
                //  m_proPar<<"Dimension:"<<m_dimNumber<<"; ";
                
            }
            void Problem::allocateMemory(int const rDim){
                m_searchRange=new void* [rDim];
                mp_bestSoFar=new double[m_objectives];
            }
            Problem::~Problem()
            {
                //dtor
                freeMemory();
            }
            
            void Problem::freeMemory(){
                delete []  m_searchRange;
                m_searchRange=0;
                delete [] mp_bestSoFar;
                mp_bestSoFar=0;
            }
            
            Problem& Problem::operator=(const Problem & rP){
                if(this== &rP) return *this;
                
                m_id=rP.m_id;
                
                m_encoding=rP.m_encoding;
                m_cat=rP.m_cat;
                m_problemType=rP.m_problemType;
                m_evals=rP.m_evals;
                m_objectives=rP.m_objectives;
                m_objIdx=rP.m_objIdx;
                
                if(m_dimNumber!=rP.m_dimNumber) {
                    delete[] m_searchRange;
                    m_dimNumber=rP.m_dimNumber;
                    m_searchRange=new void* [m_dimNumber];
                }
                
                
                strcpy(ma_name,rP.ma_name);
                
                gCopy<double>(mp_bestSoFar,rP.mp_bestSoFar,m_objectives);
                return *this;
            }
            void Problem::parameterSetting(Problem * rP){
                
                m_id=rP->m_id;
                
                m_encoding=rP->m_encoding;
                m_cat=rP->m_cat;
                m_problemType=rP->m_problemType;
                m_evals=rP->m_evals;
                m_objectives=rP->m_objectives;
                m_objIdx=rP->m_objIdx;
                gCopy<double>(mp_bestSoFar,rP->mp_bestSoFar,m_objectives);
                
            }
            
            void Problem::setEvaluations(int value){
                this->m_evals=value;
            }
            
            
            
            class DynamicProblem : public Problem
            {
            protected:
                
                int m_changeFre;
                SChangeType m_changeType;
                
                int m_period;					// definite period for values repeating
                int m_changeCounter;				// counter of number of changes
                float m_noisySeverity;		// deviation servity from the trajactory of recurrent change
                bool m_flagDimensionChange;			// flag=true, the number of dimensions change, otherwise no change,  default value is false
                bool m_dirDimensionChange;			// direction of change, dir=true means increasing the dimension, otherwise decrease it
                bool m_synchronize;                 // default=true all dimensions change at the same time
                
                int m_dimNumberTemp;                //a temporal variable for dimensional change only
                
                int m_numPeaks;
                bool m_flagNumPeaksChange;                  // flag of the change of the number of peaks
                bool m_dirNumPeaksChange;                   // true for increasing the number of peaks, otherwise decreasing the number of peaks
                int m_numPeaksTemp;                         // temporal varibal for number of peaks change only
                
                
                static const unsigned int msc_MaxDimensionNumber=32;
                static const unsigned int msc_MinDimensionNumber=2;     //should be greater than 1
                static const unsigned int msc_MaxNumPeaks=50;
                static const unsigned int msc_MinNumPeaks=1;
                
                float m_alpha, m_maxAlpha;              // to control step severity
                float m_chaoticConstant;
                int m_maxChangeNumber;                  // the number of the maximum changes during one run
                
                void setDimensionChange(const bool rFlag);
                void setChangeDirction(const bool rFlag);
                
            public:
                static int msc_NumChangeTypies;
                
                
                DynamicProblem(const int rId, const int rDimNumber, const Encoding rEncoding,const int rNumPeaks);
                virtual ~DynamicProblem()=0;
                
                DynamicProblem & operator=(const DynamicProblem & rDP);
                
                void setChangeFre(const int rChangeFre);
                virtual bool setPeriod(const int rPeriod);
                void setChangeType(const SChangeType &rChangeType);
                void setChangeType(const ChangeType rT);
                void setNumPeaksChange(const bool rPC);
                void setSynchronize(const bool rFlag);
                void setNoisySeverity(const float rSeverity);
                void setMaxChangeNumber(const int rMaxChangeNum);
                void setAlpha(const float rAlpha){
                    m_alpha=rAlpha;
                };
                void setMaxAlpha(const float rMaxAlpha){
                    m_maxAlpha=rMaxAlpha;
                };
                void setChoaticConstant(const float rValue){
                    m_chaoticConstant=rValue;
                }
                
                int getChangeFre()const{
                    return m_changeFre;
                };
                int getChangeCounter()const {
                    return m_changeCounter;
                };
                int getPeriod()const {
                    return m_period;
                }
                ChangeType getChangeType() const{
                    return m_changeType.type;
                };
                bool getFlagDimensionChange() const{
                    return m_flagDimensionChange;
                };
                bool getDirDimensionChange() const{
                    return m_dirDimensionChange;
                };
                bool getFlagSynchronizeChange()const{
                    return m_synchronize;
                };
                int getMaxChangeNumber()const{
                    return m_maxChangeNumber;
                };
                
                int getNumberofPeak()const;
                
                void change();
                double sinValueNoisy(const int x,const double min, const double max, const double amplitude, const double angle,const double noisy_severity=1.,bool flag=false);
                double chaoticStep(const double x, const double min, const double max, const float scale=1.0);
                bool predictChange(const int evalsMore);
            protected:
                virtual void randomChange(){};
                virtual void smallStepChange(){};
                virtual void largeStepChange(){};
                virtual void recurrentChange(){};
                virtual void chaoticChange(){};
                virtual void recurrentNoisyChange(){};
                
                virtual void changeDimension(){};
                virtual void changeNumPeaks(){};
                
                //added by Chenyang Bu <2015/1/23>
                virtual void linearChange(){};
                virtual void cyclicChange(){};
                virtual void decayOscilationChange(){};
                virtual void stochasticChange(){};
                //end of Chenyang Bu
                
                
                virtual void parameterSetting(Problem * rP);
                virtual void  freeMemory(){};
            };
            
            
            
            
            
            int DynamicProblem::msc_NumChangeTypies=8;
            
            DynamicProblem::DynamicProblem(const int rId, const int rDimNumber, const Encoding rEncoding,const int rNumPeaks):Problem(rId,rDimNumber,rEncoding, CAT_DYNAMIC),m_changeCounter(0)
            ,m_dimNumberTemp(rDimNumber),m_numPeaks(rNumPeaks),m_numPeaksTemp(rNumPeaks){
                //ctor
                m_changeFre=5000;
                m_changeType.type=CT_Random;
                m_changeType.counter=0;
                m_period=0;
                m_flagDimensionChange=false;
                m_dirDimensionChange=true;
                m_synchronize=true;
                m_noisySeverity=0.8;
                m_maxChangeNumber=100;
                m_alpha=0.04;
                m_maxAlpha=0.1;
                m_chaoticConstant=3.67; //in [1,4]
                
                m_flagNumPeaksChange=false;
                m_dirNumPeaksChange=true;
                
                //m_proPar<<"Change frequency:"<<m_changeFre<<"; "<<"Peaks:"<<m_numPeaks<<"; "<<"NumPeaksChange:"<<m_dirNumPeaksChange<<"; ";
                
            }
            
            DynamicProblem::~DynamicProblem()
            {
#ifdef Test
                cout<<"~DynamicProblem"<<endl;
#endif
                //dtor
            }
            int DynamicProblem::getNumberofPeak()const{
                return m_numPeaks;
            }
            
            void DynamicProblem::setNumPeaksChange(const bool rPC){
                m_flagNumPeaksChange=rPC;
                /*size_t start, end;
                 * start=m_proPar.str().find("NumPeaksChange:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"NumPeaksChange:"<<m_dirNumPeaksChange<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
            }
            
            void DynamicProblem::setChangeFre(const int rChangeFre){
                if(rChangeFre>0) m_changeFre=rChangeFre;
                else{
                    Throw(Invalid_argument("Change frequncy must be greater than 0"));
                    exit(0);
                }
                
                /* size_t start, end;
                 * start=m_proPar.str().find("Change frequency:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"Change frequency:"<<m_changeFre<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
                
                
            }
            bool DynamicProblem::setPeriod(const int rPeriod){
                if(rPeriod>=0) m_period=rPeriod;
                else{
                    Throw(Invalid_argument("period must be positive"));
                    exit(0);
                }
                return true;
            }
            void DynamicProblem::setChangeType(const SChangeType &rChangeType){
                m_changeType=rChangeType;
            }
            void DynamicProblem::setChangeType(const ChangeType rT){
                m_changeType.type=rT;
            }
            
            void DynamicProblem::setDimensionChange(const bool rFlag){
                m_flagDimensionChange=rFlag;
            }
            
            void DynamicProblem::setChangeDirction(const bool rFlag){
                m_dirDimensionChange=rFlag;
            }
            void DynamicProblem::setSynchronize(const bool rFlag){
                m_synchronize=rFlag;
            }
            
            void DynamicProblem::setNoisySeverity(const float rSeverity){
                
                m_noisySeverity=rSeverity;
            }
            
            void DynamicProblem::setMaxChangeNumber(const int rMaxChangeNum){
                m_maxChangeNumber=rMaxChangeNum;
            }
            
            void DynamicProblem::change(){
                
#ifdef DEMON_EALIB
                double gOpt;
                Global::gp_problem->getObjGlobalOpt(&gOpt);
                g_avgErrSoFar=(g_avgErrSoFar*m_changeCounter+fabs(mp_bestSoFar[0]-gOpt))/(m_changeCounter+1);
#endif
                m_changeCounter++;
                switch(getChangeType()){
                    case CT_Random:
                        randomChange();
                        break;
                    case CT_Recurrent:
                        recurrentChange();
                        break;
                    case CT_RecurrentNoisy:
                        recurrentNoisyChange();
                        break;
                    case CT_SmallStep:
                        smallStepChange();
                        break;
                    case CT_LargeStep:
                        largeStepChange();
                        break;
                    case CT_Chaotic:
                        chaoticChange();
                        break;
                    case CT_Linear:
                        this->linearChange();
                        break;
                    case CT_Cyclic:
                        this->cyclicChange();
                        break;
                    case CT_Decay:
                        this->decayOscilationChange();
                    default :
                        break;
                }
                
                if(m_flagDimensionChange){
                    
                    Global::g_dimNumber=m_dimNumber;
                    if(Global::g_dimNumber==msc_MinDimensionNumber)
                        m_dirDimensionChange=true;
                    if(Global::g_dimNumber==msc_MaxDimensionNumber)
                        m_dirDimensionChange=false;
                    
                    if(m_dirDimensionChange==true) {
                        m_dimNumberTemp++;
                        Global::g_dimNumber++;
                    }
                    else {
                        m_dimNumberTemp--;
                        Global::g_dimNumber--;
                    }
                    changeDimension();
                }
                
                if(m_flagNumPeaksChange){
                    
                    if((unsigned int)m_numPeaks>=msc_MaxNumPeaks-1) m_dirNumPeaksChange=false;
                    
                    if((unsigned int)m_numPeaks<=msc_MinNumPeaks+1) m_dirNumPeaksChange=true;
                    
                    if(m_dirNumPeaksChange==true) m_numPeaksTemp=m_numPeaks+2;
                    else m_numPeaksTemp=m_numPeaks-2;
                    
                    changeNumPeaks();
                }
                
                
                
#ifdef DEMON_EALIB
                calculateSamplePoints();
#endif
                
            }
            
            
            
            DynamicProblem & DynamicProblem::operator=(const DynamicProblem & rDP){
                if(this==&rDP) return *this;
                
                if(m_dimNumber!=rDP.m_dimNumber){
                    Throw(Invalid_argument("The number of dimensions must be same!"));
                    exit(0);
                }
                if(m_changeType.type!=rDP.m_changeType.type){
                    Throw(Invalid_argument("The change type must be same!"));
                    exit(0);
                }
                if(m_numPeaks!=rDP.m_numPeaks){
                    Throw(Invalid_argument("The number of peaks must be same!"));
                    exit(0);
                    
                }
                Problem::operator=(rDP);
                
                
                m_changeType.counter=rDP.m_changeType.counter;
                m_changeFre=rDP.m_changeFre;
                m_period=rDP.m_period;
                m_flagDimensionChange=rDP.m_flagDimensionChange;
                m_dirDimensionChange=rDP.m_dirDimensionChange;
                m_synchronize=rDP.m_synchronize;
                m_noisySeverity=rDP.m_noisySeverity;
                m_maxChangeNumber=rDP.m_maxChangeNumber;
                
                m_alpha =rDP.m_alpha;
                m_maxAlpha= rDP.m_maxAlpha;
                m_chaoticConstant =rDP.m_chaoticConstant;
                
                m_flagNumPeaksChange=rDP.m_flagNumPeaksChange;
                m_dirNumPeaksChange=rDP.m_dirNumPeaksChange;
                
                return *this;
            }
            
            void  DynamicProblem::parameterSetting(Problem * rdp){
                
                Problem::parameterSetting(rdp);
                
                DynamicProblem *rDP=dynamic_cast<DynamicProblem*>(rdp);
                m_changeType=rDP->m_changeType;
                m_changeFre=rDP->m_changeFre;
                m_period=rDP->m_period;
                m_flagDimensionChange=rDP->m_flagDimensionChange;
                m_dirDimensionChange=rDP->m_dirDimensionChange;
                m_synchronize=rDP->m_synchronize;
                m_noisySeverity=rDP->m_noisySeverity;
                m_maxChangeNumber=rDP->m_maxChangeNumber;
                m_alpha =rDP->m_alpha;
                m_maxAlpha= rDP->m_maxAlpha;
                m_chaoticConstant =rDP->m_chaoticConstant;
                
                m_flagNumPeaksChange=rDP->m_flagNumPeaksChange;
                m_dirNumPeaksChange=rDP->m_dirNumPeaksChange;
            }
            
            double DynamicProblem::sinValueNoisy(const int x,const double min, const double max, const double amplitude, const double angle,const double noisy_severity,bool flag){
                // return a value in recurrent with noisy dynamism environment
                double y;
                double noisy,t;
                y=min+amplitude*(sin(2*PI*(x+angle)/m_period)+1)/2.;
                //modified by Chenyang Bu
                if(flag==true){
                    noisy=noisy_severity*Global::mfr_gp_normalPro->Next();
                }
                else{
                    noisy=noisy_severity*Global::gp_normalPro->Next();
                }
                //end
                t=y+noisy;
                if(t>min&&t<max) y=t;
                else y= t-noisy;
                return y;
            }
            
            double DynamicProblem::chaoticStep(const double x, const double min, const double max, const float scale){
                if(min>max) return -1;
                double chaotic_value;
                chaotic_value=(x-min)/(max-min);
                chaotic_value=m_chaoticConstant*chaotic_value*(1-chaotic_value);
                //return fabs((min+chaotic_value*(max-min)-x)* Global::scale);
                return chaotic_value*scale;
            }
            
            bool DynamicProblem::predictChange(const int evalsMore){
                int fre=getChangeFre();
                int evals=getEvaluations()%fre;
                if(evals+evalsMore>=fre) return true;
                else return false;
            }
            
            class DynamicContinuous : public DynamicProblem
            {
            protected:
                double *mp_genes;							// real coded solution
                //       int m_numPeaks;						        // number of peaks in Rotation_DBG , number of function in Composition_DBG
                double **mpp_peak;					    	// positions of local or global optima(local optima in Rotation_DBG,
                double **mpp_prePeak;							// global optima of basic function in Composition_DBG)
                double **mpp_initialPeak;				        // save the initial positions
                double *mp_height;							// peak height in Rotation_DBG, height of global optima in Composition_DBG
                double *mp_width;                           // weight value of each basic function in Composition_DBG,  peak width in Rotation_DBG
                //added by Chenyang Bu <2015/1/23>
                double* mpp_initialHeight;
                double* mpp_initialWidth;
                int* regionIndex;
                int numFeasibleRegions;// the number of disconnected feasible regions
                //end of Chenyang Bu
                ///TODO preHeight and preWidth not considered in current version
                double *mp_preHeight;
                double *mp_preWidth;
                
                
                double m_minHeight,m_maxHeight;		// minimum\maximum height of all peaks(local optima) in Rotation_DBG(Composition_DBG)
                double m_heightSeverity;
                
                double m_minWidth, m_maxWidth;
                double m_widthSeverity;
                
                double *mp_fit;						    	// objective value of each basic funciton in Composition_DBG, peak height in Rotation_DBG
                double m_globalOptima;				    	// global optima value
                bool *mp_globalOptimaIdx;                      // the index of the global optimal peak
                
                int m_currentPeak;                         // the peak where the best individual is located
                int m_maxPeaksNumber;                      // the number of heigthest peaks
                double m_currentBest;                      // the objective value of current best individual
                
                bool *mp_whetherChange;                      // whether peaks change or not
                int m_numChangePeaks;                       // the number of peaks that change
                float m_changePeakRatio;                    // the ratio of changing peaks
                double m_accuracy;                          // the accuracy level
                
                int m_numVisablePeaks;                      // number of visable peaks, a peak is visable only if no peak is no top of it
                
            public:
                DynamicContinuous(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks);
                virtual ~DynamicContinuous()=0;
                
                double getGlobalMax()const;
                virtual bool getObjGlobalOpt(double *rObj, int rNumObj=1);
                void printFun( std::ofstream & out);
                const double * const getPeak(const int p) const;
                const double * const* const getAllPeaks()const;
                double getPeakHeight(const int p)const;
                double getPrePeakHeight(const int p)const;
                double getPrePeakWidth(const int p)const;
                //added by Chenyang Bu Jan 22,2015
                int getNumberOfDisconnectedFeasibleRegions();
                int getRealRegionIndex(int peakID);
                
                double getPeakWidth(const int p)const;
                const double *const getHeight() const;
                const double *const getPrePeak(const int p)const;
                const bool *const getGlobalOptimaIdx()const;
                int getNumberofGlobalOptPeak()const;
                double getAccuracy();
                
                void setNumberofChanges(const int n);
                void setNumberofChanges(const float rRatio);
                
                void setHeightSeverity(const double rS);
                void setWidthSeverity(const double rS);
                DynamicContinuous &operator=(const DynamicContinuous &rDCP);
                
                void setHeight(const double *h);
                void setPosition(const double * const * const p);//const double **p
                virtual void setWidth(const double w);
                void setAccuracy(double rAcc);
                /// for debug mode
                void printPeak( const int rIdx);
                void printPeaks(ofstream & out);
                //added by Chenyang Bu <2015/1/23>
                void printPeaks();
                bool getKnownFlagGOpt();
                int getNumofVisablePeaks();
                bool isVisable(const int rIdx);
                
            protected:
                virtual void randomChange(){};
                virtual void smallStepChange(){};
                virtual void largeStepChange(){};
                virtual void recurrentChange(){};
                virtual void chaoticChange(){};
                virtual void recurrentNoisyChange(){};
                
                virtual void parameterSetting(Problem * rP);
                virtual void  freeMemory();
                virtual void allocateMemory(const int rDimNum, const int rPeaks);
                
                virtual void changeDimension(){};
                virtual void changeNumPeaks(){};
                
                void calculateGlobalOptima();
                void updateNumberofChanges();
                void computeNumVisablePeaks();
                
            };
            
            
            
            
            
            DynamicContinuous::DynamicContinuous(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks):DynamicProblem(rId,rDimNumber,rEncoding, rNumPeaks),m_numChangePeaks(m_numPeaks),m_changePeakRatio(1.0),m_accuracy(0.01){
                
                allocateMemory(m_dimNumber,m_numPeaks);
                for (int i=0; i< m_numPeaks; i++) mp_whetherChange[i]=true;
                //added by Chenyang Bu
                for(int i=0;i<rNumPeaks;i++) this->regionIndex[i]=-1;
                numFeasibleRegions=0;
                //end of Chenyang Bu
            }
            
            DynamicContinuous::~DynamicContinuous(){
#ifdef DEBUG
                cout<<"~DynamicContinuous\n";
#endif
                freeMemory();
            }
            
            void DynamicContinuous::allocateMemory(const int rDimNum, const int rPeaks){
                
                mp_genes = new double[rDimNum];
                mpp_peak = new double*[rPeaks];
                mpp_prePeak= new double*[rPeaks];
                mpp_initialPeak=new double*[rPeaks];
                mp_width=new double[rPeaks];
                mp_height=new double[rPeaks];
                mp_preHeight=new double[rPeaks];
                mp_preWidth=new double[rPeaks];
                mp_fit=new double[rPeaks];
                
                for (int i=0; i< rPeaks; i++){
                    mpp_peak[i]= new double[rDimNum];
                    mpp_prePeak[i]= new double[rDimNum];
                    mpp_initialPeak[i]= new double[rDimNum];
                }
                mp_whetherChange=new bool[rPeaks];
                mp_globalOptimaIdx=new bool[rPeaks];
                
                for(int i=0;i<rDimNum;i++)  m_searchRange[i]=new Boundary<double>();
                //added by Chenyang Bu
                this->mpp_initialHeight=new double[rPeaks];
                this->mpp_initialWidth=new double[rPeaks];
                this->regionIndex=new int[rPeaks];
                //end of Chenyang Bu
            }
            void  DynamicContinuous::freeMemory(){
                delete [] mp_genes;
                for (int i=0; i< m_numPeaks; i++){
                    delete [] mpp_peak[i];
                    delete [] mpp_prePeak[i];
                    delete[] mpp_initialPeak[i];
                    
                }
                delete [] mpp_peak;
                delete [] mpp_prePeak;
                delete[] mpp_initialPeak;
                delete[] mp_height;
                delete[] mp_width;
                delete[] mp_preHeight;
                delete[] mp_preWidth;
                delete[] mp_fit;
                delete [] mp_whetherChange;
                delete [] mp_globalOptimaIdx;
                //added by Chenyang Bu <2015/1/23>
                delete[] this->mpp_initialHeight;
                delete[] this->mpp_initialWidth;
                delete[] this->regionIndex;
                //end
                
                for(int i=0;i<m_dimNumber;i++) delete  (Boundary<double>*) m_searchRange[i];
                
                mp_genes=0;
                mpp_peak=0;
                mpp_prePeak=0;
                mpp_initialPeak=0;
                mp_height=0;
                mp_width=0;
                mp_preHeight=0;
                mp_preWidth=0;
                mp_fit=0;
                mp_whetherChange=0;
                
            }
            
            double DynamicContinuous::getGlobalMax()const{
                return m_globalOptima;
            }
            bool DynamicContinuous::getObjGlobalOpt(double *rObj, int rNumObj){
                *rObj=m_globalOptima;
                return true;
            }
            void DynamicContinuous::printFun(ofstream & out){
                
                for(int i=0;i<m_numPeaks;i++){
                    
                    for(int j=0;j<m_dimNumber;j++)
                        out<<mpp_peak[i][j]<<" ";
                    out<<endl;
                }
            }
            
            const double * const DynamicContinuous::getPeak(const int p)const {
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return mpp_peak[p];
            }
            
            const double * const DynamicContinuous::getPrePeak(const int p) const{
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return  mpp_prePeak[p];
            }
            const double * const * const DynamicContinuous::getAllPeaks()const {
                return  mpp_peak;
            }
            
            double DynamicContinuous::getPeakHeight(const int p)const{
                
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return mp_height[p];
            }
            
            
            double DynamicContinuous::getPrePeakHeight(const int p)const {
                
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return mp_preHeight[p];
                
            }
            double DynamicContinuous::getPrePeakWidth(const int p)const{
                
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return mp_preWidth[p];
            }
            double DynamicContinuous::getPeakWidth(const int p)const{
                if(p<0||p>=m_numPeaks) {
                    Throw(Out_of_range("Please give right value of peak index [0,] "));
                    exit(0);
                }
                return this->mp_width[p];
            }
            const bool * const DynamicContinuous::getGlobalOptimaIdx() const{
                
                return mp_globalOptimaIdx;
            }
            int DynamicContinuous::getNumberofGlobalOptPeak()const{
                return m_maxPeaksNumber;
            }
            
            void DynamicContinuous::setNumberofChanges(const int n){
                if(n<1||n>m_numPeaks) {
                    Throw(Out_of_range("the number of changing peaks is invalid"));
                    exit(0);
                }
                
                m_numChangePeaks=n;
                m_changePeakRatio=n/(float)m_numPeaks;
                updateNumberofChanges();
                
                /* size_t start, end;
                 * start=m_proPar.str().find("Changing peaks ratio:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"Changing peaks ratio:"<<m_changePeakRatio<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
                
            }
            void DynamicContinuous::setNumberofChanges(const float rRatio){
                if(rRatio<0||rRatio>1) {
                    Throw(Out_of_range("the ratio of changing peaks is invalid"));
                    exit(0);
                }
                
                m_changePeakRatio=rRatio;
                m_numChangePeaks=(int)(m_numPeaks*m_changePeakRatio)>1?(int)(m_numPeaks*m_changePeakRatio):1;
                updateNumberofChanges();
                
                /* size_t start, end;
                 * start=m_proPar.str().find("Changing peaks ratio:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"Changing peaks ratio:"<<m_changePeakRatio<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
                
            }
            
            void DynamicContinuous::updateNumberofChanges(){
                if(m_numChangePeaks==m_numPeaks){
                    for(int i=0;i<m_numPeaks;i++) mp_whetherChange[i]=true;
                    return;
                }
                int *a=new int[m_numPeaks];
                
                gInitializeRandomArray(a,m_numPeaks,false);
                
                for(int i=0;i<m_numPeaks;i++) mp_whetherChange[i]=false;
                for(int i=0;i<m_numChangePeaks;i++) mp_whetherChange[a[i]]=true;
                delete []a;
                
            }
            void DynamicContinuous::setHeightSeverity(const double rS){
                m_heightSeverity=rS;
            }
            void DynamicContinuous::setWidthSeverity(const double rS){
                m_widthSeverity=rS;
            }
            DynamicContinuous & DynamicContinuous::operator=(const DynamicContinuous &rDCP){
                if(this==&rDCP) return *this;
                
                if(m_dimNumber!=rDCP.m_dimNumber||m_numPeaks!=rDCP.m_numPeaks) return *this;
                
                DynamicProblem::operator=(rDCP);
                
                gCopy(mp_genes,rDCP.mp_genes,m_dimNumber);
                
                for(int i=0;i<m_numPeaks;i++){
                    gCopy(mpp_peak[i],rDCP.mpp_peak[i],m_dimNumber);
                    gCopy(mpp_prePeak[i],rDCP.mpp_prePeak[i],m_dimNumber);
                    gCopy(mpp_initialPeak[i], rDCP.mpp_initialPeak[i],m_dimNumber);
                    
                }
                gCopy(mp_height,rDCP.mp_height,m_numPeaks);
                gCopy(mp_width,rDCP.mp_width,m_numPeaks);
                gCopy(mp_preHeight,rDCP.mp_preHeight,m_numPeaks);
                gCopy(mp_preWidth,rDCP.mp_preWidth,m_numPeaks);
                gCopy(mp_fit,rDCP.mp_fit,m_numPeaks);
                gCopy(mp_whetherChange,rDCP.mp_whetherChange,m_numPeaks);
                
                //added by Chenyang Bu <2015/1/23>
                gCopy(this->mpp_initialHeight,rDCP.mpp_initialHeight,m_dimNumber);
                gCopy(this->mpp_initialWidth,rDCP.mpp_initialWidth,m_dimNumber);
                gCopy(this->regionIndex,rDCP.regionIndex,m_numPeaks);
                this->numFeasibleRegions=rDCP.numFeasibleRegions;
                //end
                
                m_minHeight=rDCP.m_minHeight;
                m_maxHeight=rDCP.m_maxHeight;
                m_heightSeverity=rDCP.m_heightSeverity;
                
                m_minWidth=rDCP.m_minWidth;
                m_maxWidth=rDCP.m_maxWidth;
                m_widthSeverity=rDCP.m_widthSeverity;
                
                m_globalOptima=rDCP.m_globalOptima;
                gCopy(mp_globalOptimaIdx,rDCP.mp_globalOptimaIdx,m_numPeaks);
                
                
                m_currentBest=rDCP.m_currentBest;
                m_currentPeak=rDCP.m_currentPeak;
                m_maxPeaksNumber=rDCP.m_maxPeaksNumber;
                
                m_numChangePeaks =rDCP.m_numChangePeaks;
                m_changePeakRatio=rDCP.m_changePeakRatio;
                
                m_accuracy=rDCP.m_accuracy;
                
                
                for(int j=0;j<m_dimNumber;j++){
                    ((Boundary<double> *)m_searchRange[j])->setBoundary(((Boundary<double> *)rDCP.m_searchRange[j])->lower,((Boundary<double> *)rDCP.m_searchRange[j])->upper);
                }
                
                
                return *this;
            }
            void DynamicContinuous::parameterSetting(Problem * rP){
                DynamicProblem::parameterSetting(rP);
                
                DynamicContinuous *dcp=static_cast<DynamicContinuous *>(rP);
                
                int dim=m_dimNumberTemp<rP->getDimNumber()?m_dimNumberTemp:rP->getDimNumber();
                
                int peaks=m_numPeaks<dcp->getNumberofPeak()?m_numPeaks:dcp->getNumberofPeak();
                
                for(int i=0;i<peaks;i++){
                    gCopy(mpp_peak[i],dcp->mpp_peak[i],dim);
                    gCopy(mpp_prePeak[i],dcp->mpp_prePeak[i],dim);
                    gCopy(mpp_initialPeak[i], dcp->mpp_initialPeak[i],dim);
                    
                }
                gCopy(mp_height,dcp->mp_height,peaks);
                gCopy(mp_width,dcp->mp_width,peaks);
                gCopy(mp_preHeight,dcp->mp_preHeight,peaks);
                gCopy(mp_preWidth,dcp->mp_preWidth,peaks);
                gCopy(mp_fit,dcp->mp_fit,peaks);
                gCopy(mp_whetherChange,dcp->mp_whetherChange,peaks);
                
                m_minHeight=dcp->m_minHeight;
                m_maxHeight=dcp->m_maxHeight;
                m_heightSeverity=dcp->m_heightSeverity;
                
                m_minWidth=dcp->m_minWidth;
                m_maxWidth=dcp->m_maxWidth;
                m_widthSeverity=dcp->m_widthSeverity;
                
                m_globalOptima=dcp->m_globalOptima;
                gCopy(mp_globalOptimaIdx,dcp->mp_globalOptimaIdx,peaks);
                
                m_currentBest=dcp->m_currentBest;
                m_currentPeak=dcp->m_currentPeak;
                m_maxPeaksNumber=dcp->m_maxPeaksNumber;
                
                m_accuracy=dcp->m_accuracy;
                
                m_changePeakRatio=dcp->m_changePeakRatio;
                m_numChangePeaks =(int)(m_changePeakRatio*peaks)>1?(int)(m_changePeakRatio*peaks):1;//dcp->m_numChangePeaks;
                
                for(int j=0;j<dim;j++){
                    ((Boundary<double> *)m_searchRange[j])->setBoundary(((Boundary<double> *)dcp->m_searchRange[j])->lower,((Boundary<double> *)dcp->m_searchRange[j])->upper);
                }
                
            }
            
            void DynamicContinuous::calculateGlobalOptima(){
                
                /*m_globalOptima=gExtremum(mp_height,m_numPeaks,m_problemType);
                 * m_maxPeaksNumber=0;
                 * for(int i=0;i<m_numPeaks;i++){
                 * mp_globalOptimaIdx[i]=false;
                 * if(mp_height[i]==m_globalOptima){
                 * m_maxPeaksNumber++;
                 * mp_globalOptimaIdx[i]=true;
                 * }
                 * }
                 * computeNumVisablePeaks();*/
            }
            
            void DynamicContinuous::setHeight(const double *h){
                gCopy(mp_height,h,m_numPeaks);
            }
            
            void DynamicContinuous::setPosition(const double * const * const p){
                for(int i=0;i<m_numPeaks;i++){
                    gCopy(mpp_peak[i],p[i],m_dimNumber);
                    gCopy(mpp_initialPeak[i],(p[i]),m_dimNumber);
                }
            }
            const double *const DynamicContinuous::getHeight() const{
                return mp_height;
            }
            void DynamicContinuous::setWidth(const double w){
                for(int i=0;i<m_numPeaks;i++)
                    mp_width[i]=w;
            }
            void DynamicContinuous::printPeak( const int rIdx){
                
                cout<<"the "<<rIdx<<"th peak, height: "<<mp_height[rIdx]<<" position:"<<endl;
                
                for(int i=0;i<m_dimNumber;i++){
                    cout<<mpp_peak[rIdx][i]<<" ";
                }
                cout<<endl;
            }
            void DynamicContinuous::printPeaks(ofstream & out){
                for(int j=0;j<m_numPeaks;j++){
                    out<<"center: ";
                    for(int i=0;i<m_dimNumber;i++){
                        out<<mpp_peak[j][i]<<" ";
                    }
                    out<<"height: "<<mp_height[j]<<"  width: "<<this->mp_width[j]<<endl;
                }
                
            }
            void DynamicContinuous::printPeaks(){
                for(int j=0;j<m_numPeaks;j++){
                    for(int i=0;i<m_dimNumber;i++){
                        cout<<mpp_peak[j][i]<<" ";
                    }
                    cout<<mp_height[j]<<endl;
                }
            }
            void DynamicContinuous::setAccuracy(double rAcc){
                m_accuracy=rAcc;
                
            }
            double DynamicContinuous::getAccuracy(){
                return m_accuracy;
            }
            bool DynamicContinuous::getKnownFlagGOpt(){
                return true;
            }
            
            int DynamicContinuous::getNumofVisablePeaks(){
                return m_numVisablePeaks;
                
            }
            void DynamicContinuous::computeNumVisablePeaks(){
                m_numVisablePeaks=m_numPeaks;
                for(int i=0;i<m_numPeaks;i++){
                    double height=evaluate(mpp_peak[i],false);
                    switch(m_problemType){
                        case MIN_OPT:
                            if(height<mp_height[i]) m_numVisablePeaks--;
                            break;
                        case MAX_OPT:
                            if(height>mp_height[i]) m_numVisablePeaks--;
                            break;
                    }
                }
                
            }
            bool DynamicContinuous::isVisable(const int rIdx){
                
                double height=evaluate(mpp_peak[rIdx],false);
                switch(m_problemType){
                    case MIN_OPT:
                        if(height<mp_height[rIdx]) return false;
                        break;
                    case MAX_OPT:
                        if(height>mp_height[rIdx]) return false;
                        break;
                }
                return true;
                
            }
            int DynamicContinuous::getNumberOfDisconnectedFeasibleRegions(){
                return this->numFeasibleRegions;
            }
            int DynamicContinuous::getRealRegionIndex(int peakID){
                return this->regionIndex[peakID];
            }
            
            
            
            
            class MovingPeak : public DynamicContinuous
            {
            protected:
                int m_F;
                double m_vlength ; /* distance by which the peaks are moved, severity */
                //added by Chenyang Bu
                bool isMFRB;//determine wheter is MFRB or not
                //end by Chenyang Bu
                
                /* lambda determines whether there is a direction of the movement, or whether
                 * they are totally random. For lambda = 1.0 each move has the same direction,
                 * while for lambda = 0.0, each move has a random direction */
                double m_lambda;
                int m_useBasisFunction; /* if set to 1, a   landscape (basis_function) is included in the fitness evaluation */
                int m_calculateRightPeak ; /* saves computation time if not needed and set to 0 */
                double  m_standardHeight;
                /* width chosen randomly when standardwidth = 0.0 */
                double  m_standardWidth;
                
                double *mp_shift;
                int *mp_coveredPeaks;    /* which peaks are covered by the population ? */
                double **mpp_prevMovement;/* to store every peak's previous movement */
                int *mp_isTracked;
                int *mp_heightOrder;
                bool *mp_found;
                int m_peaksFound;
                //added by Chenyang Bu <23/1/2015>
                double par_chaoticChange;
                double ** randArray;
                double * RegionRadius;
                int * RegionRadiusOrder;
                double times;
                double times_con;
                double conHeight;
                int mfr_IDGlobalRegion;
                //end of Chenyang Bu <23/1/2015>
            public://public for matlab version
                MovingPeak(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks, float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                //Chenyang Bu <23/1/2015>
                MovingPeak(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double rTimes_con=4.,const double rTimes_len=2.,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                //end of Chenyang Bu
            public:
                int getGlobalRegion(){
                    return this->mfr_IDGlobalRegion;
                }
                bool readData();
                bool mfr_readData();
                static  MovingPeak *msp_MPs;
                static MovingPeak * msp_MFRs;
                /* the following basis functions are provided :*/
                double constantBasisFunc(double *gen);
                double fivePeakBasisFunc(double *gen);
                /* the following peak functions are provided: */
                double peakFunction1(double *gen, int peak_number);
                double peakFunctionCone (double *gen, int peak_number);
                double peakFunctionHilly (double *gen, int peak_number);
                double peakFunctionTwin (double  *gen, int peak_number);
                double functionSelection(double  *gen, int peak_number);
                double dummyEval (double *gen);
                void initialize();
                void mfr_initialize();
                //added by Chenyang Bu Jan 22, 2015
                void mfr_change();
                void mpb_change();
                void getDisconnectedFeasibleRegions();
                void setGlobalRegion(int peak_number);
                int isInRegion(double *gen){
                    int in=0;
                    for(int i=0;i<this->getNumberofPeak();i++){
                        if(this->isInRegion(gen,i))
                        {
                            in=i;
                            break;
                        }
                    }
                    return in;
                }
                bool isInRegion(double *gen,int peak_number);
                bool isInGlobalRegion(double*gen);
                void set_m_F(int value);
                double& getTimes_con(){
                    return this->times_con;
                }
                double &getTimes_len(){
                    return this->times;
                }
            protected:
                void currentPeakCalc (double *gen);
                virtual void  freeMemory();
                virtual void allocateMemory(const int rDimNum, const int rPeaks);
                virtual void randomChange();
                ///TODO the flowing change types are not implemented
                virtual void smallStepChange(){randomChange();};
                virtual void largeStepChange(){randomChange();};
                virtual void recurrentChange(){randomChange();};
                virtual void chaoticChange();
                virtual void recurrentNoisyChange(){randomChange();};
                virtual void changeDimension(){randomChange();};
                virtual void changeNumPeaks();
                //added by Chenyang Bu <2015/1/23>
                virtual void linearChange();
                virtual void cyclicChange();
                virtual void decayOscilationChange();
                virtual void stochasticChange();
                //end of Chenyang Bu
                void parameterSetting(DynamicProblem * rP);
                
                
            public:
                static  MovingPeak * getMPs();
                //Chenyang Bu<6/3/2015>
                static MovingPeak * getMFRs();
                static void initialize(int rDim, int rPeaks,float const rChangingRatio, const bool rFlagDimChange=false,const bool flagNumPeakChange=false);
                static void initialize(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks, float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                static void initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double rTimes_con=4,const double rTimes_len=2,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                static void deleteMFRs();
                string getRegionRadius();
                double getRegionRadius(int rpeak);
                double distance(double *x1,double*x2);
                //end of Chenyang Bu
                static void deleteMPs();
                static bool isInitialized();
                virtual ~MovingPeak();
                
                virtual double evaluate (double const *gen, bool rFlag=true);
                void changeStepsizeRandom () ;
                void changeStepsizeLinear();
                int getRightPeak();
                void setVlength(const double s);
                void setVlength(const int rtimes, int rpeak);
                void reset();
                //Chenyang Bu
                void mfr_reset();
                double get_conHeight();
                //end of Chenyang Bu
                MovingPeak &operator=(MovingPeak &other);
                int getTrackNumber(int idex);
                bool isTracked(double const *gen);
                int getPeaksFound();
            };
            
            
            
            MovingPeak *MovingPeak::msp_MPs=0;
            MovingPeak *MovingPeak::msp_MFRs=0;
            MovingPeak::MovingPeak(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks){
                this->isMFRB=false;
                m_flagDimensionChange=rFlagDimChange;
                setNumPeaksChange(rFlagNumPeakChange);
                // m_flagNumPeaksChange=rFlagNumPeakChange;
                
                if(!readData()) exit(0);
                m_peaksFound=0;
                
                allocateMemory(m_dimNumber,m_numPeaks);
                strcpy(ma_name,"Moving Peak Benchmark");
                initialize();
                setNumberofChanges((int)(rChangingRatio*m_numPeaks));
                
                //m_proPar<<"Vlength:"<<m_vlength<<"; ";
                
                
            }
            MovingPeak::MovingPeak(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double rTimes_con,const double rTimes_len, float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks){
                this->isMFRB=risMFRB;
                m_flagDimensionChange=rFlagDimChange;
                setNumPeaksChange(rFlagNumPeakChange);
                this->times=rTimes_len;
                this->times_con=rTimes_con;
                this->mfr_IDGlobalRegion=0;
                //this->conHeight=rConHeight;
                // m_flagNumPeaksChange=rFlagNumPeakChange;
                
                if(!this->isMFRB){
                    if(!readData()) exit(0);
                }
                else{
                    if(!this->mfr_readData()) exit(0);
                }
                m_peaksFound=0;
                
                allocateMemory(m_dimNumber,m_numPeaks);
                strcpy(ma_name,"Moving Feasible Regions Benchmark");
                if(this->isMFRB)
                    mfr_initialize();
                else
                    this->initialize();
                setNumberofChanges((int)(rChangingRatio*m_numPeaks));
                //if(this->isMFRB)
                //this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)rTimes_con;
                //	m_proPar<<"Vlength:"<<m_vlength<<"; ";
            }
            
            void  MovingPeak::freeMemory(){
                int i;
                
                for (i=0; i< m_numPeaks; i++){
                    delete [] mpp_prevMovement[i];
                }
                delete [] mpp_prevMovement;
                delete []  mp_shift ;
                delete []  mp_coveredPeaks ;
                delete [] mp_isTracked;
                delete [] mp_heightOrder;
                delete [] mp_found;
                //added by Chenyang Bu
                for (i=0; i< m_numPeaks; i++){
                    delete [] this->randArray[i];
                }
                delete[] this->randArray;
                if(this->isMFRB){
                    delete[] this->RegionRadius;
                    delete[]this->RegionRadiusOrder;
                    this->RegionRadius=0;
                    this->RegionRadiusOrder=0;
                }
                mpp_prevMovement=0;
                mp_shift=0 ;
                mp_coveredPeaks=0 ;
                mp_isTracked=0;
                mp_heightOrder=0;
                mp_found=0;
            }
            void MovingPeak::allocateMemory(const int rDimNum, const int rPeaks){
                mp_shift = new double[rDimNum];
                mp_coveredPeaks = new int[rPeaks];
                mpp_prevMovement = new double*[rPeaks];
                mp_isTracked= new int [rPeaks];
                mp_heightOrder=new int [rPeaks];
                mp_found=new bool[rPeaks];
                for (int i=0; i< rPeaks; i++){
                    mpp_prevMovement[i] =new double[rDimNum];
                }
                //added by Chenyang Bu
                this->randArray=new double*[rPeaks];
                for (int i=0; i< rPeaks; i++){
                    this->randArray[i] =new double[rDimNum];
                }
                for (int i=0; i< rPeaks; i++){
                    for(int j=0;j<rDimNum;j++){
                        if(this->isMFRB==false)
                            this->randArray[i][j]=Global::gp_uniformPro->Next()-0.5;
                        else
                            this->randArray[i][j]=Global::mfr_gp_uniformPro->Next()-0.5;
                    }
                }
                if(this->isMFRB){
                    this->RegionRadius=new double [rPeaks];
                    this->RegionRadiusOrder=new int [rPeaks];
                    for(int i=0;i<rPeaks;i++){
                        this->RegionRadius[i]=0.0;
                        this->RegionRadiusOrder[i]=0;
                    }
                }
                
                
            }
            bool MovingPeak::readData(){
                
                /***************************************
                 * //		m_F		Evaluation Function
                 * //		1		constant_basis_func()
                 * //		2		five_peak_basis_func()
                 * //		3		peak_function1()
                 * //		4		peak_function_cone()
                 * //		5		peak_function_hilly()
                 * //		6		peak_function_twin()
                 **************************************
                 * in>>temp>>m_vlength; // distance by which the peaks are moved, severity
                 * lambda determines whether there is a direction of the movement, or whether
                 * they are totally random. For lambda = 1.0 each move has the same direction,
                 * while for lambda = 0.0, each move has a random direction
                 * //in>>temp>>lambda;
                 * //in>>temp>>m_useBasisFunction;  if set to 1, a static landscape (basis_function) is included in the fitness evaluation
                 * }*/
                
                m_F=3;
                m_lambda=0.0;
                m_useBasisFunction=0;
                m_vlength=2.0;
                m_calculateRightPeak = 1; /* saves computation time if not needed  set to 0 */
                m_minHeight = 5.0;
                m_maxHeight = 15.0;
                m_standardHeight = 5.0;
                m_heightSeverity=7.0; /* severity of height changes, larger numbers  mean larger severity */
                m_minWidth =0.1 ;
                m_maxWidth = 2.0;
                m_standardWidth = 0.5;
                m_widthSeverity = 1.0; /* severity of width changes, larger numbers mean larger severity */
                
                return true;
                
            }
            bool MovingPeak::mfr_readData(){
                m_F=3;
                m_lambda=1.0;
                m_useBasisFunction=0;
                //m_vlength=0.1;
                m_calculateRightPeak = 1; /* saves computation time if not needed  set to 0 */
                m_minHeight = 30.0;
                m_maxHeight = 70.0;
                m_standardHeight = 50.0;
                m_minWidth = 1.0 ;
                m_maxWidth = 12.0;
                m_standardWidth = 1.0;
                m_heightSeverity=7.0; /* severity of height changes, larger numbers  mean larger severity */
                m_widthSeverity = 0.01; /* severity of width changes, larger numbers mean larger severity */
                
                return true;
            }
            void MovingPeak::initialize(){
                int i=0,j=0;
                setSearchRange<double>(0,100);
                setProblemType(MAX_OPT);
                
                for ( i=0; i< m_numPeaks; i++)
                    for ( j=0; j< m_dimNumber; j++){
                        mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
                        mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
                    }
                //Chenyang Bu <2015/1/23>
                for (i=0;i<m_numPeaks; i++)
                    gCopy(this->mpp_initialPeak[i],mpp_peak[i],m_dimNumber);
                //end
                if (m_standardHeight <= 0.0){
                    for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next()+m_minHeight;
                }else{
                    for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
                }
                
                if (m_standardWidth <= 0.0){
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= (m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next()+m_minWidth;
                }else{
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= m_standardWidth;
                }
                
                calculateGlobalOptima();
                for (i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                
                for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                //added by Chenyang Bu <2015/1/23>
                gCopy(this->mpp_initialHeight,this->mp_height,m_numPeaks);
                gCopy(this->mpp_initialWidth,this->mp_width,m_numPeaks);
                //end
            }
            void MovingPeak::mfr_initialize(){
                int i=0,j=0;
                setSearchRange<double>(0,100);
                setProblemType(MAX_OPT);
                
                for ( i=0; i< m_numPeaks; i++)
                    for ( j=0; j< m_dimNumber; j++){
                        if(this->isMFRB==false)
                            mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
                        else
                            mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
                        if(this->isMFRB==false)
                            mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
                        else
                            mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
                    }
                //Chenyang Bu <2015/1/23>
                for (i=0;i<m_numPeaks; i++)
                    gCopy(this->mpp_initialPeak[i],mpp_peak[i],m_dimNumber);
                //end
                
                if (m_standardHeight <= 0.0){
                    for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
                }else{
                    for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
                }
                
                if (m_standardWidth <= 0.0){
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
                }else{
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= m_standardWidth;
                }
                //Chenyang Bu <6/3/2015>
                
                
                //end of Chenyang Bu
                calculateGlobalOptima();
                for (i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                //this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)times_con;
                this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
                for(i=0;i<m_numPeaks;i++){
                    this->RegionRadius[i]=sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
                    this->RegionRadiusOrder[i]=i;
                }
                gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
                for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                //added by Chenyang Bu <2015/1/23>
                gCopy(this->mpp_initialHeight,this->mp_height,m_numPeaks);
                gCopy(this->mpp_initialWidth,this->mp_width,m_numPeaks);
                getDisconnectedFeasibleRegions();
                //end
            }
            void MovingPeak::set_m_F(int value){
                this->m_F=value;
            }
            void MovingPeak::setGlobalRegion(int peak_number){
                this->mfr_IDGlobalRegion=this->regionIndex[peak_number];
            }
            double MovingPeak::distance(double *x1,double*x2){
                double dis=0.0;
                for(int i=0;i<this->getDimNumber();i++){
                    dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
                }
                dis=sqrt(dis);
                return dis;
            }
            bool MovingPeak::isInRegion(double *gen,int peak_number){
                if(this->RegionRadius[peak_number]<=0)
                    return false;
                double height=this->functionSelection(gen,peak_number);
                if(height>=this->conHeight)
                    return true;
                else
                    return false;
                /*double dis=this->distance(gen,this->mpp_peak[peak_number]);
                 * if(dis<=this->RegionRadius[peak_number])
                 * return true;
                 * else return false;*/
                
            }
            bool MovingPeak::isInGlobalRegion(double*gen){
                for(int i=0;i<this->m_numPeaks;i++){
                    if(this->isInRegion(gen,i))
                    {
                        if(this->regionIndex[i]==this->mfr_IDGlobalRegion)
                            return true;
                    }
                }
                return false;
            }
            void MovingPeak::reset(){
                int i=0,j=0;
                
                for ( i=0; i< m_numPeaks; i++)
                    for ( j=0; j< m_dimNumber; j++){
                        if(this->isMFRB==false){
                            mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
                            mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
                        }else{
                            mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
                            mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
                        }
                    }
                
                if (m_standardHeight <= 0.0){
                    if(this->isMFRB==false)
                        for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next()+m_minHeight;
                    else
                        for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
                }else{
                    for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
                }
                
                if (m_standardWidth <= 0.0){
                    for (i=0; i< m_numPeaks; i++){
                        if(this->isMFRB==false)
                            mp_width[i]= (m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next()+m_minWidth;
                        else
                            mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
                    }
                }else{
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= m_standardWidth;
                }
                
                calculateGlobalOptima();
                m_changeCounter=0;
                //for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;  no need to be reset to 0 for different runs, accumulate the values of all runs
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
            }
            void MovingPeak::mfr_reset(){
                int i=0,j=0;
                
                for ( i=0; i< m_numPeaks; i++)
                    for ( j=0; j< m_dimNumber; j++){
                        mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
                        mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
                    }
                
                if (m_standardHeight <= 0.0){
                    for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
                }else{
                    for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
                }
                
                if (m_standardWidth <= 0.0){
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
                }else{
                    for (i=0; i< m_numPeaks; i++)
                        mp_width[i]= m_standardWidth;
                }
                
                calculateGlobalOptima();
                m_changeCounter=0;
                //for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;  no need to be reset to 0 for different runs, accumulate the values of all runs
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
            }
            /* free disc space at end of program */
            MovingPeak::~MovingPeak()
            {
#ifdef Test
                if(this->isMFRB)
                    cout<<"~MFRB\n";
                else
                    cout<<"~movingPeak()\n";
#endif
                freeMemory();
                //this->deleteMFRs();
                //this->deleteMPs();
                //MovingPeak::msp_MPs=0;
                //MovingPeak::msp_MFRs=0;
            }
            string MovingPeak::getRegionRadius(){
                stringstream ss;
                ss<<"[";
                for(int i=0;i<(this->m_numPeaks-1);i++){
                    ss<<this->RegionRadius[i]<<", ";
                }
                ss<<this->RegionRadius[this->m_numPeaks-1]<<"]"<<endl;
                return ss.str();
            }
            double MovingPeak::getRegionRadius(int rpeak){
                return this->RegionRadius[rpeak];
            }
            /* current_peak_calc determines the peak of the current best individual */
            void MovingPeak::currentPeakCalc (double *gen)
            {
                int i;
                double maximum = -100000.0, dummy;
                
                
                m_currentPeak = 0;
                maximum = functionSelection(gen, 0);
                for(i=1; i<m_numPeaks; i++){
                    dummy = functionSelection(gen, i);
                    if (dummy > maximum){
                        maximum = dummy;
                        m_currentPeak = i;
                    }
                }
            }
            
            
            /* evaluation function */
            double MovingPeak::evaluate (double const *gen, bool rFlag)
            {
                
                int i;
                double maximum = -100000.0, dummy;
                
                for(i=0; i<m_numPeaks; i++)    {
                    dummy = functionSelection(const_cast<double *>(gen), i);
                    if (dummy > maximum)      maximum = dummy;
                }
                
                if (m_useBasisFunction) {
                    
                    dummy = functionSelection(const_cast<double *>(gen),-1);
                    /* If value of basis function is higher return it */
                    if (maximum < dummy)
                        maximum = dummy;
                }
                if(rFlag) isTracked(gen);
                if(rFlag)    m_evals++;
                if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals){
                    /*DynamicProblem::change();
                     * for (i=0; i< m_numPeaks; i++) {
                     * mp_heightOrder[i]=i;
                     * mp_found[i]=false;
                     * }
                     * gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);*/
                }
                return(maximum);
            }
            void MovingPeak::mfr_change(){
                //this->m_changeCounter++;
                
                DynamicProblem::change();
                
                for (int i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                
                //this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)this->times_con;
                //this->conHeight=this->mp_height[0]/(double)this->times_con;
                this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
                //Chenyang Bu <6/3/2015>
                for(int i=0;i<m_numPeaks;i++){
                    this->RegionRadius[i]=sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
                    this->RegionRadiusOrder[i]=i;
                }
                this->numFeasibleRegions=0;
                for(int i=0;i<m_numPeaks;i++){
                    this->regionIndex[i]=-1;
                }
                
                gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
                
                getDisconnectedFeasibleRegions();
                
                //end of Chenyang Bu
            }
            void MovingPeak::mpb_change(){
                DynamicProblem::change();
                for (int i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
            }
            /* dummy evaluation function allows to evaluate without being counted */
            double MovingPeak::dummyEval (double *gen)
            {
                int i;
                double maximum = -100000.0, dummy;
                
                for(i=0; i<m_numPeaks; i++)
                {
                    dummy = functionSelection(gen, i);
                    if (dummy > maximum)
                        maximum = dummy;
                }
                
                if (m_useBasisFunction) {
                    
                    dummy = functionSelection(gen,-1);
                    /* If value of basis function is higher return it */
                    if (maximum < dummy)
                        maximum = dummy;
                }
                return(maximum);
            }
            
            /* whenever this function is called, the peaks are changed */
            void MovingPeak::randomChange(){
                //cout<<"randomchange\n";
                int i,j;
                double sum, sum2, offset;
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                for(i=0; i<m_numPeaks; i++){
                    //cout<<i<<endl;
                    if(mp_whetherChange[i]==false) continue;
                    if(this->isMFRB)
                        this->setVlength(this->times,i);
                    /* shift peak locations */
                    sum = 0.0;
                    for (j=0; j<m_dimNumber; j++){
                        if(!this->isMFRB)
                            mp_shift[j]=Global::gp_uniformPro->Next()-0.5;
                        else
                            mp_shift[j]=Global::mfr_gp_uniformPro->Next()-0.5;
                        sum += mp_shift[j]*mp_shift[j];
                    }
                    if(sum>0.0)		sum = m_vlength/sqrt(sum);
                    else  sum = 0.0;                        /* only in case of rounding errors */
                    
                    sum2=0.0;
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=sum*(1.0-m_lambda)*mp_shift[j]+m_lambda*mpp_prevMovement[i][j];
                        sum2 += mp_shift[j]*mp_shift[j];
                    }
                    if(sum2>0.0)sum2 = m_vlength/sqrt(sum2);
                    else     sum2 = 0.0;                      /* only in case of rounding errors */
                    
                    for(j=0; j<m_dimNumber; j++){
                        mp_shift[j]*=sum2;
                        mpp_prevMovement[i][j]= mp_shift[j];
                        if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
                            mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }
                        else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
                            mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }else
                            mpp_peak[i][j] += mpp_prevMovement[i][j];
                    }
#ifdef TestEffectofDynamicSeverity
                    if(this->isMFRB==false)
#endif
                    {
                        /* change peak width */
                        if(!this->isMFRB)
                            offset = Global::gp_normalPro->Next()*m_widthSeverity;
                        else
                            offset = Global::mfr_gp_normalPro->Next()*m_widthSeverity;
                        
                        
                        double range=m_maxWidth-m_minWidth;
                        double exceed=0.0;
                        if((mp_width[i]+offset) < m_minWidth) {
                            exceed=m_minWidth-(mp_width[i]+offset);
                            if(exceed>range)
                                exceed-=((int)(exceed/range))*range;
                            mp_width[i]=m_minWidth+exceed;
                        }
                        else if((mp_width[i]+offset) > m_maxWidth){
                            exceed=(mp_width[i]+offset)-m_maxWidth;
                            if(exceed>range)
                                exceed-=((int)(exceed/range))*range;
                            mp_width[i]=m_maxWidth-exceed;
                        }
                        else	mp_width[i] += offset;
                        
                        /*if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
                         * else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
                         * else	mp_width[i] += offset;*/
                        //cout<<i<<" "<<mp_width[i]<<endl;
                        /* change peak height */
                        if(!this->isMFRB)
                            offset = m_heightSeverity*Global::gp_normalPro->Next();
                        else
                            offset = m_heightSeverity*Global::mfr_gp_normalPro->Next();
                        
                        
                        range=m_maxHeight-m_minHeight;
                        exceed=0.0;
                        if((mp_height[i]+offset) < m_minHeight) {
                            exceed=m_minHeight-(mp_height[i]+offset);
                            if(exceed>range)
                                exceed-=((int)(exceed/range))*range;
                            mp_height[i]=m_minHeight+exceed;
                        }
                        else if((mp_height[i]+offset) > m_maxHeight){
                            exceed=(mp_height[i]+offset)-m_maxHeight;
                            if(exceed>range)
                                exceed-=((int)(exceed/range))*range;
                            mp_height[i]=m_maxHeight-exceed;
                        }
                        else	mp_height[i] += offset;
                        
                        
                        /*if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
                         * else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
                         * else	mp_height[i] += offset;*/
                    }
                }
                
                calculateGlobalOptima();
                updateNumberofChanges();
                //cout<<"randomchange end\n";
            }
            //Chenyang Bu <2015/1/23>
            void MovingPeak::chaoticChange(){
                int i,j;
                double sum, sum2, offset;
                if(this->getChangeCounter()==0){
                    for(i=0;i<this->m_numPeaks;i++){
                        gCopy(this->mpp_prevMovement[i],this->randArray[i],this->m_dimNumber);
                    }
                }
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                for(i=0; i<m_numPeaks; i++){
                    if(mp_whetherChange[i]==false) continue;
                    if(this->isMFRB)
                        this->setVlength(this->times,i);
                    /* shift peak locations */
                    for (j=0; j<m_dimNumber; j++){
                        this->mp_shift[j]=this->par_chaoticChange*this->mpp_prevMovement[i][j]*(1-this->mpp_prevMovement[i][j]);
                    }
                    
                    for(j=0; j<m_dimNumber; j++){
                        mpp_prevMovement[i][j]= mp_shift[j];
                        if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
                            mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }
                        else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
                            mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }else
                            mpp_peak[i][j] =this->mpp_initialPeak[i][j] + mpp_prevMovement[i][j];
                    }
                    /* change peak width */
                    if(this->isMFRB==false)
                        offset = Global::gp_normalPro->Next()*m_widthSeverity;
                    else
                        offset=Global::mfr_gp_normalPro->Next()*m_widthSeverity;
                    if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
                    else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
                    else	mp_width[i] += offset;
                    /* change peak height */
                    if(this->isMFRB==false)
                        offset = m_heightSeverity*Global::gp_normalPro->Next();
                    else
                        offset = m_heightSeverity*Global::mfr_gp_normalPro->Next();
                    
                    if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
                    else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
                    else	mp_height[i] += offset;
                }
                
                calculateGlobalOptima();
                updateNumberofChanges();
                
                
            }
            void MovingPeak::linearChange(){
                int i,j;
                double sum, sum2, offset;
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                for(i=0; i<m_numPeaks; i++){
                    if(mp_whetherChange[i]==false) continue;
                    if(this->isMFRB)
                        this->setVlength(this->times,i);
                    /* shift peak locations */
                    sum = 0.0;
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->randArray[i][j];//the moving direction of each peak remains the same
                        sum += mp_shift[j]*mp_shift[j];
                    }
                    if(sum>0.0)		sum = m_vlength/sqrt(sum);
                    else  sum = 0.0;                        /* only in case of rounding errors */
                    
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->m_lambda*sqrt(this->m_vlength/(double)this->m_dimNumber)+(1-this->m_lambda)*sum*this->mp_shift[j];
                    }
                    
                    for(j=0; j<m_dimNumber; j++){
                        mpp_prevMovement[i][j]= mp_shift[j];
                        if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
                            mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }
                        else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
                            mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }else
                            mpp_peak[i][j] += mpp_prevMovement[i][j];
                    }
                    ///* change peak width */
                    //if(this->isMFRB==false)
                    //	offset = Global::gp_normalPro->Next()*m_widthSeverity;
                    //else
                    //	offset=Global::mfr_gp_normalPro->Next()*m_widthSeverity;
                    //if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
                    //else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
                    //else	mp_width[i] += offset;
                    ///* change peak height */
                    //if(this->isMFRB==false)
                    //	offset = m_heightSeverity*Global::gp_normalPro->Next();
                    //else
                    //	offset = m_heightSeverity*Global::gp_normalPro->Next();
                    
                    //if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
                    //else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
                    //else	mp_height[i] += offset;
                }
                
                calculateGlobalOptima();
                updateNumberofChanges();
                
            }
            void MovingPeak::cyclicChange(){
                int i,j;
                double sum, sum2, offset;
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                for(i=0; i<m_numPeaks; i++){
                    if(mp_whetherChange[i]==false) continue;
                    double period=12.0;
                    double noisySevrity=0.2;
                    if(this->isMFRB){
                        this->setVlength(this->times,i);
                        this->m_vlength*=(period/2.);
                    }
                    /* shift peak locations */
                    sum = 0.0;
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->randArray[i][j];//the moving direction of each peak remains the same
                        sum += mp_shift[j]*mp_shift[j];
                    }
                    if(sum>0.0)		sum = m_vlength/sqrt(sum);
                    else  sum = 0.0;                        /* only in case of rounding errors */
                    
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->m_lambda*sqrt(this->m_vlength/(double)this->m_dimNumber)+(1-this->m_lambda)*sum*this->mp_shift[j];
                        mp_shift[j]*=0.5*(sin(2.0*M_PI/period*(double)this->getChangeCounter()+M_PI*0.5)+1)+Global::mfr_gp_normalPro->Next()*noisySevrity;
                    }
                    
                    for(j=0; j<m_dimNumber; j++){
                        mpp_prevMovement[i][j]= mp_shift[j];
                        if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
                            mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }
                        else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
                            mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }else
                            mpp_peak[i][j] =this->mpp_initialPeak[i][j] + mpp_prevMovement[i][j];
                    }
                    ///* change peak width */
                    //if(this->isMFRB==false)
                    //	offset = Global::gp_normalPro->Next()*m_widthSeverity;
                    //else
                    //	offset=Global::mfr_gp_normalPro->Next()*m_widthSeverity;
                    //if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
                    //else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
                    //else	mp_width[i] += offset;
                    ///* change peak height */
                    //if(this->isMFRB==false)
                    //	offset = m_heightSeverity*Global::gp_normalPro->Next();
                    //else
                    //	offset = m_heightSeverity*Global::gp_normalPro->Next();
                    
                    //if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
                    //else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
                    //else	mp_height[i] += offset;
                }
                
                calculateGlobalOptima();
                updateNumberofChanges();
                
            }
            void MovingPeak::stochasticChange(){
                this->randomChange();
            }
            void MovingPeak::decayOscilationChange(){
                int i,j;
                double sum, sum2, offset;
                
                for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                for(i=0; i<m_numPeaks; i++){
                    if(mp_whetherChange[i]==false) continue;
                    if(this->isMFRB)
                        this->setVlength(this->times,i);
                    /* shift peak locations */
                    sum = 0.0;
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->randArray[i][j];//the moving direction of each peak remains the same
                        sum += mp_shift[j]*mp_shift[j];
                    }
                    if(sum>0.0)		sum = m_vlength/sqrt(sum);
                    else  sum = 0.0;                        /* only in case of rounding errors */
                    
                    for (j=0; j<m_dimNumber; j++){
                        mp_shift[j]=this->m_lambda*sqrt(this->m_vlength/(double)this->m_dimNumber)+(1-this->m_lambda)*sum*this->mp_shift[j];
                        mp_shift[j]*=exp(-1.0*(double)this->getChangeCounter()*sin(M_PI*(double)this->getChangeCounter()*0.5));
                    }
                    
                    for(j=0; j<m_dimNumber; j++){
                        mpp_prevMovement[i][j]= mp_shift[j];
                        if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
                            mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }
                        else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
                            mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
                            mpp_prevMovement[i][j]*=-1.0;
                        }else
                            mpp_peak[i][j] =this->mpp_initialPeak[i][j] + mpp_prevMovement[i][j];
                    }
                    /* change peak width */
                    if(this->isMFRB==false)
                        offset = Global::gp_normalPro->Next()*m_widthSeverity;
                    else
                        offset=Global::mfr_gp_normalPro->Next()*m_widthSeverity;
                    if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
                    else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
                    else	mp_width[i] += offset;
                    /* change peak height */
                    if(this->isMFRB==false)
                        offset = m_heightSeverity*Global::gp_normalPro->Next();
                    else
                        offset = m_heightSeverity*Global::gp_normalPro->Next();
                    
                    if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
                    else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
                    else	mp_height[i] += offset;
                }
                
                calculateGlobalOptima();
                updateNumberofChanges();
                
            }
            //end of Chenyang Bu
            /* Basis Functions */
            
            /* This gives a constant value back to the eval-function that chooses the max of them */
            double MovingPeak::constantBasisFunc(double *gen)
            {
                return 0.0;
            }
            
            double MovingPeak::fivePeakBasisFunc(double *gen)
            {
                int i,j;
                double maximum = -100000.0, dummy;
                static double basis_peak [5][7]=
                {
                    {8.0,  64.0,  67.0,  55.0,   4.0, 0.1, 50.0},
                    {50.0,  13.0,  76.0,  15.0,   7.0, 0.1, 50.0},
                    {9.0,  19.0,  27.0,  67.0, 24.0, 0.1, 50.0},
                    {66.0,  87.0,  65.0,  19.0,  43.0, 0.1, 50.0},
                    {76.0,  32.0,  43.0,  54.0,  65.0, 0.1, 50.0}
                };
                for(i=0; i<5; i++)
                {
                    dummy = (gen[0]-basis_peak[i][0])*(gen[0]-basis_peak[i][0]);
                    for (j=1; j< m_dimNumber; j++)
                        dummy += (gen[j]-basis_peak[i][j])*(gen[j]-basis_peak[i][j]);
                    dummy = basis_peak[i][m_dimNumber+1]-(basis_peak[i][m_dimNumber]*dummy);
                    if (dummy > maximum)
                        maximum = dummy;
                }
                return maximum;
            }
            
            /* Peak Functions */
            
            /* sharp peaks */
            double MovingPeak::peakFunction1(double *gen, int peak_number)
            {
                int j;
                double dummy;
                
                dummy = (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
                for (j=1; j< m_dimNumber; j++)
                    dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);
                
                return mp_height[peak_number]/(1+mp_width[peak_number]*dummy);
            }
            
            double MovingPeak::peakFunctionCone(double *gen, int peak_number)
            {
                int j;
                double dummy;
                
                dummy =  (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
                for (j=1; j< m_dimNumber; j++)    dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);
                
                if(dummy!=0)
                    dummy =mp_height[peak_number]-mp_width[peak_number]*sqrt(dummy);
                
                
                return dummy;
            }
            
            double MovingPeak::peakFunctionHilly(double *gen, int peak_number)
            {
                int j;
                double dummy;
                
                dummy =  (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
                for (j=1; j< m_dimNumber; j++)
                    dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);
                
                return mp_height[peak_number]- mp_width[peak_number]*dummy-0.01*sin(20.0*dummy);
            }
            
            double MovingPeak::peakFunctionTwin(double  *gen, int peak_number) /* two twin peaks moving together */
            {
                int j;
                double maximum = -100000.0, dummy;
                static double twin_peak [7] = /* difference to first peak */
                {
                    1.0,  1.0,  1.0,  1.0,   1.0, 0.0, 0.0,
                };
                
                dummy = pow(gen[0]-mpp_peak[peak_number][0],2);
                for (j=1; j< m_dimNumber; j++)
                    dummy += pow(gen[j]-mpp_peak[peak_number][j],2);
                
                dummy = mp_height[peak_number]- mp_width[peak_number]*dummy;
                
                maximum = dummy;
                dummy = pow(gen[0]-(mpp_peak[peak_number][0]+twin_peak[0]),2);
                for (j=1; j< m_dimNumber; j++)
                    dummy += pow(gen[j]-(mpp_peak[peak_number][j]+twin_peak[0]),2);
                
                dummy =  mp_height[peak_number]+twin_peak[m_dimNumber+1]-((mp_width[peak_number]+twin_peak[m_dimNumber])*dummy);
                if (dummy > maximum)
                    maximum = dummy;
                
                return maximum;
            }
            double MovingPeak::functionSelection(double  *gen, int peak_number){
                double dummy;
                switch(m_F){
                    case 1: {
                        dummy=constantBasisFunc(gen);
                        break;
                    }
                    case 2: {
                        dummy=fivePeakBasisFunc(gen);
                        break;
                    }
                    case 3: {
                        dummy=peakFunction1(gen, peak_number);
                        break;
                    }
                    case 4: {
                        dummy=peakFunctionCone(gen, peak_number);
                        break;
                    }
                    case 5: {
                        dummy=peakFunctionHilly(gen, peak_number);
                        break;
                    }
                    case 6: {
                        dummy=peakFunctionTwin(gen, peak_number);
                        break;
                    }
                }
                return dummy;
            }
            /* The following procedures may be used to change the step size over time */
            
            double MovingPeak::get_conHeight(){
                return this->conHeight;
            }
            void MovingPeak::changeStepsizeRandom () /* assigns vlength a value from a normal distribution */
            {
                m_vlength = Global::gp_normalPro->Next();
            }
            
            void MovingPeak::changeStepsizeLinear() /* sinusoidal change of the stepsize, */
            {
                static int counter = 1;
                static double frequency = 3.14159/20.0;  /* returns to same value after 20 changes */
                
                m_vlength = 1+ sin((double)counter*frequency);
                counter ++;
            }
            
            int MovingPeak::getRightPeak()  /* returns 1 if current best individual is on highest mpp_peak, 0 otherwise */
            {
                bool flag=false;
                
                for(int i=0;i<m_numPeaks;i++){
                    if(mp_globalOptimaIdx[i]==true && m_currentPeak == i){
                        flag=true;
                        break;
                    }
                }
                
                return flag;
            }
            void MovingPeak::setVlength(const double s){
                m_vlength=s;
                
                /*size_t start, end;
                 * start=m_proPar.str().find("Vlength:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"Vlength:"<<m_vlength<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
                
            }
            void MovingPeak::setVlength(const int rtimes, int rpeak){
                if(this->isMFRB==false) return;
                this->m_vlength=rtimes*sqrt((this->mp_height[rpeak]/this->conHeight-1)/this->mp_width[rpeak]);
                //this->m_vlength*=6;
                /*size_t start, end;
                 * start=m_proPar.str().find("Vlength:");
                 * for(int i=start;i<m_proPar.str().size();i++){
                 * if(m_proPar.str()[i]==';') {
                 * end=i;
                 * break;
                 * }
                 * }
                 * stringstream ss;
                 * ss<<"Vlength:"<<m_vlength<<"; ";
                 * string result=m_proPar.str();
                 * result.replace(start,end-start+1, ss.str());
                 * m_proPar.str(result);*/
            }
            
            MovingPeak * MovingPeak::getMPs(){
                if(!MovingPeak::msp_MPs){
                    Throw(Logic_error("the MPB problem is not initialized"));
                }
                
                return MovingPeak::msp_MPs;
            }
            MovingPeak * MovingPeak::getMFRs(){
                if(!MovingPeak::msp_MFRs){
                    Throw(Logic_error("the MFRB problem is not initialized"));
                }
                
                return MovingPeak::msp_MFRs;
            }
            void MovingPeak::deleteMPs(){
                if(MovingPeak::msp_MPs!=0){
                    //	freeMemory();
                    delete MovingPeak::msp_MPs;
                }
                MovingPeak::msp_MPs=0;
            }
            void MovingPeak::deleteMFRs(){
                if(MovingPeak::msp_MFRs!=0){
                    //	freeMemory();
                    
                    
                    delete MovingPeak::msp_MFRs;
                }
                MovingPeak::msp_MFRs=0;
            }
            
            bool MovingPeak::isInitialized(){
                if(MovingPeak::msp_MPs!=0) return true;
                else return false;
            }
            
            void MovingPeak::initialize(int rDim, int rPeaks,float const rChangingRatio,const bool rFlagDimChange, const bool flagNumPeakChange){
                if(MovingPeak::msp_MPs){
                    Throw(Logic_error("the MPB problem has been already initialized"));
                    return;
                }
                MovingPeak::msp_MPs=new MovingPeak(MovingPeak_DOP,rDim,C_DECIMAL,rPeaks,rChangingRatio,rFlagDimChange,flagNumPeakChange);
            }
            void MovingPeak::initialize(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks, float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
                if(MovingPeak::msp_MPs){
                    Throw(Logic_error("the MPB problem has been already initialized"));
                    return;
                }
                MovingPeak::msp_MPs=new MovingPeak(rId, rDimNumber,rEncoding,rNumPeaks,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
            }
            
            void MovingPeak::initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double rTimes_con,const double rTimes_len,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
                if(risMFRB){
                    if(MovingPeak::msp_MFRs){
                        Throw(Logic_error("the MFRB problem has been already initialized"));
                        return;
                    }
                    MovingPeak::msp_MFRs=new MovingPeak(risMFRB,rId, rDimNumber,rEncoding,rNumPeaks,rTimes_con,rTimes_len,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                }
                else{
                    if(MovingPeak::msp_MPs){
                        Throw(Logic_error("the MPB problem has been already initialized"));
                        return;
                    }
                    MovingPeak::msp_MPs=new MovingPeak(risMFRB,rId, rDimNumber,rEncoding,rNumPeaks,rTimes_con,rTimes_len,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                    
                }
            }
            
            void MovingPeak::changeNumPeaks(){
                
                
                MovingPeak* mpb=new MovingPeak(MovingPeak_DOP,m_dimNumber,C_DECIMAL,m_numPeaksTemp,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);
                
                
                mpb->parameterSetting(this);
                mpb->calculateGlobalOptima();
                
                freeMemory();
                DynamicContinuous::freeMemory();
                
                allocateMemory(m_dimNumber,m_numPeaksTemp);
                DynamicContinuous::allocateMemory(m_dimNumber,m_numPeaksTemp);
                
                m_numPeaks=m_numPeaksTemp;
                
                *this=*mpb;
                delete mpb;
                
            }
            
            void MovingPeak::parameterSetting(DynamicProblem * rP){
                DynamicContinuous::parameterSetting(rP);
                
                MovingPeak *mpb=static_cast<MovingPeak *>(rP);
                int dim=m_dimNumberTemp<rP->getDimNumber()?m_dimNumberTemp:rP->getDimNumber();
                int peaks=m_numPeaks<rP->getNumberofPeak()?m_numPeaks:rP->getNumberofPeak();
                
                m_F=mpb->m_F;
                m_vlength=mpb->m_vlength;
                m_lambda=mpb->m_lambda;
                m_useBasisFunction=mpb->m_useBasisFunction;
                m_calculateRightPeak=mpb->m_calculateRightPeak ;
                m_standardHeight=mpb->m_standardHeight;
                m_standardWidth=mpb->m_standardWidth;
                
                m_peaksFound==mpb->m_peaksFound;
                gCopy(mp_shift,mpb->mp_shift,dim);
                gCopy(mp_coveredPeaks,mpb->mp_coveredPeaks,peaks);
                gCopy(mp_isTracked,mpb->mp_isTracked,peaks);
                gCopy(mp_heightOrder,mpb->mp_heightOrder,peaks);
                gCopy(mp_found,mpb->mp_found,peaks);
                
                
                for (int i=0; i<peaks; i++){
                    gCopy(mpp_prevMovement[i],mpb->mpp_prevMovement[i],dim);
                    
                }
                
            }
            MovingPeak &MovingPeak::operator=(MovingPeak &other){
                if(this==&other) return *this;
                
                DynamicContinuous::operator=(other);
                
                m_F=other.m_F;
                m_vlength=other.m_vlength;
                m_lambda=other.m_lambda;
                m_useBasisFunction=other.m_useBasisFunction;
                m_calculateRightPeak=other.m_calculateRightPeak ;
                m_standardHeight=other.m_standardHeight;
                m_standardWidth=other.m_standardWidth;
                m_peaksFound=other.m_peaksFound;
                
                gCopy(mp_shift,other.mp_shift,m_dimNumber);
                gCopy(mp_coveredPeaks,other.mp_coveredPeaks,m_numPeaks);
                gCopy(mp_isTracked,other.mp_isTracked,m_numPeaks);
                gCopy(mp_heightOrder,other.mp_heightOrder,m_numPeaks);
                gCopy(mp_found,other.mp_found,m_numPeaks);
                
                for (int i=0; i<m_numPeaks; i++){
                    gCopy(mpp_prevMovement[i],other.mpp_prevMovement[i],m_dimNumber);
                    
                }
                //added by Chenyang Bu <2015/1/23>
                this->par_chaoticChange=other.par_chaoticChange;
                for (int i=0; i<m_numPeaks; i++){
                    gCopy(randArray[i],other.randArray[i],m_dimNumber);
                    
                }
                gCopy(this->RegionRadius,other.RegionRadius,this->m_dimNumber);
                gCopy(this->RegionRadiusOrder,other.RegionRadiusOrder,this->m_dimNumber);
                this->times=other.times;
                this->times_con=other.times_con;
                this->conHeight=other.conHeight;
                this->mfr_IDGlobalRegion=other.mfr_IDGlobalRegion;
                this->isMFRB=other.isMFRB;
                //end of Chenyang Bu
                return *this;
            }
            int MovingPeak::getTrackNumber(int idex){
                return mp_isTracked[idex];
            }
            
            bool MovingPeak::isTracked(double const *gen){
                bool flag=false;
                for(int i=0;i<m_numPeaks;i++){
                    double dis=0;
                    for(int j=0;j<m_dimNumber;j++) dis+=(gen[j]-mpp_peak[i][j])*(gen[j]-mpp_peak[i][j]);
                    dis=sqrt(dis);
                    if(dis<=0.1){//Global::g_sigma
                        int j=0;
                        while(mp_heightOrder[j++]!=i&&j<m_numPeaks);
                        if(!mp_found[i]){
                            mp_isTracked[j-1]++;
                            mp_found[i]=true;
                            m_peaksFound++;
                        }
                        flag=true;
                    }
                }
                
                return flag;
            }
            int MovingPeak::getPeaksFound(){
                return m_peaksFound;
            }
            void MovingPeak::getDisconnectedFeasibleRegions(){
                for(int i=0;i<this->m_numPeaks;i++){
                    if(this->regionIndex[i]==-1){
                        this->regionIndex[i]=this->numFeasibleRegions++;
                        
                    }
                    for(int j=i+1;j<this->m_numPeaks;j++){
                        double dis=0.0;
                        for(int i1=0;i1<this->m_dimNumber;i1++){
                            dis+=(this->mpp_peak[i][i1]-this->mpp_peak[j][i1])*(this->mpp_peak[i][i1]-this->mpp_peak[j][i1]);
                        }
                        dis=sqrt(dis);
                        
                        if(dis<=(this->RegionRadius[i]+this->RegionRadius[j])){
                            this->regionIndex[j]=this->regionIndex[i];
                        }
                    }
                }
            }
            
            
            class MyVector{								// *****************Orthogonal rotation matrix***********************
            public:
                int size;
                double *data;
            public:
                MyVector();
                MyVector(const int s);
                ~MyVector();
                MyVector &operator =(const MyVector & v);
                
                void operator +(const MyVector & v);
                void operator -(const MyVector & v);
                double operator *(const MyVector & v);
                void ProjectionToV(MyVector &v);
                void Normalization();
                void freeMemory();
                void allocateMemory(const int s);
            };
            
            
            
            MyVector::MyVector(){
                data=0;
                size=0;
                /*if(Global::num_dim<1) Throw(Logic_error("size of vector must be greater than 0"));
                 * size=Global::num_dim;
                 * data=new double[size];*/
            }
            MyVector::MyVector(const int s){
                if(s<1) Throw(Logic_error("size of vector must be greater than 0"));
                size=s;
                data=new double[size];
            }
            
            void  MyVector::freeMemory(){
                delete []data;
                data=0;
            }
            void  MyVector::allocateMemory(const int s){
                if(s<1) Throw(Logic_error("size of vector must be greater than 0"));
                size=s;
                data=new double[size];
                
            }
            
            MyVector::~MyVector(){
                freeMemory();
            }
            MyVector &MyVector::operator =(const MyVector & v){
                if(this==&v) return *this;
                for(int i=0;i<size;i++) data[i]=v.data[i];
                return *this;
            }
            void MyVector::operator +(const MyVector & v){
                if(size!=v.size) Throw(Logic_error("the size of two vectors must be same by + operation"));
                
                for(int i=0;i<size;i++) data[i]=data[i]+v.data[i];
                
            }
            void MyVector::operator -(const MyVector & v){
                if(size!=v.size) Throw(Logic_error("the size of two vectors must be same by - operation"));
                
                for(int i=0;i<size;i++) data[i]=data[i]-v.data[i];
                
            }
            double MyVector::operator *(const MyVector & v){
                if(size!=v.size) Throw(Logic_error("the size of two vectors must be same by * operation"));
                double sum=0;
                for(int i=0;i<size;i++) sum+=data[i]*v.data[i];
                
                return sum;
            }
            void MyVector::ProjectionToV(MyVector &v){
                
                double sv=0,vv=0;
                for(int i=0;i<size;i++){
                    sv+=data[i]*v.data[i];
                    vv+=v.data[i]*v.data[i];
                }
                for(int i=0;i<size;i++){
                    data[i]=sv*v.data[i]/vv;
                }
            }
            
            void MyVector::Normalization(){
                double sum=0;
                for(int i=0;i<size;i++) sum+=data[i]*data[i];
                sum=sqrt(sum);
                for(int i=0;i<size;i++) data[i]=data[i]/sum;
            }
            
            
            class Matrix{								// *****************Orthogonal rotation matrix***********************
            public:
                int col,row;										// matrix size
                MyVector *vec;									// value of each element
            public:
                Matrix();
                Matrix(const int c,const int r);
                ~Matrix();
                void operator *(const Matrix & m);
                void operator *(const double x);
                Matrix & operator=(const Matrix & m);
                bool Identity();
                bool isIdentity();
                void Set_Rotation(const int &r,const int &c,const double &angle);
                void GenerateRotationMatrix(const double CondiNum,bool rMode);
                void Randomize(bool rMode);
                void Orthonormalization();
                void InitialToZero();
                const MyVector *Get_Data()const {
                    return const_cast<const MyVector *>(vec);
                }
                double getData(const int r, const int c);
                void setDataRow(const double *d, const int c,const int r=1);
                void setDataCol(const double *d, const int r,const int c=1);
                void setData(const double * const * d);
                void Diagonal(const double CondiNum );
                void Transpose();
                void inverse();
                
                void Read_Data(ifstream &in){
                    for(int i=0;i<row;i++){
                        for(int j=0;j<col;j++)
                            in>>vec[i].data[j];
                    }
                };
                // used for debug
                void Print(ofstream & out){
                    for(int i=0;i<row;i++){
                        for(int j=0;j<col;j++)
                            out<<vec[i].data[j]<<" ";
                        out<<endl;
                    }
                    //out<<endl;
                };
            protected:
                void freeMemory();
                void allocateMemory(const int r, const int c);
            };
            
            
            
            Matrix::Matrix():col(Global::g_dimNumber),row(Global::g_dimNumber){
                if(row==0) return;
                allocateMemory(row,col);
                
            }
            Matrix::Matrix(const int c, const int r):col(c),row(r){
                allocateMemory(row,col);
                
            }
            void Matrix::setDataRow(const double *d,const int c,const int r){
                if(r!=row) return;
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=d[j];
            }
            void Matrix::setDataCol(const double *d, const int r,const int c){
                if(c!=col) return;
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=d[i];
                
            }
            void Matrix::setData(const double * const * d){
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=d[i][j];
            }
            Matrix::~Matrix(){
                
                freeMemory();
            }
            void Matrix::operator *(const Matrix &m){
                
                if(col!=m.row) Throw(Logic_error("can not *, col of 1st matrix must be equal to row of 2nd matrix"));
                
                Matrix r(m.col,row);
                for(int i=0;i<row;i++){
                    for(int j=0;j<m.col;j++){
                        r.vec[i].data[j]=0;
                        for(int k=0;k<col;k++)
                            r.vec[i].data[j]+=vec[i].data[k]*m.vec[k].data[j];
                    }
                }
                if(row!=m.row||col!=m.col){
                    freeMemory();
                    row=r.row;col=r.col;
                    allocateMemory(row,col);
                }
                *this=r;
            }
            void Matrix::operator *(const double x){
                for(int i=0;i<row;i++){
                    for(int j=0;j<col;j++){
                        vec[i].data[j]*=x;
                    }
                }
                
            }
            Matrix&Matrix::operator =(const Matrix &m){
                if(row!=m.row||col!=m.col) return *this;
                if(this==&m) return *this;
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=m.vec[i].data[j];
                return *this;
            }
            bool Matrix::Identity(){
                if(row!=col) return false;
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]= (j==i);
                
                return true;
            }
            bool Matrix::isIdentity(){
                if(row!=col) return false;
                for(int i=0;i<row;i++){
                    for(int j=0;j<col;j++) {
                        if(vec[i].data[j]!=(i==j)){
                            return false;
                        }
                    }
                }
                return true;
            }
            void Matrix::Diagonal(const double CondiNum ){
                if(row!=col) Throw(Logic_error("can not be diagonal, matrix must be squre"));
                
                double min,max;
                double *r=new double[row];
                for(int i=0;i<row;i++)	r[i]=gRandFloat(1,row,false);
                
                min=max=r[0];
                for(int i=0;i<row;i++)	{
                    if(min>r[i])min=r[i];
                    if(max<r[i]) max=r[i];
                }
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        if(j!=i) vec[i].data[j]=0.;
                        else vec[i].data[j]=pow(CondiNum,(r[i]-min)/(max-min));
                delete []r;
            }
            void Matrix::InitialToZero(){
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=0.;
            }
            void Matrix::Set_Rotation(const int &r, const int &c,const double &angle){
                Identity();
                vec[r].data[r]=cos(angle);
                vec[r].data[c]=-sin(angle);
                vec[c].data[r]=sin(angle);
                vec[c].data[c]=cos(angle);
            }
            
            
            void Matrix::GenerateRotationMatrix(const double CondiNum,bool rMode){
                
                Matrix ortholeft,orthoright,diagonal;
                ortholeft.Randomize(rMode);
                ortholeft.Orthonormalization();
                orthoright.Randomize(rMode);
                orthoright.Orthonormalization();
                diagonal.Diagonal(CondiNum);
                ortholeft*diagonal;
                ortholeft*orthoright;
                *this=ortholeft;
                
            }
            void Matrix::Randomize(bool rMode){
                for(int i=0;i<row;i++)
                    for(int j=0;j<col;j++)
                        vec[i].data[j]=gRandFloat(-1,1,rMode);
            }
            void Matrix::Orthonormalization(){
                if(row!=col) Throw(Logic_error("can not orthonormalization, matrix must be squre"));
                
                MyVector t1(col),t2(col);
                //Gram schmidt process
                for(int i=1;i<row;i++){
                    t1=vec[i];
                    t2=vec[i];
                    for(int j=0;j<i;j++){
                        t1.ProjectionToV(vec[j]);
                        t2-t1;
                        t1=vec[i];
                    }
                    vec[i]=t2;
                }
                // Normalization each vector
                for(int i=0;i<row;i++) vec[i].Normalization();
            }
            void Matrix::Transpose(){
                double t;
                for(int i=0;i<row;i++)
                    for(int j=0;j<i;j++){
                        t=vec[i].data[j];
                        vec[i].data[j]=vec[j].data[i];
                        vec[j].data[i]=t;
                    }
                
            }
            
            void Matrix::inverse(){
                double **a;
                
                a=new double*[row];
                for(int i=0;i<row;i++ ) a[i]=new double[2*col];
                
                for(int i=0;i<row;i++){
                    for(int j=0;j<col;j++) {
                        a[i][j]=vec[i].data[j];
                    }
                }
                
                for(int i=0;i<row;i++){
                    for(int j=col;j<col*2;j++)
                        a[i][j]=(j-i==col)?(1.0):(0.0);
                }
                
                for(int i=0;i<row;i++)
                {
                    if(a[i][i]!=1.0)
                    {
                        double tmp=a[i][i];
                        a[i][i]=1.0;
                        for(int j=i;j<col*2;j++)
                            a[i][j]/=tmp;
                    }
                    for(int k=0;k<row;k++)
                    {
                        if(i!=k)
                        {
                            double tmp=a[k][i];
                            for(int j=0;j<col*2;j++)
                                a[k][j]-=(tmp*a[i][j]);
                        }
                        else continue;
                    }
                }
                
                for(int i=0;i<row;i++){
                    for(int j=col;j<col*2;j++)
                        vec[i].data[j-col]=a[i][j];
                }
                
                for(int i=0;i<row;i++) delete [] a[i];
                delete [] a;
            }
            
            void Matrix::freeMemory(){
                delete [] vec;
            }
            void Matrix::allocateMemory(const int r, const int c){
                vec=new MyVector[r];
                for(int i=0;i<r;i++)
                    vec[i].allocateMemory(c);
            }
            double Matrix::getData(const int r, const int c){
                if(r<row&&c<col) return vec[r].data[c];
                else Throw(Out_of_range("out of range error in Matrix getData()"));
            }
            
            
            
            class RealDBG : public DynamicContinuous
            {
            protected:
                bool isMFRB;//determine wheter is MFRB or not
                bool m_prediction;						// the next change of function can be predictable or not
                Matrix *mp_rotationMatrix;				// orthogonal rotation matrixes for each function
                int ***mppp_rotationPlanes;					// save the planes rotated during one periodicity
                
            public:
                RealDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks);
                RealDBG(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks);
                virtual ~RealDBG()=0;
                
                ///TODO: not 100% sure whether it should be derived by CompositionDBG and RotationDBG
                virtual bool setPeriod(const int rPeriod);
                
                RealDBG & operator=(const RealDBG & rP);
                void reset();
            protected:
                void correctSolution();
                void heightStandardChange();
                void positionStandardChange(double angle);
                
                virtual void randomChange(){};
                virtual void smallStepChange(){};
                virtual void largeStepChange(){};
                virtual void recurrentChange(){};
                virtual void chaoticChange(){};
                virtual void recurrentNoisyChange(){};
                
                
                virtual void parameterSetting(Problem * rP);
                virtual void  freeMemory();
                double  standardChange(const ChangeType T, const double min, const double max);
                virtual void allocateMemory(const int rDimNum, const int rPeaks);
                
                void initialize(const ChangeType rT, const bool rFlagDimChange, const bool rFlagNumPeakChange);
                void restoreInfor();
                virtual void changeDimension(){};
                virtual void changeNumPeaks(){};
                //added by Chenyang Bu
                void initialize(bool risMFRB,const ChangeType rT, const bool rFlagDimChange, const bool rFlagNumPeakChange);
                int *mp_heightOrder;
                
            };
            
            
            
            
            
            RealDBG::RealDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks)
            {
                this->isMFRB=false;
                //ctor
                allocateMemory(m_dimNumber,m_numPeaks);
                mppp_rotationPlanes=0;
                // setSearchRange<double>(-5,5);
                setSearchRange<double>(-100,100);
                
                m_maxHeight=100;
                m_minHeight=10;
                m_maxWidth=10;
                m_minWidth=1;
                setNoisySeverity(0.8);
                setHeightSeverity(5.0);
                setWidthSeverity(0.5);
                setWidth(5); /// value in 1-10
                
                
            }
            RealDBG::RealDBG(bool risMFRB, const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks)
            {
                this->isMFRB=risMFRB;
                //ctor
                allocateMemory(m_dimNumber,m_numPeaks);
                mppp_rotationPlanes=0;
                // setSearchRange<double>(-5,5);
                setSearchRange<double>(0,100);
                
                m_maxHeight=100;
                m_minHeight=10;
                m_maxWidth=10;
                m_minWidth=1;
                setNoisySeverity(0.8);
                setHeightSeverity(5.0);
                setWidthSeverity(0.5);
                setWidth(5); /// value in 1-10
                
                
            }
            void RealDBG::allocateMemory(const int rDimNum, const int rPeaks){
                mp_rotationMatrix= new Matrix [rPeaks];
                mp_heightOrder=new int [rPeaks];
            }
            RealDBG::~RealDBG(){
                //dtor
                freeMemory();
            }
            RealDBG & RealDBG::operator=(const RealDBG & rP){
                
                if(this==&rP) return *this;
                
                DynamicContinuous::operator=(rP);
                gCopy(mp_rotationMatrix,rP.mp_rotationMatrix,m_numPeaks);
                
                m_prediction=rP.m_prediction;
                
                if(getPeriod()!=rP.getPeriod()){
                    Throw(Logic_error("The period must be the same"));
                    exit(0);
                }
                
                for(int i=0;i<m_period;i++){
                    for(int j=0;j<m_numPeaks;j++)
                        gCopy(mppp_rotationPlanes[i][j],rP.mppp_rotationPlanes[i][j],m_dimNumber);
                }
                
                return *this;
                
            }
            void  RealDBG::freeMemory(){
                delete[] mp_rotationMatrix;
                delete [] mp_heightOrder;
                mp_heightOrder=0;
                if(mppp_rotationPlanes){
                    for(int j=0;j<getPeriod();j++){
                        for(int i=0;i<m_numPeaks;i++)
                            delete [] mppp_rotationPlanes[j][i];
                        delete []mppp_rotationPlanes[j];
                    }
                    delete []mppp_rotationPlanes;
                }
                
                mp_rotationMatrix=0;
                mppp_rotationPlanes=0;
            }
            bool RealDBG::setPeriod(const int p){
                if(p<1) return false;
                DynamicProblem::setPeriod(p);
                
                mppp_rotationPlanes=new int**[m_period];
                for(int i=0;i<m_period;i++){
                    mppp_rotationPlanes[i]=new int*[m_numPeaks];
                    for(int j=0;j<m_numPeaks;j++)
                        mppp_rotationPlanes[i][j]=new int[m_dimNumber];
                }
                return true;
            }
            void RealDBG::correctSolution(){
                for(int j=0;j<m_dimNumber;j++){
                    if(mp_genes[j]>((Boundary<double> *)m_searchRange[j])->upper)
                        mp_genes[j]=((Boundary<double> *)m_searchRange[j])->upper;
                    else if(mp_genes[j]<((Boundary<double> *)m_searchRange[j])->lower)
                        mp_genes[j]=((Boundary<double> *)m_searchRange[j])->lower;
                }
            }
            void RealDBG::heightStandardChange(){
                
                double step;
                for(int i=0;i<m_numPeaks;i++){
                    if(mp_whetherChange[i]==false) continue;
                    step=m_heightSeverity*standardChange(getChangeType(),m_minHeight,m_maxHeight);
                    mp_height[i]=mp_height[i]+step;
                    if(mp_height[i]>m_maxHeight||mp_height[i]<m_minHeight) mp_height[i]=mp_height[i]-step;
                    
                }
            }
            void RealDBG::positionStandardChange(double angle){
                
                // for each basic function of dimension n(even number) , R=R(l1,l2)*R(l3,l4)*....*R(li-1,li), 0<=li<=n
                
                if(getChangeType()==CT_Chaotic){
                    for(int i=0;i<m_numPeaks;i++){
                        if(mp_whetherChange[i]==false) continue;
                        for(int j=0;j<m_dimNumber;j++)
                            mpp_peak[i][j]=gChaoticValue(mpp_peak[i][j],((Boundary<double> *)m_searchRange[j])->lower,((Boundary<double> *)m_searchRange[j])->upper,m_chaoticConstant);
                    }
                    return;
                }
                int * d=new int[m_dimNumber];
                Matrix I;
                for(int i=0;i<m_numPeaks;i++){
                    
                    if((getChangeType()==CT_Recurrent||getChangeType()==CT_RecurrentNoisy)&&m_changeType.counter>=getPeriod()){
                        gCopy(d,mppp_rotationPlanes[m_changeType.counter%getPeriod()][i],m_dimNumber);
                    }
                    else{
                        gInitializeRandomArray(d,m_dimNumber,false);
                        if(getChangeType()==CT_Recurrent||getChangeType()==CT_RecurrentNoisy)
                            gCopy(mppp_rotationPlanes[m_changeType.counter][i],d,m_dimNumber);
                    }
                    
                    if((getChangeType()==CT_Recurrent||getChangeType()==CT_RecurrentNoisy)&&m_changeType.counter%getPeriod()==0)
                        gCopy(mpp_peak[i],mpp_initialPeak[i],m_dimNumber);
                    
                    if(mp_whetherChange[i]==false) continue;
                    
                    I.Identity();
                    for(int j=0;j+1<m_dimNumber;j+=2){
                        if(getChangeType()==CT_SmallStep||getChangeType()==CT_LargeStep||getChangeType()==CT_Random)
                            angle=standardChange(getChangeType(), -PI,PI);
                        I.Set_Rotation(d[j],d[j+1],angle);
                        if(j==0) mp_rotationMatrix[i]=I;
                        else
                            mp_rotationMatrix[i]*I;
                    }
                    Matrix m(m_dimNumber,1);
                    m.setDataRow(mpp_peak[i],m_dimNumber);
                    m*mp_rotationMatrix[i];
                    gCopy(mp_genes,m.Get_Data()[0].data,m_dimNumber);
                    correctSolution();
                    gCopy(mpp_peak[i],mp_genes,m_dimNumber);
                }
                delete [] d;
            }
            void RealDBG::parameterSetting(Problem * rP){
                
                DynamicContinuous::parameterSetting(rP);
                
                RealDBG *r_dbg=static_cast<RealDBG *>(rP);
                int dim=m_dimNumberTemp<rP->getDimNumber()?m_dimNumberTemp:rP->getDimNumber();
                int peaks=m_numPeaks<r_dbg->getNumberofPeak()?m_numPeaks:r_dbg->getNumberofPeak();
                
                m_prediction=r_dbg->m_prediction;
                
                
                if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy){
                    for(int i=0;i<r_dbg->m_period;i++){
                        if(m_changeType.counter<=i) break;
                        for(int j=0;j<peaks;j++){
                            if(dim==m_dimNumberTemp){// the number of dimensions decreases
                                for(int m=0,k=0;k<dim;k++,m++)
                                    if(r_dbg->mppp_rotationPlanes[i][j][m]==dim) {k--;continue;}
                                    else
                                        mppp_rotationPlanes[i][j][k]=r_dbg->mppp_rotationPlanes[i][j][m];
                                
                            }else
                                gCopy(mppp_rotationPlanes[i][j],r_dbg->mppp_rotationPlanes[i][j],dim);
                            
                        }
                        
                    }
                }
            }
            double  RealDBG::standardChange(const ChangeType T, const double min, const double max){
                double step,sign;
                switch(T){
                    case CT_SmallStep:
                        if(!this->isMFRB)
                            step=-1+2*Global::gp_uniformPro->Next();
                        else
                            step=-1+2*Global::mfr_gp_uniformPro->Next();
                        step=m_alpha*step*(max-min);
                        break;
                    case CT_Random:
                        if(!this->isMFRB)
                            step=Global::gp_normalPro->Next();
                        else
                            step=Global::mfr_gp_normalPro->Next();
                        break;
                    case CT_LargeStep:
                        if(!this->isMFRB)
                            step=-1+2*Global::gp_uniformPro->Next();
                        else
                            step=-1+2*Global::mfr_gp_uniformPro->Next();
                        if(step>0)sign=1;
                        else if(step<0) sign=-1;
                        else sign=0;
                        step=(m_alpha*sign+(m_maxAlpha-m_alpha)*step)*(max-min);
                        break;
                    case CT_Recurrent:
                    case CT_Chaotic:
                    case CT_RecurrentNoisy:
                        break;
                }
                return step;
            }
            void RealDBG::reset(){
                m_changeType.counter=0;
                m_changeCounter=0;
                double *t=new double[m_numPeaks];
                
                for(int i=0;i<m_numPeaks;i++){
                    if(m_changeType.type==CT_Chaotic){
                        if(!this->isMFRB)
                            t[i]=m_minHeight+(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next();
                        else
                            t[i]=m_minHeight+(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next();
                    }
                    else
                        t[i]=50;
                }
                setHeight(t);
                delete [] t;
                
                
                double **position;
                position=new double*[m_numPeaks];
                for(int i=0;i<m_numPeaks;i++)
                    position[i]=new double[m_dimNumber];
                for(int i=0;i<m_numPeaks;i++){
                    for(int j=0;j<m_dimNumber;j++){
                        if(!this->isMFRB){
                            position[i][j]=((Boundary<double> *)m_searchRange[j])->lower+(((Boundary<double> *)m_searchRange[j])->upper-((Boundary<double> *)m_searchRange[j])->lower)*Global::gp_uniformPro->Next();
                        }else{
                            position[i][j]=((Boundary<double> *)m_searchRange[j])->lower+(((Boundary<double> *)m_searchRange[j])->upper-((Boundary<double> *)m_searchRange[j])->lower)*Global::mfr_gp_uniformPro->Next();
                        }
                    }
                }
                setPosition(position);
                
                
                for(int i=0;i<m_numPeaks;i++)		delete []position[i];
                delete [] position;
                
                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                calculateGlobalOptima();
            }
            void RealDBG::initialize(const ChangeType rT, const bool rFlagDimChange, const bool rFlagNumPeakChange){
                m_flagDimensionChange=rFlagDimChange;
                setNumPeaksChange(rFlagNumPeakChange);
                //m_flagNumPeaksChange=rFlagNumPeakChange;
                
                
                if(m_flagDimensionChange){
                    m_changeType.type=CT_Random;
                    m_dirDimensionChange=true;
                }else if(m_flagNumPeaksChange){
                    m_changeType.type=CT_Random;
                    m_dirNumPeaksChange=true;
                }
                else{
                    m_changeType.type=rT;
                }
                m_changeType.counter=0;
                
                if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)      setPeriod(12);
                else      setPeriod(0);
                
                
                double *t=new double[m_numPeaks];
                
                setChoaticConstant(3.67);
                
                for(int i=0;i<m_numPeaks;i++){
                    if(m_changeType.type==CT_Chaotic)
                        t[i]=m_minHeight+(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next();
                    else
                        t[i]=50;
                }
                setHeight(t);
                delete [] t;
                
                
                double **position;
                position=new double*[m_numPeaks];
                for(int i=0;i<m_numPeaks;i++)
                    position[i]=new double[m_dimNumber];
                for(int i=0;i<m_numPeaks;i++){
                    for(int j=0;j<m_dimNumber;j++){
                        position[i][j]=((Boundary<double> *)m_searchRange[j])->lower+(((Boundary<double> *)m_searchRange[j])->upper-((Boundary<double> *)m_searchRange[j])->lower)*Global::gp_uniformPro->Next();
                    }
                }
                setPosition(position);
                
                
                for(int i=0;i<m_numPeaks;i++)		delete []position[i];
                delete [] position;
                
                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                //added by ChenyangBu
                for (int i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    //mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                
                
            }
            void RealDBG::restoreInfor(){
                
                for(int i=0;i<m_numPeaks;i++){
                    if(!mp_whetherChange[i]){
                        gCopy(mpp_peak[i],mpp_prePeak[i],m_dimNumber);
                        mp_height[i]=mp_preHeight[i];
                        mp_width[i]=mp_preWidth[i];
                    }
                }
                
            }
            void RealDBG::initialize(bool risMFRB,const ChangeType rT, const bool rFlagDimChange, const bool rFlagNumPeakChange){
                m_flagDimensionChange=rFlagDimChange;
                setNumPeaksChange(rFlagNumPeakChange);
                //m_flagNumPeaksChange=rFlagNumPeakChange;
                
                
                if(m_flagDimensionChange){
                    m_changeType.type=CT_Random;
                    m_dirDimensionChange=true;
                }else if(m_flagNumPeaksChange){
                    m_changeType.type=CT_Random;
                    m_dirNumPeaksChange=true;
                }
                else{
                    m_changeType.type=rT;
                }
                m_changeType.counter=0;
                
                if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)      setPeriod(12);
                else      setPeriod(0);
                
                
                double *t=new double[m_numPeaks];
                
                setChoaticConstant(3.67);
                //set height
                for(int i=0;i<m_numPeaks;i++){
                    if(!risMFRB){
                        if(m_changeType.type==CT_Chaotic)
                            t[i]=m_minHeight+(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next();
                        else
                            t[i]=50;
                        
                    }else{
                        if(m_changeType.type==CT_Chaotic)
                            t[i]=m_minHeight+(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next();
                        else
                            t[i]=50;
                        
                    }
                }
                setHeight(t);
                delete [] t;
                
                
                double **position;
                position=new double*[m_numPeaks];
                for(int i=0;i<m_numPeaks;i++)
                    position[i]=new double[m_dimNumber];
                for(int i=0;i<m_numPeaks;i++){
                    for(int j=0;j<m_dimNumber;j++){
                        if(!risMFRB)
                            position[i][j]=((Boundary<double> *)m_searchRange[j])->lower+(((Boundary<double> *)m_searchRange[j])->upper-((Boundary<double> *)m_searchRange[j])->lower)*Global::gp_uniformPro->Next();
                        else
                            position[i][j]=((Boundary<double> *)m_searchRange[j])->lower+(((Boundary<double> *)m_searchRange[j])->upper-((Boundary<double> *)m_searchRange[j])->lower)*Global::mfr_gp_uniformPro->Next();
                    }
                }
                setPosition(position);
                
                
                for(int i=0;i<m_numPeaks;i++)		delete []position[i];
                delete [] position;
                
                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                gCopy(mp_preHeight,mp_height,m_numPeaks);
                gCopy(mp_preWidth,mp_width,m_numPeaks);
                
                //added by ChenyangBu
                for (int i=0; i< m_numPeaks; i++) {
                    mp_heightOrder[i]=i;
                    //mp_found[i]=false;
                }
                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                
                
            }
            
            
            
            
            
            
            class RotationDBG : public RealDBG
            {
            public://public for matlab version												//
                static RotationDBG * msp_rdbg;						// pointer of RotationDBG class, single instance class
                
                RotationDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,
                        const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange);
            public:
                virtual ~RotationDBG();
                static RotationDBG* getRotationDBG();
                static void deleteRotationDBG();
                static void initialize(int rDim, int rPeaks,const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange);
                static bool isInitialized();
                void initialize(const ChangeType T,float const rChangingRatio, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                
                RotationDBG& operator=(const RotationDBG &);
                virtual void  setWidth(const double w);
                virtual double evaluate( double const * x, bool rFlag=true);
                
            protected:
                virtual void parameterSetting(Problem * rP);
                void widthStandardChange();
                virtual void randomChange();
                virtual void smallStepChange();
                virtual void largeStepChange();
                virtual void recurrentChange();
                virtual void chaoticChange();
                virtual void recurrentNoisyChange();
                virtual void changeDimension();
                virtual void changeNumPeaks();
                
                //added by ChenyangBu
            public://public for matlab version
                RotationDBG(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double rTimes_con=4.,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
            protected:
                
                double conHeight;
                int mfr_IDGlobalRegion;
                double * RegionRadius;
                int * RegionRadiusOrder;
                double times_con;
                double times_len;//no use
            public:
                bool mfr_readData();
                static RotationDBG * msp_MFRs;
                void mfr_initialize(const ChangeType T,float const rChangingRatio=1.0, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                void mfr_change();
                void mpb_change();
                void setGlobalRegion(int peak_number);
                bool isInRegion(double *gen,int peak_number);
                bool isInGlobalRegion(double*gen);
                static RotationDBG * getMFRs();
                static void initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double rTimes_con=4.,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                static void initialize(bool risMFRB,const ChangeType T,float const rChangingRatio=1.0, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
                static void deleteMFRs();
                string getRegionRadius();
                double getRegionRadius(int rpeak);
                double distance(double *x1,double*x2);
                void mfr_reset();
                double get_conHeight();
                virtual void  freeMemory();
                double dummyEval(double *gen);
                double& getTimes_con(){
                    return this->times_con;
                }
                double& getTimes_len(){
                    times_len=0.0;
                    return this->times_len;
                }
                int getGlobalRegion(){
                    return mfr_IDGlobalRegion;
                }
                //added by Chenyang Bu
                void getDisconnectedFeasibleRegions();
                //end of Chenyang Bu
                
            };
            
            
            
            
            RotationDBG * RotationDBG::msp_rdbg=0;
            RotationDBG * RotationDBG::msp_MFRs=0;
            RotationDBG::RotationDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,
                    const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange):RealDBG(rId,rDimNumber,rEncoding,rNumPeaks){
                        //ctor
                        strcpy(ma_name,"Rotation DBG");
                        initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                    }
                    RotationDBG::RotationDBG(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,
                            const double rTimes_con,float const rChangingRatio,
                            const bool rFlagDimChange,const bool rFlagNumPeakChange):RealDBG(risMFRB,rId,rDimNumber,rEncoding,rNumPeaks){
                                //ctor
                                //this->isMFRB=risMFRB;
                                this->times_con=rTimes_con;
                                this->mfr_IDGlobalRegion=0;
                                //added by Chenyang Bu
                                if(this->isMFRB){
                                    
                                    strcpy(ma_name,"RotationDBG_MFRB");
                                    //mp_shift = new double[rDimNumber];
                                    //mpp_prevMovement = new double*[rNumPeaks];
                                    
                                    /*for (int i=0; i< rNumPeaks; i++){
                                     * mpp_prevMovement[i] =new double[rDimNumber];
                                     * }*/
                                    this->RegionRadius=new double [rNumPeaks];
                                    this->RegionRadiusOrder=new int [rNumPeaks];
                                    for(int i=0;i<rNumPeaks;i++){
                                        this->RegionRadius[i]=0.0;
                                        this->RegionRadiusOrder[i]=0;
                                    }
                                    
                                    //this->randArray=new double*[rNumPeaks];
                                    //for (int i=0; i< rNumPeaks; i++){
                                    //	this->randArray[i] =new double[rDimNumber];
                                    //}
                                    //for (int i=0; i< rNumPeaks; i++){
                                    //	for(int j=0;j<rDimNumber;j++){
                                    //		this->randArray[i][j]=Global::mfr_gp_uniformPro->Next()-0.5;
                                    //	}
                                    //}
                                    
                                    
                                    
                                    //initialize(risMFRB,rId, rDimNumber, rEncoding, rNumPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                    mfr_initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                    this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)rTimes_con;
                                }else{
                                    strcpy(ma_name,"Rotation DBG");
                                    initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                }
                            }
                            
                            RotationDBG::~RotationDBG()
                            {
                                //dtor
                                this->freeMemory();
                            }
                            void RotationDBG::freeMemory(){
                                delete[] this->RegionRadius;
                                delete[] this->RegionRadiusOrder;
                            }
                            void  RotationDBG::setWidth(const double w){
                                
                                for(int i=0;i<m_numPeaks;i++)
                                    if(m_changeType.type==CT_Chaotic){
                                        if(!this->isMFRB)
                                            mp_width[i]=m_minWidth+(m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next();
                                        else
                                            mp_width[i]=m_minWidth+(m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next();
                                        
                                    }
                                    else
                                        mp_width[i]=w;
                            };
                            
                            RotationDBG& RotationDBG::operator =(const RotationDBG & r_dbg){
                                if(this==& r_dbg) return *this;
                                RealDBG::operator =(r_dbg);
                                this->isMFRB=r_dbg.isMFRB;
                                this->conHeight=r_dbg.conHeight;
                                this->mfr_IDGlobalRegion=r_dbg.mfr_IDGlobalRegion;
                                this->times_con=r_dbg.times_con;
                                this->times_len=r_dbg.times_len;
                                gCopy(this->RegionRadius,r_dbg.RegionRadius,this->m_dimNumber);
                                gCopy(this->RegionRadiusOrder,r_dbg.RegionRadiusOrder,this->m_dimNumber);
                                return *this;
                            }
                            void RotationDBG::randomChange(){
                                
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                heightStandardChange();
                                widthStandardChange();
                                positionStandardChange(0);
                                
                                restoreInfor();
                                calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            void RotationDBG::recurrentChange(){
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                
                                double initial_angle;
                                
                                double height_range=m_maxHeight-m_minHeight;
                                double width_range=m_maxWidth-m_minWidth;
                                for(int i=0;i<m_numPeaks;i++){
                                    if(mp_whetherChange[i]==false) continue;
                                    initial_angle=(double)getPeriod()*i/m_numPeaks;
                                    mp_height[i]=m_minHeight+height_range*(sin(2*PI*(m_changeType.counter+initial_angle)/getPeriod())+1)/2.;
                                    mp_width[i]=m_minWidth+width_range*(sin(2*PI*(m_changeType.counter+initial_angle)/getPeriod())+1)/2.;
                                }
                                initial_angle=PI*(sin(2*PI*(m_changeType.counter)/getPeriod())+1)/12.;
                                positionStandardChange(initial_angle);
                                
                                restoreInfor();
                                //calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            void RotationDBG::chaoticChange(){
                                
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                for(int i=0;i<m_numPeaks;i++){
                                    if(mp_whetherChange[i]==false) continue;
                                    mp_height[i]=gChaoticValue(mp_height[i],m_minHeight,m_maxHeight);
                                    mp_width[i]=gChaoticValue(mp_width[i],m_minWidth,m_maxWidth);
                                }
                                positionStandardChange(0);
                                
                                restoreInfor();
                                calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            void RotationDBG::smallStepChange(){
                                
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                heightStandardChange();
                                widthStandardChange();
                                positionStandardChange(0);
                                
                                restoreInfor();
                                calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            void RotationDBG::largeStepChange(){
                                
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                heightStandardChange();
                                widthStandardChange();
                                positionStandardChange(0);
                                
                                restoreInfor();
                                calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            void RotationDBG::recurrentNoisyChange(){
                                for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
                                gCopy(mp_preHeight,mp_height,m_numPeaks);
                                gCopy(mp_preWidth,mp_width,m_numPeaks);
                                
                                double initial_angle;
                                double height_range=m_maxHeight-m_minHeight;
                                double width_range=m_maxWidth-m_minWidth;
                                double noisy;
#ifndef TestEffectofDynamicSeverity
                                for(int i=0;i<m_numPeaks;i++){
                                    if(mp_whetherChange[i]==false) continue;
                                    initial_angle=(double)getPeriod()*i/m_numPeaks;
                                    mp_height[i]=sinValueNoisy(m_changeType.counter,m_minHeight,m_maxHeight,height_range,initial_angle,m_noisySeverity,this->isMFRB);
                                    mp_width[i]=sinValueNoisy(m_changeType.counter,m_minWidth,m_maxWidth,width_range,initial_angle,m_noisySeverity,this->isMFRB);
                                }
#endif
                                initial_angle=PI*(sin(2*PI*(m_changeType.counter)/getPeriod())+1)/12.;
                                if(!this->isMFRB)
                                    noisy=m_noisySeverity*Global::gp_normalPro->Next();
                                else
                                    noisy=m_noisySeverity*Global::mfr_gp_normalPro->Next();
                                positionStandardChange(initial_angle+noisy);
                                restoreInfor();
                                calculateGlobalOptima();
                                updateNumberofChanges();
                                m_changeType.counter++;
                            }
                            double RotationDBG::evaluate( double const * x, bool rFlag){
                                
                                gCopy(mp_genes,x,m_dimNumber);
                                for(int i=0;i<m_numPeaks;i++){
                                    mp_fit[i]=0;
                                    for(int j=0;j<m_dimNumber;j++)
                                        mp_fit[i]+=(mp_genes[j]-mpp_peak[i][j])*(mp_genes[j]-mpp_peak[i][j]);
                                    if(mp_fit[i]!=0) mp_fit[i]=sqrt(mp_fit[i]/m_dimNumber);
                                    mp_fit[i]=mp_height[i]/(1+mp_width[i]*mp_fit[i]);
                                }
                                double obj=gExtremum(mp_fit,m_numPeaks,MAX_OPT);
                                
                                /*if(rFlag&&m_evals%m_changeFre==0) mp_bestSoFar[0]=obj;
                                 *
                                 * if(rFlag&&mp_bestSoFar[0]<obj) mp_bestSoFar[0]=obj;
                                 * if(rFlag)    m_evals++;
                                 * if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals) DynamicProblem::change();*/
                                
                                return  obj;
                            }
                            
                            void RotationDBG::widthStandardChange(){
                                double step;
                                for(int i=0;i<m_numPeaks;i++){
                                    if(mp_whetherChange[i]==false) continue;
                                    step=m_widthSeverity*standardChange(m_changeType.type,m_minWidth,m_maxWidth);
                                    mp_width[i]=mp_width[i]+step;
                                    
                                    if(mp_width[i]>m_maxWidth||mp_width[i]<m_minWidth) mp_width[i]=mp_width[i]-step;
                                    
                                }
                            }
                            
                            void RotationDBG::changeDimension(){
                                /// no need to preserve  previous information, e.g., positions, heights, width....
                                
                                
                                RotationDBG* r_dbg=new RotationDBG(RotationDBG_DOP,m_dimNumberTemp,C_DECIMAL,m_numPeaks,m_changeType.type
                                        ,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);
                                if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)
                                    r_dbg->setPeriod(m_period);
                                
                                r_dbg->parameterSetting(this);
                                r_dbg->calculateGlobalOptima();
                                
                                RealDBG::freeMemory();
                                DynamicContinuous::freeMemory();
                                Problem::freeMemory();
                                
                                Problem::allocateMemory(m_dimNumberTemp);
                                DynamicContinuous::allocateMemory(m_dimNumberTemp,m_numPeaks);
                                RealDBG::allocateMemory(m_dimNumberTemp,m_numPeaks);
                                
                                m_dimNumber=m_dimNumberTemp;
                                setPeriod(m_period);
                                *this=*r_dbg;
                                delete r_dbg;
                                
                            }
                            
                            void RotationDBG::parameterSetting(Problem * rP){
                                RealDBG::parameterSetting(rP);
                            }
                            
                            RotationDBG* RotationDBG::getRotationDBG(){
                                if(!RotationDBG::msp_rdbg){
                                    Throw(Logic_error("the RotationDBG problem is not initialized"));
                                    return NULL;
                                }
                                
                                return RotationDBG::msp_rdbg;
                                
                            }
                            RotationDBG* RotationDBG::getMFRs(){
                                if(!RotationDBG::msp_MFRs){
                                    Throw(Logic_error("the RotationDBG_MFRB problem is not initialized"));
                                    return NULL;
                                }
                                
                                return RotationDBG::msp_MFRs;
                            }
                            void RotationDBG::deleteRotationDBG(){
                                if(RotationDBG::msp_rdbg){
                                    delete RotationDBG::msp_rdbg;
                                    RotationDBG::msp_rdbg=0;
                                }
                            }
                            void RotationDBG::deleteMFRs(){
                                if(RotationDBG::msp_MFRs){
                                    int i;
                                    delete RotationDBG::msp_MFRs;
                                    RotationDBG::msp_MFRs=0;
                                }
                            }
                            void RotationDBG::mpb_change(){
                                DynamicProblem::change();
                                
                            }
                            void RotationDBG::mfr_change(){
                                DynamicProblem::change();
                                for (int i=0; i< m_numPeaks; i++) {
                                    mp_heightOrder[i]=i;
                                    //		mp_found[i]=false;
                                }
                                gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
                                this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
                                //Chenyang Bu <6/3/2015>
                                for(int i=0;i<m_numPeaks;i++){
                                    this->RegionRadius[i]=(this->mp_height[i]/this->conHeight-1.)*sqrt((double)this->getDimNumber())/this->mp_width[i];//sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
                                    this->RegionRadiusOrder[i]=i;
                                }
                                this->numFeasibleRegions=0;
                                for(int i=0;i<m_numPeaks;i++){
                                    this->regionIndex[i]=-1;
                                }
                                getDisconnectedFeasibleRegions();
                                //gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
                                //end of Chenyang Bu
                            }
                            void RotationDBG::initialize(int rDim, int rPeaks,const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
                                if(RotationDBG::msp_rdbg){
                                    Throw(Logic_error("the RotationDBG problem has been already initialized"));
                                    return;
                                }
                                if((unsigned int)rDim>msc_MaxDimensionNumber|| (unsigned int) rDim<msc_MinDimensionNumber){
                                    stringstream  oss;
                                    oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
                                    Throw(Out_of_range(oss.str().c_str()));
                                    return;
                                }
                                RotationDBG::msp_rdbg=new RotationDBG(RotationDBG_DOP,rDim,C_DECIMAL,rPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                
                            }
                            bool RotationDBG::isInitialized(){
                                if(RotationDBG::msp_rdbg!=0) return true;
                                else return false;
                                
                            }
                            void RotationDBG::initialize(const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
                                RealDBG::initialize(rT,rFlagDimChange,rFlagNumPeakChange);
                                setNumberofChanges(rChangingRatio);
                                setProblemType(MAX_OPT);
                                calculateGlobalOptima();
                            }
                            void RotationDBG::initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double rTimes_con,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
                                const int rDim=rDimNumber;
                                if(!risMFRB){
                                    if(RotationDBG::msp_rdbg){
                                        Throw(Logic_error("the RotationDBG problem has been already initialized"));
                                        return;
                                    }
                                    if((unsigned int)rDimNumber>msc_MaxDimensionNumber|| (unsigned int) rDimNumber<msc_MinDimensionNumber){
                                        stringstream  oss;
                                        oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
                                        Throw(Out_of_range(oss.str().c_str()));
                                        return;
                                    }
                                    RotationDBG::msp_rdbg=new RotationDBG(RotationDBG_DOP,rDim,C_DECIMAL,rNumPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                    
                                }
                                else{
                                    if(RotationDBG::msp_MFRs){
                                        Throw(Logic_error("the RotationDBG_MFRB problem has been already initialized"));
                                        return;
                                    }
                                    if((unsigned int)rDimNumber>msc_MaxDimensionNumber|| (unsigned int) rDimNumber<msc_MinDimensionNumber){
                                        stringstream  oss;
                                        oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
                                        Throw(Out_of_range(oss.str().c_str()));
                                        return;
                                    }
                                    RotationDBG::msp_MFRs=new RotationDBG(true,RotationDBG_DOP,rDim,C_DECIMAL,rNumPeaks,rT,rTimes_con,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
                                    
                                }
                            }
                            void RotationDBG::mfr_initialize(const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
                                RealDBG::initialize(true,rT,rFlagDimChange,rFlagNumPeakChange);
                                setNumberofChanges(rChangingRatio);
                                setProblemType(MAX_OPT);
                                //Chenyang Bu <27/3/2015>
                                this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)times_con;
                                for(int i=0;i<m_numPeaks;i++){
                                    this->RegionRadius[i]=(this->mp_height[i]/this->conHeight-1.)*sqrt((double)this->getDimNumber())/this->mp_width[i];//sqrt((double)this->m_dimNumber)*(this->mp_height[i]/this->conHeight-1.)/this->mp_width[i];
                                    this->RegionRadiusOrder[i]=i;
                                }
                                getDisconnectedFeasibleRegions();
                                //gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
                                //end of Chenyang Bu
                                //calculateGlobalOptima();
                            }
                            void  RotationDBG::changeNumPeaks(){
                                
                                RotationDBG* r_dbg=new RotationDBG(RotationDBG_DOP,m_dimNumber,C_DECIMAL,m_numPeaksTemp,m_changeType.type
                                        ,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);
                                
                                if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)
                                    r_dbg->setPeriod(m_period);
                                r_dbg->parameterSetting(this);
                                r_dbg->calculateGlobalOptima();
                                
                                
                                RealDBG::freeMemory();
                                DynamicContinuous::freeMemory();
                                
                                DynamicContinuous::allocateMemory(m_dimNumber,m_numPeaksTemp);
                                RealDBG::allocateMemory(m_dimNumber,m_numPeaksTemp);
                                
                                
                                m_numPeaks=m_numPeaksTemp;
                                setPeriod(m_period);
                                *this=*r_dbg;
                                delete r_dbg;
                                
                            }
                            void  RotationDBG::setGlobalRegion(int peak_number){
                                this->mfr_IDGlobalRegion=this->regionIndex[peak_number];
                            }
                            bool RotationDBG::isInRegion(double *gen,int peak_number){
                                if(this->RegionRadius[peak_number]<=0)
                                    return false;
                                double height=0.0;
                                int i=peak_number;
                                for(int j=0;j<m_dimNumber;j++)
                                    height+=(gen[j]-mpp_peak[i][j])*(gen[j]-mpp_peak[i][j]);
                                if(height!=0) height=sqrt(height/m_dimNumber);
                                height=mp_height[i]/(1+mp_width[i]*height);
                                if(height>=this->conHeight)
                                    return true;
                                else
                                    return false;
                            }
                            bool RotationDBG::isInGlobalRegion(double*gen){
                                for(int i=0;i<this->m_numPeaks;i++){
                                    if(this->isInRegion(gen,i))
                                    {
                                        if(this->regionIndex[i]==this->mfr_IDGlobalRegion)
                                            return true;
                                    }
                                }
                                return false;
                            }
                            double RotationDBG::dummyEval(double *gen){
                                gCopy(mp_genes,gen,m_dimNumber);
                                for(int i=0;i<m_numPeaks;i++){
                                    mp_fit[i]=0;
                                    for(int j=0;j<m_dimNumber;j++)
                                        mp_fit[i]+=(mp_genes[j]-mpp_peak[i][j])*(mp_genes[j]-mpp_peak[i][j]);
                                    if(mp_fit[i]!=0) mp_fit[i]=sqrt(mp_fit[i]/m_dimNumber);
                                    mp_fit[i]=mp_height[i]/(1+mp_width[i]*mp_fit[i]);
                                }
                                double obj=gExtremum(mp_fit,m_numPeaks,MAX_OPT);
                                
                                /*if(rFlag&&m_evals%m_changeFre==0) mp_bestSoFar[0]=obj;
                                 *
                                 * if(rFlag&&mp_bestSoFar[0]<obj) mp_bestSoFar[0]=obj;
                                 * if(rFlag)    m_evals++;
                                 * if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals) DynamicProblem::change();*/
                                
                                return  obj;
                            }
                            string RotationDBG::getRegionRadius(){
                                stringstream ss;
                                ss<<"[";
                                for(int i=0;i<(this->m_numPeaks-1);i++){
                                    ss<<this->RegionRadius[i]<<", ";
                                }
                                ss<<this->RegionRadius[this->m_numPeaks-1]<<"]"<<endl;
                                return ss.str();
                            }
                            double RotationDBG::getRegionRadius(int rpeak){
                                return this->RegionRadius[rpeak];
                            }
                            double RotationDBG::distance(double *x1,double*x2){
                                double dis=0.0;
                                for(int i=0;i<this->getDimNumber();i++){
                                    dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
                                }
                                dis=sqrt(dis);
                                return dis;
                            }
                            double RotationDBG::get_conHeight(){
                                return this->conHeight;
                            }
                            void RotationDBG::getDisconnectedFeasibleRegions(){
                                for(int i=0;i<this->m_numPeaks;i++){
                                    if(this->regionIndex[i]==-1){
                                        this->regionIndex[i]=this->numFeasibleRegions++;
                                        
                                    }
                                    for(int j=i+1;j<this->m_numPeaks;j++){
                                        double dis=0.0;
                                        for(int i1=0;i1<this->m_dimNumber;i1++){
                                            dis+=(this->mpp_peak[i][i1]-this->mpp_peak[j][i1])*(this->mpp_peak[i][i1]-this->mpp_peak[j][i1]);
                                        }
                                        dis=sqrt(dis);
                                        
                                        if(dis<=(this->RegionRadius[i]+this->RegionRadius[j])){
                                            this->regionIndex[j]=this->regionIndex[i];
                                        }
                                    }
                                }
                            }
                            
                            
                            
                            
                            void mexFunction(int nlhs,mxArray *plhs[],int nrhs, const mxArray *prhs[]){
#ifdef TestOutput
                                ofstream outfile;
                                outfile.open("data\\matlab_MFRB.txt",ofstream::out|ofstream::app);
                                if(!outfile){
                                    outfile<<"cannot open the outfile!"<<endl;
                                    system("pasue");
                                    exit(0);
                                    
                                }
#endif
                                gCreateRandPro(0.3);
                                
                                plhs[0]=mxCreateDoubleMatrix(1, 1, mxREAL);
                                double* out=mxGetPr(plhs[0]);
                                
                                int dim, numPeaks, changeFre, CurrentNumEvals;
                                ChangeType _changeType;
                                dim=(int)(*mxGetPr(prhs[0]));
                                numPeaks=(int)(*mxGetPr(prhs[1]));
                                changeFre=(int)(*mxGetPr(prhs[2]));
                                int tmpType=*mxGetPr(prhs[3]);
                                
                                switch(tmpType){
                                    case 0:
                                        _changeType= CT_Random;
                                        break;
                                    case 1:
                                        _changeType=CT_Linear;
                                        break;
                                    case 2:
                                        _changeType=CT_Cyclic;
                                        break;
                                    case 3:
                                        _changeType=CT_Decay;
                                        break;
                                    case 4:
                                        _changeType=CT_Chaotic;
                                        break;
                                    case 5:
                                        _changeType=CT_None;
                                        break;
                                    case 6:
                                        _changeType=CT_Recurrent;
                                        break;
                                    case 7:
                                        _changeType=CT_RecurrentNoisy;
                                        break;
                                    default:
                                        _changeType= CT_Recurrent;
                                        
                                }
                                CurrentNumEvals=(int)(*mxGetPr(prhs[4]));
                                
                                double * Indata=mxGetPr(prhs[5]);
                                int isMFRB=(int)*mxGetPr(prhs[6]);
                                double rTimes_con=(int)*mxGetPr(prhs[7]);
                                double rTimes_len=(int)*mxGetPr(prhs[8]);
                                int problem=(int)*mxGetPr(prhs[9]);//10000 for MFRB-C, 10001 for MFRB-R
                                int time=CurrentNumEvals/changeFre;
                                Global::g_changeFre=changeFre;
                                Global::g_tEvals=changeFre*100;
                                if((bool)isMFRB){
                                    if(problem==10000){
                                        RotationDBG *mpb=new RotationDBG((bool)isMFRB,-1,dim,C_UNSER_DEFINED,numPeaks,_changeType,rTimes_con);
                                        mpb->setChangeType(_changeType);
                                        for(int i=0;i<time;i++){
#ifdef TestOutput
                                            outfile<<"Time "<<i<<endl;
                                            outfile<<"constraintHeight: "<<mpb->get_conHeight()<<endl;
                                            outfile<<"regions:\n";
                                            mpb->printPeaks(outfile);
                                            outfile<<"Region radius:\n";
                                            outfile<<mpb->getRegionRadius();
                                            outfile<<"global region: "<<mpb->getGlobalRegion()<<endl;
#endif
                                            mpb->mfr_change();
                                            
                                        }
                                        out[0]=mpb->evaluate(Indata);
                                        delete mpb;
                                    }else{
                                        MovingPeak* mpb=new MovingPeak((bool)isMFRB,-1,dim,C_UNSER_DEFINED,numPeaks,rTimes_con,rTimes_len);
                                        mpb->setChangeType(_changeType);
                                        for(int i=0;i<time;i++){
#ifdef TestOutput
                                            outfile<<"Time "<<i<<endl;
                                            outfile<<"constraintHeight: "<<mpb->get_conHeight()<<endl;
                                            outfile<<"regions:\n";
                                            mpb->printPeaks(outfile);
                                            outfile<<"Region radius:\n";
                                            outfile<<mpb->getRegionRadius();
                                            outfile<<"global region: "<<mpb->getGlobalRegion()<<endl;
#endif
                                            mpb->mfr_change();
                                        }
                                        out[0]=mpb->evaluate(Indata);
                                        delete mpb;
                                    }
                                    
                                }else{
                                    MovingPeak* mpb=new MovingPeak((bool)isMFRB,-1,dim,C_UNSER_DEFINED,numPeaks,rTimes_con,rTimes_len);
                                    mpb->setChangeType(_changeType);
                                    for(int i=0;i<time;i++){
#ifdef TestOutput
                                        outfile<<"Time "<<i<<endl;
                                        outfile<<"peaks:\n";
                                        mpb->printPeaks(outfile);
#endif
                                        mpb->mpb_change();
                                    }
                                    out[0]=mpb->evaluate(Indata);
                                    delete mpb;
                                }
                                
                                gDeleteRandPro();
#ifdef TestOutput
                                outfile.close();
#endif
                                
                                // _CrtSetReportMode( _CRT_ERROR, _CRTDBG_MODE_DEBUG );
                                
                                //_CrtDumpMemoryLeaks();
                                return;
                            }
                            
