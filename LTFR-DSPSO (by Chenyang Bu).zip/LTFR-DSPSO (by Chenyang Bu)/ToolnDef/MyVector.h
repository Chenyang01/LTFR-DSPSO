//MyVector.h

#pragma once
#ifndef MyVector_H
#define MyVector_H

#include "Global.h"
using namespace std;

class MyVector{								// *****************Orthogonal rotation matrix***********************
public:
	int size;
	double *data;
public:
	MyVector();
	MyVector(const int s);
	~MyVector();
	MyVector &operator =(const MyVector & v);

	void operator +(const MyVector & v);
	void operator -(const MyVector & v);
	double operator *(const MyVector & v);
	void ProjectionToV(MyVector &v);
	void Normalization();
    void freeMemory();
    void allocateMemory(const int s);
};

#endif
