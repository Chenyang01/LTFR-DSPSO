/*************************************************************
[Usage]
*You could test different combinations of the proposed strategies via defining or undefining
a particular term in the file "stdafx.h". For example, if you would like to use the strategy of
tracking current feasible regions, the term "UseTrackingCurrentFeasibleRegionsStrategy"
should be defined (i.e., #define UseTrackingCurrentFeasibleRegionsStrategy).

*Note that the GNU Scientific Library (GSL) should be installed to conduct the gradient-based repair,
and the C++ environment needs to be configured to call the dynamic link library "libMyAdd.dll", 
which was created by the MATLAB written functions. The file "libMyAdd.dll" is required because we 
employ the MATLAB function "fmincon" to conduct the local search (SQP). Thus, the hybrid programming of
MATLAB and C++ is adopted.

*CONFIGURATION OF C++ ENVIRONMENT is the following, 
where "$MATLAB" is the installation directory of the software matlab, 
and $gsl is the directory of "gsl-64" (provided in the source files).
Step 1. Project menu - > Properties - > Configuration Properties - > Linker - > General category,  
add "$MATLAB\extern\lib\win64\microsoft" 
Step 2. Project menu - > Properties - > Configuration Properties - > Linker - > Input - >  Additional Dependencies, 
add "libmx.lib;libmat.lib;libeng.lib;libmex.lib;libMyAdd.lib;mclmcrrt.lib;libgsl-0.lib;libgslcblas-0.lib;"
Step 3. Configuration Properties - >  C/C++ - >  General - >  Additional Include Directories, 
add "$MATLAB\extern\include" and "$gsl\gsl-64\include"

*We created the dll "libMyAdd.dll" via Matlab2014b on a 64-bit windows, 
if an aother version of Matlab is used, 
you should recreate the dll file using your own matlab.
The following commands might be required.
"mex �C setup"
"mex -setup C++"
"mbuild �C setup"
"mex -setup C++ -client MBUILD"
"mex evaluateF.cpp"
"mcc -W cpplib:libMyAdd -T link:lib localSearch"

Once the dll "libMyAdd.dll" has been successfully re-created, the existing files "libMyAdd.dll", "libMyAdd.h", and 
"libMyAdd.lib" in the current directory should be overwritten by the newly created files.

*The source files that created the "libMyAdd.dll" are given in the folder "dll".
Note that to reproduce the results of Tables IX - X, you should define the term "TestEffectofDynamicSeverity" in 
this file, and use the codes in the directory "dll\Tables IX-X (TestEffectOfDynamicSeverity)".
It is because for Table IX and Table X, the size of each region was not changed in each run, i.e., the height and 
the width of the constraint function remains unchanged during a run.

*If you would like to test the benchmark G24 (proposed by Nguyen and Yao), 
the term "G24" in the file "stdafx.h" should be defined;
if you would like to test MFRB-R, then undefine "G24" and undefine "MFRB_C";
if you would like to test MFRB-C, then undefine "G24" and define "MFRB_C".
*************************************************************/

#pragma once
#define VERSION				"2015/10/12"
#define LAST_UPDATE			"2016/5/18"

#include<cmath>
#include <iostream>
#include<fstream>
#include <vector>
#include <deque>
#include <cfloat>
#include <cstdlib>
#include <ctime>
#include<stdlib.h>
#include <malloc.h>
#include<string>
#include <sstream>
#include <iomanip>
#include <stdio.h>
#include <direct.h>
#include <io.h>
#include   <algorithm>
#include <functional>
#if (_MSC_VER >= 1600)
#define __STDC_UTF_16__
#endif
#define _USE_MATH_DEFINES
#include "ToolnDef\Global.h"

//#define DSPSO //the original version of DSPSO. It should be noted that the species seeds are from current population, rather than pbests.

#ifdef DSPSO//original DSPSO
#define originalDSPSO //always evaluate the objective values, and without the proposed strategies
#define UseSortingRuleOfOriginalSPSO //sort according to the objective values, otherwise use the Deb's rules
#else //the proposed LTFR-DSPSO
#define UseTrackingCurrentFeasibleRegionsStrategy
#define UseLocatingFeasibleRegionsStrategy
#define UseTrackingPreviouslyAppearedFeasibleRegionsStrategy
#define UsePredictingFutureFeasibleRegionsStrategy 
#define UseLS //use the local search strategy SQP, where the matlab function fmincon is employed
#endif


#define G24 //test the benchmark G24
#ifndef G24 //test the MFRB
//#define MFRB_C// test MFRB-C, otherwise test MFRB-R
//#define TestEffectofDynamicSeverity //for Table IX and Table X
#endif

//#define TestFeasibleRatio
//#define TestMFRB
//#define TestSorting
//#define outputErrorInfo
//#define outputErrorInfo1
//#define OutputPopInfo
//#define ProInfo //output global optima
//#define OutputDection
//#define TestGlobalValue //just to test the global optima
//#define OutputInfomationPerChange //measure the performance of the algorithm per change
//#define OutputLS //output the information of local search
//#define OutputRepair //output the information of repair
//#define DEBUG

#define UseRepair //use the gradient-based repair strategy
//#define UseChangeDetectionStrategy //use the change-detection strategy, otherwise the changes are informed
#ifdef originalDSPSO
#define UseSortingRuleOfOriginalSPSO
#endif


#ifdef UseLS
#include "libMyAdd.h"
#endif
#include <io.h>
#include <direct.h>

enum ProblemType{G24_u=1,G24_1,G24_f,G24_uf,G24_2,G24_2u,G24_3,G24_3b,G24_3f,
	G24_4,G24_5,G24_6a,G24_6b,G24_6c,G24_6d,G24_7,G24v_3=3001,G24w_3=3003,G24v_3b=8001,G24w_3b=8003,
	mfrb_C=10000,mfrb_R=10001
};




