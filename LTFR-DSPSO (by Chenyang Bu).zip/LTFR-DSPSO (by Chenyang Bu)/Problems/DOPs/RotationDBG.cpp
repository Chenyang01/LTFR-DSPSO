/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 11 May 2011
// Last modified:

#include "RotationDBG.h"

RotationDBG * RotationDBG::msp_rdbg=0;
RotationDBG * RotationDBG::msp_MFRs=0;
RotationDBG::RotationDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,
                         const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange):RealDBG(rId,rDimNumber,rEncoding,rNumPeaks){
    //ctor
    strcpy(ma_name,"Rotation DBG");
    initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
}
RotationDBG::RotationDBG(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,
	                     const double par_RegionSize,float const rChangingRatio,
						 const bool rFlagDimChange,const bool rFlagNumPeakChange):RealDBG(risMFRB,rId,rDimNumber,rEncoding,rNumPeaks){
    //ctor
	//this->isMFRB=risMFRB;
	this->times_con=par_RegionSize;
	this->mfr_IDGlobalRegion=0;
	//added by Chenyang Bu
	if(this->isMFRB){

		strcpy(ma_name,"RotationDBG_MFRB");
		//mp_shift = new double[rDimNumber];
		//mpp_prevMovement = new double*[rNumPeaks];
		
		/*for (int i=0; i< rNumPeaks; i++){
			mpp_prevMovement[i] =new double[rDimNumber];			
		}*/
		this->RegionRadius=new double [rNumPeaks];
		this->RegionRadiusOrder=new int [rNumPeaks];
		for(int i=0;i<rNumPeaks;i++){
			this->RegionRadius[i]=0.0;
			this->RegionRadiusOrder[i]=0;
		}

		//this->randArray=new double*[rNumPeaks];
		//for (int i=0; i< rNumPeaks; i++){
		//	this->randArray[i] =new double[rDimNumber];
		//}
		//for (int i=0; i< rNumPeaks; i++){
		//	for(int j=0;j<rDimNumber;j++){
		//		this->randArray[i][j]=Global::mfr_gp_uniformPro->Next()-0.5;
		//	}
		//}



		//initialize(risMFRB,rId, rDimNumber, rEncoding, rNumPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
		mfr_initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
		this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)par_RegionSize;
	}else{
		strcpy(ma_name,"Rotation DBG");
		initialize(rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
	}
}

RotationDBG::~RotationDBG()
{
    //dtor
	this->freeMemory();
}
void RotationDBG::freeMemory(){
	delete[] this->RegionRadius;
	delete[] this->RegionRadiusOrder;
}
void  RotationDBG::setWidth(const double w){

    for(int i=0;i<m_numPeaks;i++)
        if(m_changeType.type==CT_Chaotic){
			if(!this->isMFRB)
				mp_width[i]=m_minWidth+(m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next();
			else
				mp_width[i]=m_minWidth+(m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next();
			
		}
        else
            mp_width[i]=w;
};

RotationDBG& RotationDBG::operator =(const RotationDBG & r_dbg){
	if(this==& r_dbg) return *this;
	RealDBG::operator =(r_dbg);
	this->isMFRB=r_dbg.isMFRB;
	this->conHeight=r_dbg.conHeight;
	this->mfr_IDGlobalRegion=r_dbg.mfr_IDGlobalRegion;
	this->times_con=r_dbg.times_con;
	this->times_len=r_dbg.times_len;
	gCopy(this->RegionRadius,r_dbg.RegionRadius,this->m_dimNumber);
	gCopy(this->RegionRadiusOrder,r_dbg.RegionRadiusOrder,this->m_dimNumber);
	return *this;
}
void RotationDBG::randomChange(){

    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	heightStandardChange();
	widthStandardChange();
	positionStandardChange(0);

	restoreInfor();
    calculateGlobalOptima();
     updateNumberofChanges();
	m_changeType.counter++;
}
void RotationDBG::recurrentChange(){
    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);


	double initial_angle;

	double height_range=m_maxHeight-m_minHeight;
	double width_range=m_maxWidth-m_minWidth;
	for(int i=0;i<m_numPeaks;i++){
	    if(mp_whetherChange[i]==false) continue;
		initial_angle=(double)getPeriod()*i/m_numPeaks;
		mp_height[i]=m_minHeight+height_range*(sin(2*PI*(m_changeType.counter+initial_angle)/getPeriod())+1)/2.;
		mp_width[i]=m_minWidth+width_range*(sin(2*PI*(m_changeType.counter+initial_angle)/getPeriod())+1)/2.;
	}
	initial_angle=PI*(sin(2*PI*(m_changeType.counter)/getPeriod())+1)/12.;
	positionStandardChange(initial_angle);

    restoreInfor();
	//calculateGlobalOptima();
	 updateNumberofChanges();
	m_changeType.counter++;
}
void RotationDBG::chaoticChange(){

    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	for(int i=0;i<m_numPeaks;i++){
	    if(mp_whetherChange[i]==false) continue;
		mp_height[i]=gChaoticValue(mp_height[i],m_minHeight,m_maxHeight);
		mp_width[i]=gChaoticValue(mp_width[i],m_minWidth,m_maxWidth);
	}
	positionStandardChange(0);

	restoreInfor();
    calculateGlobalOptima();
     updateNumberofChanges();
	m_changeType.counter++;
}
void RotationDBG::smallStepChange(){

    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	heightStandardChange();
	widthStandardChange();
	positionStandardChange(0);

	restoreInfor();
	calculateGlobalOptima();
	 updateNumberofChanges();
	m_changeType.counter++;
}
void RotationDBG::largeStepChange(){

    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	heightStandardChange();
	widthStandardChange();
	positionStandardChange(0);

	restoreInfor();
	calculateGlobalOptima();
	 updateNumberofChanges();
	m_changeType.counter++;
}
void RotationDBG::recurrentNoisyChange(){	
    for (int i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	double initial_angle;
	double height_range=m_maxHeight-m_minHeight;
	double width_range=m_maxWidth-m_minWidth;
	double noisy;
#ifndef TestEffectofDynamicSeverity
	for(int i=0;i<m_numPeaks;i++){
        if(mp_whetherChange[i]==false) continue;
		initial_angle=(double)getPeriod()*i/m_numPeaks;
		mp_height[i]=sinValueNoisy(m_changeType.counter,m_minHeight,m_maxHeight,height_range,initial_angle,m_noisySeverity,this->isMFRB);
		mp_width[i]=sinValueNoisy(m_changeType.counter,m_minWidth,m_maxWidth,width_range,initial_angle,m_noisySeverity,this->isMFRB);
		//cout<<"height["<<i<<"]: "<<mp_height[i]<<", mp_width["<<i<<"]\n";
	}
#endif
	initial_angle=PI*(sin(2*PI*(m_changeType.counter)/getPeriod())+1)/12.;	
	if(!this->isMFRB)
		noisy=m_noisySeverity*Global::gp_normalPro->Next();
	else
		noisy=m_noisySeverity*Global::mfr_gp_normalPro->Next();
	positionStandardChange(initial_angle+noisy);	
	//this->printPeaks();
    restoreInfor();
	calculateGlobalOptima();
    updateNumberofChanges();
	m_changeType.counter++;
}
double RotationDBG::evaluate( double const * x, bool rFlag){

	gCopy(mp_genes,x,m_dimNumber);
	for(int i=0;i<m_numPeaks;i++){
		mp_fit[i]=0;
		for(int j=0;j<m_dimNumber;j++)
			mp_fit[i]+=(mp_genes[j]-mpp_peak[i][j])*(mp_genes[j]-mpp_peak[i][j]);
		if(mp_fit[i]!=0) mp_fit[i]=sqrt(mp_fit[i]/m_dimNumber);
		mp_fit[i]=mp_height[i]/(1+mp_width[i]*mp_fit[i]);
	}
	double obj=gExtremum(mp_fit,m_numPeaks,MAX_OPT);

	/*if(rFlag&&m_evals%m_changeFre==0) mp_bestSoFar[0]=obj;

	if(rFlag&&mp_bestSoFar[0]<obj) mp_bestSoFar[0]=obj;
    if(rFlag)    m_evals++;
    if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals) DynamicProblem::change();*/

	return  obj;
}

void RotationDBG::widthStandardChange(){
	double step;
	for(int i=0;i<m_numPeaks;i++){
        if(mp_whetherChange[i]==false) continue;
		step=m_widthSeverity*standardChange(m_changeType.type,m_minWidth,m_maxWidth);
		mp_width[i]=mp_width[i]+step;

		if(mp_width[i]>m_maxWidth||mp_width[i]<m_minWidth) mp_width[i]=mp_width[i]-step;

	}
}

void RotationDBG::changeDimension(){
    /// no need to preserve  previous information, e.g., positions, heights, width....


	RotationDBG* r_dbg=new RotationDBG(RotationDBG_DOP,m_dimNumberTemp,C_DECIMAL,m_numPeaks,m_changeType.type
                                    ,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);
	if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)
		r_dbg->setPeriod(m_period);

	r_dbg->parameterSetting(this);
	r_dbg->calculateGlobalOptima();

    RealDBG::freeMemory();
	DynamicContinuous::freeMemory();
    Problem::freeMemory();

    Problem::allocateMemory(m_dimNumberTemp);
    DynamicContinuous::allocateMemory(m_dimNumberTemp,m_numPeaks);
    RealDBG::allocateMemory(m_dimNumberTemp,m_numPeaks);

    m_dimNumber=m_dimNumberTemp;
    setPeriod(m_period);
	*this=*r_dbg;
	delete r_dbg;

}

void RotationDBG::parameterSetting(Problem * rP){
	RealDBG::parameterSetting(rP);
}

RotationDBG* RotationDBG::getRotationDBG(){
     if(!RotationDBG::msp_rdbg){
        Throw(Logic_error("the RotationDBG problem is not initialized"));
        return NULL;
    }

    return RotationDBG::msp_rdbg;

}
RotationDBG* RotationDBG::getMFRs(){
	if(!RotationDBG::msp_MFRs){
        Throw(Logic_error("the RotationDBG_MFRB problem is not initialized"));
        return NULL;
    }

    return RotationDBG::msp_MFRs;
}
void RotationDBG::deleteRotationDBG(){
    if(RotationDBG::msp_rdbg){
        delete RotationDBG::msp_rdbg;
        RotationDBG::msp_rdbg=0;
    }
}
void RotationDBG::deleteMFRs(){
	if(RotationDBG::msp_MFRs){
		int i;
		delete RotationDBG::msp_MFRs;
		RotationDBG::msp_MFRs=0;
	}
}
void RotationDBG::mpb_change(){
    DynamicProblem::change();

}
void RotationDBG::mfr_change(){
	DynamicProblem::change();
	for (int i=0; i< m_numPeaks; i++) {
		mp_heightOrder[i]=i;
//		mp_found[i]=false;
	}
	gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
	this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
	//Chenyang Bu <6/3/2015>		
	for(int i=0;i<m_numPeaks;i++){
		this->RegionRadius[i]=(this->mp_height[i]/this->conHeight-1.)*sqrt((double)this->getDimNumber())/this->mp_width[i];//sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
		this->RegionRadiusOrder[i]=i;
	}
	this->numFeasibleRegions=0;
	for(int i=0;i<m_numPeaks;i++){		
		this->regionIndex[i]=-1;
	}
	getDisconnectedFeasibleRegions();
	//gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
	//end of Chenyang Bu
}

void RotationDBG::initialize(int rDim, int rPeaks,const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
    if(RotationDBG::msp_rdbg){
        Throw(Logic_error("the RotationDBG problem has been already initialized"));
        return;
    }
    if((unsigned int)rDim>msc_MaxDimensionNumber|| (unsigned int) rDim<msc_MinDimensionNumber){
        stringstream  oss;
        oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
        Throw(Out_of_range(oss.str().c_str()));
        return;
    }
    RotationDBG::msp_rdbg=new RotationDBG(RotationDBG_DOP,rDim,C_DECIMAL,rPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);

}
bool RotationDBG::isInitialized(){
    if(RotationDBG::msp_rdbg!=0) return true;
	else return false;

}
void RotationDBG::initialize(const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
    RealDBG::initialize(rT,rFlagDimChange,rFlagNumPeakChange);
    setNumberofChanges(rChangingRatio);
    setProblemType(MAX_OPT);
	calculateGlobalOptima();
}
void RotationDBG::initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double par_RegionSize,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
	const int rDim=rDimNumber;
	if(!risMFRB){
		if(RotationDBG::msp_rdbg){
			Throw(Logic_error("the RotationDBG problem has been already initialized"));
			return;
		}
		if((unsigned int)rDimNumber>msc_MaxDimensionNumber|| (unsigned int) rDimNumber<msc_MinDimensionNumber){
			stringstream  oss;
			oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
			Throw(Out_of_range(oss.str().c_str()));
			return;
		}
		RotationDBG::msp_rdbg=new RotationDBG(RotationDBG_DOP,rDim,C_DECIMAL,rNumPeaks,rT,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);

	}
	else{
		if(RotationDBG::msp_MFRs){
			Throw(Logic_error("the RotationDBG_MFRB problem has been already initialized"));
			return;
		}
		if((unsigned int)rDimNumber>msc_MaxDimensionNumber|| (unsigned int) rDimNumber<msc_MinDimensionNumber){
			stringstream  oss;
			oss<<"the number of dimensions should be within ["<<msc_MinDimensionNumber<<","<<msc_MaxDimensionNumber<<"]";
			Throw(Out_of_range(oss.str().c_str()));
			return;
		}
		RotationDBG::msp_MFRs=new RotationDBG(true,RotationDBG_DOP,rDim,C_DECIMAL,rNumPeaks,rT,par_RegionSize,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);

	}
}
void RotationDBG::mfr_initialize(const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange){
    RealDBG::initialize(true,rT,rFlagDimChange,rFlagNumPeakChange);
	setNumberofChanges(rChangingRatio);
	setProblemType(MAX_OPT);
	//Chenyang Bu <27/3/2015>
	this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)times_con;
	for(int i=0;i<m_numPeaks;i++){
		this->RegionRadius[i]=(this->mp_height[i]/this->conHeight-1.)*sqrt((double)this->getDimNumber())/this->mp_width[i];//sqrt((double)this->m_dimNumber)*(this->mp_height[i]/this->conHeight-1.)/this->mp_width[i];
		this->RegionRadiusOrder[i]=i;
	}
	getDisconnectedFeasibleRegions();
	//gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
	//end of Chenyang Bu
	//calculateGlobalOptima();
}
void  RotationDBG::changeNumPeaks(){

    RotationDBG* r_dbg=new RotationDBG(RotationDBG_DOP,m_dimNumber,C_DECIMAL,m_numPeaksTemp,m_changeType.type
                                    ,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);

	if(m_changeType.type==CT_Recurrent||m_changeType.type==CT_RecurrentNoisy)
		r_dbg->setPeriod(m_period);
	r_dbg->parameterSetting(this);
	r_dbg->calculateGlobalOptima();


    RealDBG::freeMemory();
	DynamicContinuous::freeMemory();

    DynamicContinuous::allocateMemory(m_dimNumber,m_numPeaksTemp);
    RealDBG::allocateMemory(m_dimNumber,m_numPeaksTemp);


    m_numPeaks=m_numPeaksTemp;
    setPeriod(m_period);
	*this=*r_dbg;
	delete r_dbg;

}
void  RotationDBG::setGlobalRegion(int peak_number){
	this->mfr_IDGlobalRegion=this->regionIndex[peak_number];
}
bool RotationDBG::isInRegion(double *gen,int peak_number){
	if(this->RegionRadius[peak_number]<=0)
		return false;
	double height=0.0;
	int i=peak_number;
	for(int j=0;j<m_dimNumber;j++)
			height+=(gen[j]-mpp_peak[i][j])*(gen[j]-mpp_peak[i][j]);
		if(height!=0) height=sqrt(height/m_dimNumber);
		height=mp_height[i]/(1+mp_width[i]*height);
	if(height>=this->conHeight)
		return true;
	else
		return false;
}
bool RotationDBG::isInGlobalRegion(double*gen){	
	for(int i=0;i<this->m_numPeaks;i++){
		if(this->isInRegion(gen,i))
		{
			if(this->regionIndex[i]==this->mfr_IDGlobalRegion)
				return true;
		}
	}
	return false;
}
double RotationDBG::dummyEval(double *gen){
	gCopy(mp_genes,gen,m_dimNumber);
	for(int i=0;i<m_numPeaks;i++){
		mp_fit[i]=0;
		for(int j=0;j<m_dimNumber;j++)
			mp_fit[i]+=(mp_genes[j]-mpp_peak[i][j])*(mp_genes[j]-mpp_peak[i][j]);
		if(mp_fit[i]!=0) mp_fit[i]=sqrt(mp_fit[i]/m_dimNumber);
		mp_fit[i]=mp_height[i]/(1+mp_width[i]*mp_fit[i]);
	}
	double obj=gExtremum(mp_fit,m_numPeaks,MAX_OPT);

	/*if(rFlag&&m_evals%m_changeFre==0) mp_bestSoFar[0]=obj;

	if(rFlag&&mp_bestSoFar[0]<obj) mp_bestSoFar[0]=obj;
    if(rFlag)    m_evals++;
    if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals) DynamicProblem::change();*/

	return  obj;
}
string RotationDBG::getRegionRadius(){
	stringstream ss;
	ss<<"[";
	for(int i=0;i<(this->m_numPeaks-1);i++){
		ss<<this->RegionRadius[i]<<", ";
	}
	ss<<this->RegionRadius[this->m_numPeaks-1]<<"]"<<endl;
	return ss.str();
}
double RotationDBG::getRegionRadius(int rpeak){
	return this->RegionRadius[rpeak];
}
double RotationDBG::distance(double *x1,double*x2){
	double dis=0.0;
	for(int i=0;i<this->getDimNumber();i++){
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	}
	dis=sqrt(dis);
	return dis;
}
	
double RotationDBG::get_delta_t(){
	return this->conHeight;
}
void RotationDBG::getDisconnectedFeasibleRegions(){
	for(int i=0;i<this->m_numPeaks;i++){
		if(this->regionIndex[i]==-1){
			this->regionIndex[i]=this->numFeasibleRegions++;
			
		}
		for(int j=i+1;j<this->m_numPeaks;j++){
			double dis=0.0;
			for(int i1=0;i1<this->m_dimNumber;i1++){
				dis+=(this->mpp_peak[i][i1]-this->mpp_peak[j][i1])*(this->mpp_peak[i][i1]-this->mpp_peak[j][i1]);
			}
			dis=sqrt(dis);
			
			if(dis<=(this->RegionRadius[i]+this->RegionRadius[j])){
				this->regionIndex[j]=this->regionIndex[i];
			}
		}
	}
}
