/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 11 May 2011
// Last modified:
#ifndef ROTATIONDBG_H
#define ROTATIONDBG_H

#include "RealDBG.h"


class RotationDBG : public RealDBG
{
private:												//
	static RotationDBG * msp_rdbg;						// pointer of RotationDBG class, single instance class

	RotationDBG(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,
             const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange);
public:
	virtual ~RotationDBG();
    static RotationDBG* getRotationDBG();
	static void deleteRotationDBG();
	static void initialize(int rDim, int rPeaks,const ChangeType rT,float const rChangingRatio, const bool rFlagDimChange,const bool rFlagNumPeakChange);
    static bool isInitialized();
    void initialize(const ChangeType T,float const rChangingRatio, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);

	RotationDBG& operator=(const RotationDBG &);
	virtual void  setWidth(const double w);
	virtual double evaluate( double const * x, bool rFlag=true);

protected:
	virtual void parameterSetting(Problem * rP);
    void widthStandardChange();

	virtual void recurrentNoisyChange();
	
	///TODO note that the flowing change types are not implemented for MFRB,
	//because independant random series should be adopted for the constriant
	virtual void randomChange();
    virtual void smallStepChange();
    virtual void largeStepChange();
    virtual void recurrentChange();
    virtual void chaoticChange();    
    virtual void changeDimension();
    virtual void changeNumPeaks();

	
private:
	RotationDBG(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double par_RegionSize=4.,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
protected:
	
	double conHeight;
	int mfr_IDGlobalRegion;
	//double ** randArray;
	double * RegionRadius;
	int * RegionRadiusOrder;
	//
//	 double **mpp_prevMovement;/* to store every peak's previous movement */
	//double *mp_shift;
	double times_con;
	double times_len;//no use
public:
	bool mfr_readData();
	static RotationDBG * msp_MFRs;
	void mfr_initialize(const ChangeType T,float const rChangingRatio=1.0, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
	void mfr_change();
	void mpb_change();
	void setGlobalRegion(int peak_number);
	bool isInRegion(double *gen,int peak_number);
	bool isInGlobalRegion(double*gen);
	//virtual void linearChange();
	static RotationDBG * getMFRs();
	static void initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const ChangeType rT,const double par_RegionSize=4.,float const rChangingRatio=1.0,const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
	static void initialize(bool risMFRB,const ChangeType T,float const rChangingRatio=1.0, const bool rFlagDimChange=false,const bool rFlagNumPeakChange=false);
	static void deleteMFRs();
	string getRegionRadius();
	double getRegionRadius(int rpeak);
	double distance(double *x1,double*x2);
	void mfr_reset();
	double get_delta_t();
	 virtual void  freeMemory();
	double dummyEval(double *gen);
	double& getTimes_con(){
		return this->times_con;
	}
	double& getTimes_len(){
		times_len=0.0;
		return this->times_len;
	}
	int getGlobalRegion(){
		return mfr_IDGlobalRegion;
	}
	//added by Chenyang Bu
	void getDisconnectedFeasibleRegions();
	//end of Chenyang Bu
	
};

#endif // ROTATIONDBG_H
