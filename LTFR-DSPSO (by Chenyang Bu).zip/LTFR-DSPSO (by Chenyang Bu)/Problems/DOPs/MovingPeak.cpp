/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 11 May 2011
// Last modified:

#include "MovingPeak.h"
#include <math.h>
#define _USE_MATH_DEFINES

MovingPeak *MovingPeak::msp_MPs=0;
MovingPeak *MovingPeak::msp_MFRs=0;
MovingPeak::MovingPeak(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks){
	this->isMFRB=false;
	m_flagDimensionChange=rFlagDimChange;
	setNumPeaksChange(rFlagNumPeakChange);
	// m_flagNumPeaksChange=rFlagNumPeakChange;

	if(!readData()) exit(0);
	m_peaksFound=0;

	allocateMemory(m_dimNumber,m_numPeaks);
	strcpy(ma_name,"Moving Peak Benchmark");
	initialize();
	setNumberofChanges((int)(rChangingRatio*m_numPeaks));

	//m_proPar<<"Vlength:"<<m_vlength<<"; ";


}
MovingPeak::MovingPeak(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double par_RegionSize,const double stepSeverity, float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange):DynamicContinuous(rId,rDimNumber,rEncoding,rNumPeaks){
	this->isMFRB=risMFRB;
	m_flagDimensionChange=rFlagDimChange;
	setNumPeaksChange(rFlagNumPeakChange);
	this->times=stepSeverity;
	this->times_con=par_RegionSize;
	this->mfr_IDGlobalRegion=0;
	//this->conHeight=rConHeight;
	// m_flagNumPeaksChange=rFlagNumPeakChange;

	if(!this->isMFRB){
		if(!readData()) exit(0);
	}
	else{
		if(!this->mfr_readData()) exit(0);
	}
	m_peaksFound=0;

	allocateMemory(m_dimNumber,m_numPeaks);
	strcpy(ma_name,"Moving Feasible Regions Benchmark");
	if(this->isMFRB)
		mfr_initialize();
	else 
		this->initialize();
	setNumberofChanges((int)(rChangingRatio*m_numPeaks));
	//if(this->isMFRB)
	//this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)par_RegionSize;
	//	m_proPar<<"Vlength:"<<m_vlength<<"; ";
}

void  MovingPeak::freeMemory(){
	int i;

	for (i=0; i< m_numPeaks; i++){
		delete [] mpp_prevMovement[i];
	}
	delete [] mpp_prevMovement;
	delete []  mp_shift ;
	delete []  mp_coveredPeaks ;
	delete [] mp_isTracked;
	delete [] mp_heightOrder;
	delete [] mp_found;
	//added by Chenyang Bu
	for (i=0; i< m_numPeaks; i++){
		delete [] this->randArray[i];
	}
	delete[] this->randArray;
	if(this->isMFRB){
		delete[] this->RegionRadius;
		delete[]this->RegionRadiusOrder;
		this->RegionRadius=0;
		this->RegionRadiusOrder=0;
	}
	mpp_prevMovement=0;
	mp_shift=0 ;
	mp_coveredPeaks=0 ;
	mp_isTracked=0;
	mp_heightOrder=0;
	mp_found=0;
}
void MovingPeak::allocateMemory(const int rDimNum, const int rPeaks){
	mp_shift = new double[rDimNum];
	mp_coveredPeaks = new int[rPeaks];
	mpp_prevMovement = new double*[rPeaks];
	mp_isTracked= new int [rPeaks];
	mp_heightOrder=new int [rPeaks];
	mp_found=new bool[rPeaks];
	for (int i=0; i< rPeaks; i++){
		mpp_prevMovement[i] =new double[rDimNum];
	}
	//added by Chenyang Bu
	this->randArray=new double*[rPeaks];
	for (int i=0; i< rPeaks; i++){
		this->randArray[i] =new double[rDimNum];
	}
	for (int i=0; i< rPeaks; i++){
		for(int j=0;j<rDimNum;j++){
			if(this->isMFRB==false)
				this->randArray[i][j]=Global::gp_uniformPro->Next()-0.5;
			else
				this->randArray[i][j]=Global::mfr_gp_uniformPro->Next()-0.5;
		}
	}
	if(this->isMFRB){
		this->RegionRadius=new double [rPeaks];
		this->RegionRadiusOrder=new int [rPeaks];
		for(int i=0;i<rPeaks;i++){
			this->RegionRadius[i]=0.0;
			this->RegionRadiusOrder[i]=0;
		}
	}


}
bool MovingPeak::readData(){

	/***************************************
	//		m_F		Evaluation Function
	//		1		constant_basis_func()
	//		2		five_peak_basis_func()
	//		3		peak_function1()
	//		4		peak_function_cone()
	//		5		peak_function_hilly()
	//		6		peak_function_twin()
	**************************************
	in>>temp>>m_vlength; // distance by which the peaks are moved, severity
	lambda determines whether there is a direction of the movement, or whether
	they are totally random. For lambda = 1.0 each move has the same direction,
	while for lambda = 0.0, each move has a random direction
	//in>>temp>>lambda;
	//in>>temp>>m_useBasisFunction;  if set to 1, a static landscape (basis_function) is included in the fitness evaluation
	}*/

	m_F=3;
	m_lambda=0.0;
	m_useBasisFunction=0;
	m_vlength=2.0;
	m_calculateRightPeak = 1; /* saves computation time if not needed  set to 0 */
	m_minHeight = 5.0;
	m_maxHeight = 15.0;
	m_standardHeight = 5.0;
	m_heightSeverity=7.0; /* severity of height changes, larger numbers  mean larger severity */
	m_minWidth =0.1 ;
	m_maxWidth = 2.0;
	m_standardWidth = 0.5;	
	m_widthSeverity = 1.0; /* severity of width changes, larger numbers mean larger severity */

	return true;

}
bool MovingPeak::mfr_readData(){
	m_F=3;
	m_lambda=1.0;
	m_useBasisFunction=0;
	//m_vlength=0.1;
	m_calculateRightPeak = 1; /* saves computation time if not needed  set to 0 */
	m_minHeight = 30.0;
	m_maxHeight = 70.0;
	m_standardHeight = 50.0;
	m_minWidth = 1.0 ;
	m_maxWidth = 12.0;
	m_standardWidth = 1.0;
	m_heightSeverity=7.0; /* severity of height changes, larger numbers  mean larger severity */
	m_widthSeverity = 0.01; /* severity of width changes, larger numbers mean larger severity */

	return true;
}
void MovingPeak::initialize(){
	int i=0,j=0;
	setSearchRange<double>(0,100);
	setProblemType(MAX_OPT);

	for ( i=0; i< m_numPeaks; i++)
		for ( j=0; j< m_dimNumber; j++){
			mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
			mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
		}
		//Chenyang Bu <2015/1/23>
		for (i=0;i<m_numPeaks; i++) 
			gCopy(this->mpp_initialPeak[i],mpp_peak[i],m_dimNumber);
		//end
		if (m_standardHeight <= 0.0){
			for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next()+m_minHeight;
		}else{
			for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
		}

		if (m_standardWidth <= 0.0){
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= (m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next()+m_minWidth;
		}else{
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= m_standardWidth;
		}

		calculateGlobalOptima();
		for (i=0; i< m_numPeaks; i++) {
			mp_heightOrder[i]=i;
			mp_found[i]=false;
		}
		gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);

		for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;
		for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
		gCopy(mp_preHeight,mp_height,m_numPeaks);
		gCopy(mp_preWidth,mp_width,m_numPeaks);
		//added by Chenyang Bu <2015/1/23>
		gCopy(this->mpp_initialHeight,this->mp_height,m_numPeaks);
		gCopy(this->mpp_initialWidth,this->mp_width,m_numPeaks);
		//end
}
void MovingPeak::mfr_initialize(){
	int i=0,j=0;
	setSearchRange<double>(0,100);
	setProblemType(MAX_OPT);

	for ( i=0; i< m_numPeaks; i++)
		for ( j=0; j< m_dimNumber; j++){
			if(this->isMFRB==false)
				mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
			else
				mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
			if(this->isMFRB==false)
				mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
			else
				mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
		}
		//Chenyang Bu <2015/1/23>
		for (i=0;i<m_numPeaks; i++) 
			gCopy(this->mpp_initialPeak[i],mpp_peak[i],m_dimNumber);
		//end

		if (m_standardHeight <= 0.0){
			for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
		}else{
			for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
		}

		if (m_standardWidth <= 0.0){
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
		}else{
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= m_standardWidth;
		}
		//Chenyang Bu <6/3/2015>


		//end of Chenyang Bu
		calculateGlobalOptima();
		for (i=0; i< m_numPeaks; i++) {
			mp_heightOrder[i]=i;
			mp_found[i]=false;
		}
		gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
		//this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)times_con;
		this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
		for(i=0;i<m_numPeaks;i++){
			this->RegionRadius[i]=sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
			this->RegionRadiusOrder[i]=i;
		}
		gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);
		for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;
		for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
		gCopy(mp_preHeight,mp_height,m_numPeaks);
		gCopy(mp_preWidth,mp_width,m_numPeaks);
		//added by Chenyang Bu <2015/1/23>
		gCopy(this->mpp_initialHeight,this->mp_height,m_numPeaks);
		gCopy(this->mpp_initialWidth,this->mp_width,m_numPeaks);
		getDisconnectedFeasibleRegions();
		//end
}
void MovingPeak::set_m_F(int value){
	this->m_F=value;
}
void MovingPeak::setGlobalRegion(int peak_number){
	this->mfr_IDGlobalRegion=this->regionIndex[peak_number];
}
double MovingPeak::distance(double *x1,double*x2){
	double dis=0.0;
	for(int i=0;i<this->getDimNumber();i++){
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	}
	dis=sqrt(dis);
	return dis;
}
bool MovingPeak::isInRegion(double *gen,int peak_number){
	if(this->RegionRadius[peak_number]<=0)
		return false;
	double height=this->functionSelection(gen,peak_number);
	if(height>=this->conHeight)
		return true;
	else
		return false;
	/*double dis=this->distance(gen,this->mpp_peak[peak_number]);
	if(dis<=this->RegionRadius[peak_number])
	return true;
	else return false;*/

}
bool MovingPeak::isInGlobalRegion(double*gen){	
	for(int i=0;i<this->m_numPeaks;i++){
		if(this->isInRegion(gen,i))
		{
			if(this->regionIndex[i]==this->mfr_IDGlobalRegion)
				return true;
		}
	}
	return false;
}
void MovingPeak::reset(){
	int i=0,j=0;

	for ( i=0; i< m_numPeaks; i++)
		for ( j=0; j< m_dimNumber; j++){
			if(this->isMFRB==false){
				mpp_peak[i][j] = 100.0*Global::gp_uniformPro->Next();
				mpp_prevMovement[i][j] = Global::gp_uniformPro->Next()-0.5;
			}else{
				mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
				mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
			}
		}

		if (m_standardHeight <= 0.0){
			if(this->isMFRB==false)
				for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::gp_uniformPro->Next()+m_minHeight;
			else
				for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
		}else{
			for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
		}

		if (m_standardWidth <= 0.0){
			for (i=0; i< m_numPeaks; i++){
				if(this->isMFRB==false)
					mp_width[i]= (m_maxWidth-m_minWidth)*Global::gp_uniformPro->Next()+m_minWidth;
				else
					mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
			}
		}else{
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= m_standardWidth;
		}

		calculateGlobalOptima();
		m_changeCounter=0;
		//for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;  no need to be reset to 0 for different runs, accumulate the values of all runs

		for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
		gCopy(mp_preHeight,mp_height,m_numPeaks);
		gCopy(mp_preWidth,mp_width,m_numPeaks);
}
void MovingPeak::mfr_reset(){
	int i=0,j=0;

	for ( i=0; i< m_numPeaks; i++)
		for ( j=0; j< m_dimNumber; j++){
			mpp_peak[i][j] = 100.0*Global::mfr_gp_uniformPro->Next();
			mpp_prevMovement[i][j] = Global::mfr_gp_uniformPro->Next()-0.5;
		}

		if (m_standardHeight <= 0.0){
			for ( i=0; i< m_numPeaks; i++) mp_height[i]=(m_maxHeight-m_minHeight)*Global::mfr_gp_uniformPro->Next()+m_minHeight;
		}else{
			for (i=0; i< m_numPeaks; i++) mp_height[i]= m_standardHeight;
		}

		if (m_standardWidth <= 0.0){
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= (m_maxWidth-m_minWidth)*Global::mfr_gp_uniformPro->Next()+m_minWidth;
		}else{
			for (i=0; i< m_numPeaks; i++)
				mp_width[i]= m_standardWidth;
		}

		calculateGlobalOptima();
		m_changeCounter=0;
		//for ( i=0; i< m_numPeaks; i++) mp_isTracked[i]=0;  no need to be reset to 0 for different runs, accumulate the values of all runs

		for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
		gCopy(mp_preHeight,mp_height,m_numPeaks);
		gCopy(mp_preWidth,mp_width,m_numPeaks);
}
/* free disc space at end of program */
MovingPeak::~MovingPeak()
{
#ifdef Test
	if(this->isMFRB)
		cout<<"~MFRB\n";
	else
		cout<<"~movingPeak()\n";
#endif
	freeMemory();
	//this->deleteMFRs();
	//this->deleteMPs();
	//MovingPeak::msp_MPs=0;
	//MovingPeak::msp_MFRs=0;
}
string MovingPeak::getRegionRadius(){
	stringstream ss;
	ss<<"[";
	for(int i=0;i<(this->m_numPeaks-1);i++){
		ss<<this->RegionRadius[i]<<", ";
	}
	ss<<this->RegionRadius[this->m_numPeaks-1]<<"]"<<endl;
	return ss.str();
}
double MovingPeak::getRegionRadius(int rpeak){
	return this->RegionRadius[rpeak];
}
/* current_peak_calc determines the peak of the current best individual */
void MovingPeak::currentPeakCalc (double *gen)
{
	int i;
	double maximum = -100000.0, dummy;


	m_currentPeak = 0;
	maximum = functionSelection(gen, 0);
	for(i=1; i<m_numPeaks; i++){
		dummy = functionSelection(gen, i);
		if (dummy > maximum){
			maximum = dummy;
			m_currentPeak = i;
		}
	}
}


/* evaluation function */
double MovingPeak::evaluate (double const *gen, bool rFlag)
{

	int i;
	double maximum = -100000.0, dummy;

	for(i=0; i<m_numPeaks; i++)    {
		dummy = functionSelection(const_cast<double *>(gen), i);
		if (dummy > maximum)      maximum = dummy;
	}

	if (m_useBasisFunction) {

		dummy = functionSelection(const_cast<double *>(gen),-1);
		/* If value of basis function is higher return it */
		if (maximum < dummy)
			maximum = dummy;
	}
	if(rFlag) isTracked(gen);
	if(rFlag)    m_evals++;
	if(rFlag&&m_evals%m_changeFre==0&&m_evals<Global::g_tEvals){
		/*DynamicProblem::change();
		for (i=0; i< m_numPeaks; i++) {
		mp_heightOrder[i]=i;
		mp_found[i]=false;
		}
		gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);*/
	}
	return(maximum);
}
void MovingPeak::mfr_change(){
	//this->m_changeCounter++;

	DynamicProblem::change();

	for (int i=0; i< m_numPeaks; i++) {
		mp_heightOrder[i]=i;
		mp_found[i]=false;
	}
	gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);

	//this->conHeight=this->mp_height[this->mp_heightOrder[this->m_numPeaks-1]]/(double)this->times_con;
	//this->conHeight=this->mp_height[0]/(double)this->times_con;
	this->conHeight=this->mp_height[this->mp_heightOrder[0]]/(double)this->times_con;
	//Chenyang Bu <6/3/2015>		
	for(int i=0;i<m_numPeaks;i++){		
		this->RegionRadius[i]=sqrt((this->mp_height[i]/this->conHeight-1.)/this->mp_width[i]);
		this->RegionRadiusOrder[i]=i;
	}
	this->numFeasibleRegions=0;
	for(int i=0;i<m_numPeaks;i++){		
		this->regionIndex[i]=-1;
	}

	gQuickSort(this->RegionRadius,this->RegionRadiusOrder,0,this->m_numPeaks-1);

	getDisconnectedFeasibleRegions();

	//end of Chenyang Bu
}
void MovingPeak::mpb_change(){
	DynamicProblem::change();
	for (int i=0; i< m_numPeaks; i++) {
		mp_heightOrder[i]=i;
		mp_found[i]=false;
	}
	gQuickSort(mp_height,mp_heightOrder,0,m_numPeaks-1);
}
/* dummy evaluation function allows to evaluate without being counted */
double MovingPeak::dummyEval (double *gen)
{
	int i;
	double maximum = -100000.0, dummy;

	for(i=0; i<m_numPeaks; i++)
	{
		dummy = functionSelection(gen, i);
		if (dummy > maximum)
			maximum = dummy;
	}

	if (m_useBasisFunction) {

		dummy = functionSelection(gen,-1);
		/* If value of basis function is higher return it */
		if (maximum < dummy)
			maximum = dummy;
	}
	return(maximum);
}

/* whenever this function is called, the peaks are changed */
void MovingPeak::randomChange(){
	//cout<<"randomchange\n";
	int i,j;
	double sum, sum2, offset;

	for (i=0;i<m_numPeaks; i++) gCopy(mpp_prePeak[i],mpp_peak[i],m_dimNumber);
	gCopy(mp_preHeight,mp_height,m_numPeaks);
	gCopy(mp_preWidth,mp_width,m_numPeaks);

	for(i=0; i<m_numPeaks; i++){
		//cout<<i<<endl;
		if(mp_whetherChange[i]==false) continue;
		if(this->isMFRB)
			this->setVlength(this->times,i);
		/* shift peak locations */
		sum = 0.0;
		for (j=0; j<m_dimNumber; j++){
			if(!this->isMFRB)
				mp_shift[j]=Global::gp_uniformPro->Next()-0.5;
			else
				mp_shift[j]=Global::mfr_gp_uniformPro->Next()-0.5;
			sum += mp_shift[j]*mp_shift[j];
		}
		if(sum>0.0)		sum = m_vlength/sqrt(sum);
		else  sum = 0.0;                        /* only in case of rounding errors */

		sum2=0.0;
		for (j=0; j<m_dimNumber; j++){
			mp_shift[j]=sum*(1.0-m_lambda)*mp_shift[j]+m_lambda*mpp_prevMovement[i][j];
			sum2 += mp_shift[j]*mp_shift[j];
		}
		if(sum2>0.0)sum2 = m_vlength/sqrt(sum2);
		else     sum2 = 0.0;                      /* only in case of rounding errors */

		for(j=0; j<m_dimNumber; j++){
			mp_shift[j]*=sum2;
			mpp_prevMovement[i][j]= mp_shift[j];
			if ((mpp_peak[i][j]+mpp_prevMovement[i][j]) < ((Boundary<double> *)m_searchRange[j])->lower){
				mpp_peak[i][j] = 2.0*((Boundary<double> *)m_searchRange[j])->lower-mpp_peak[i][j]-mpp_prevMovement[i][j];
				mpp_prevMovement[i][j]*=-1.0;
			}
			else if((mpp_peak[i][j]+mpp_prevMovement[i][j]) > ((Boundary<double> *)m_searchRange[j])->upper){
				mpp_peak[i][j]= 2.0*((Boundary<double> *)m_searchRange[j])->upper-mpp_peak[i][j]-mpp_prevMovement[i][j];
				mpp_prevMovement[i][j]*=-1.0;
			}else
				mpp_peak[i][j] += mpp_prevMovement[i][j];
		}
#ifdef TestEffectofDynamicSeverity
		if(this->isMFRB==false)
#endif
		{
			/* change peak width */
			if(!this->isMFRB)
				offset = Global::gp_normalPro->Next()*m_widthSeverity;
			else
				offset = Global::mfr_gp_normalPro->Next()*m_widthSeverity;


			double range=m_maxWidth-m_minWidth;
			double exceed=0.0;
			if((mp_width[i]+offset) < m_minWidth) {
				exceed=m_minWidth-(mp_width[i]+offset);
				if(exceed>range)
					exceed-=((int)(exceed/range))*range;
				mp_width[i]=m_minWidth+exceed;
			}
			else if((mp_width[i]+offset) > m_maxWidth){
				exceed=(mp_width[i]+offset)-m_maxWidth;
				if(exceed>range)
					exceed-=((int)(exceed/range))*range;
				mp_width[i]=m_maxWidth-exceed;
			}
			else	mp_width[i] += offset;

			/*if ((mp_width[i]+offset) < m_minWidth)		mp_width[i] = 2.0*m_minWidth-mp_width[i]-offset;
			else if ((mp_width[i]+offset) > m_maxWidth)	mp_width[i]= 2.0*m_maxWidth-mp_width[i]-offset;
			else	mp_width[i] += offset;*/
			//cout<<i<<" "<<mp_width[i]<<endl;
			/* change peak height */
			if(!this->isMFRB)
				offset = m_heightSeverity*Global::gp_normalPro->Next();
			else
				offset = m_heightSeverity*Global::mfr_gp_normalPro->Next();


			range=m_maxHeight-m_minHeight;
			exceed=0.0;
			if((mp_height[i]+offset) < m_minHeight) {
				exceed=m_minHeight-(mp_height[i]+offset);
				if(exceed>range)
					exceed-=((int)(exceed/range))*range;
				mp_height[i]=m_minHeight+exceed;
			}
			else if((mp_height[i]+offset) > m_maxHeight){
				exceed=(mp_height[i]+offset)-m_maxHeight;
				if(exceed>range)
					exceed-=((int)(exceed/range))*range;
				mp_height[i]=m_maxHeight-exceed;
			}
			else	mp_height[i] += offset;


			/*if ((mp_height[i]+offset) < m_minHeight)	mp_height[i] = 2.0*m_minHeight-mp_height[i]-offset;
			else if ((mp_height[i]+offset) > m_maxHeight)	mp_height[i]= 2.0*m_maxHeight-mp_height[i]-offset;
			else	mp_height[i] += offset;*/
		}
	}

	calculateGlobalOptima();
	updateNumberofChanges();
	//cout<<"randomchange end\n";
}

/* Basis Functions */

/* This gives a constant value back to the eval-function that chooses the max of them */
double MovingPeak::constantBasisFunc(double *gen)
{
	return 0.0;
}

double MovingPeak::fivePeakBasisFunc(double *gen)
{
	int i,j;
	double maximum = -100000.0, dummy;
	static double basis_peak [5][7]=
	{
		{8.0,  64.0,  67.0,  55.0,   4.0, 0.1, 50.0},
		{50.0,  13.0,  76.0,  15.0,   7.0, 0.1, 50.0},
		{9.0,  19.0,  27.0,  67.0, 24.0, 0.1, 50.0},
		{66.0,  87.0,  65.0,  19.0,  43.0, 0.1, 50.0},
		{76.0,  32.0,  43.0,  54.0,  65.0, 0.1, 50.0}
	};
	for(i=0; i<5; i++)
	{
		dummy = (gen[0]-basis_peak[i][0])*(gen[0]-basis_peak[i][0]);
		for (j=1; j< m_dimNumber; j++)
			dummy += (gen[j]-basis_peak[i][j])*(gen[j]-basis_peak[i][j]);
		dummy = basis_peak[i][m_dimNumber+1]-(basis_peak[i][m_dimNumber]*dummy);
		if (dummy > maximum)
			maximum = dummy;
	}
	return maximum;
}

/* Peak Functions */

/* sharp peaks */
double MovingPeak::peakFunction1(double *gen, int peak_number)
{
	int j;
	double dummy;

	dummy = (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
	for (j=1; j< m_dimNumber; j++)
		dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);

	return mp_height[peak_number]/(1+mp_width[peak_number]*dummy);
}

double MovingPeak::peakFunctionCone(double *gen, int peak_number)
{
	int j;
	double dummy;

	dummy =  (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
	for (j=1; j< m_dimNumber; j++)    dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);

	if(dummy!=0)
		dummy =mp_height[peak_number]-mp_width[peak_number]*sqrt(dummy);


	return dummy;
}

double MovingPeak::peakFunctionHilly(double *gen, int peak_number)
{
	int j;
	double dummy;

	dummy =  (gen[0]-mpp_peak[peak_number][0])*(gen[0]-mpp_peak[peak_number][0]);
	for (j=1; j< m_dimNumber; j++)
		dummy += (gen[j]-mpp_peak[peak_number][j])*(gen[j]-mpp_peak[peak_number][j]);

	return mp_height[peak_number]- mp_width[peak_number]*dummy-0.01*sin(20.0*dummy);
}

double MovingPeak::peakFunctionTwin(double  *gen, int peak_number) /* two twin peaks moving together */
{
	int j;
	double maximum = -100000.0, dummy;
	static double twin_peak [7] = /* difference to first peak */
	{
		1.0,  1.0,  1.0,  1.0,   1.0, 0.0, 0.0,
	};

	dummy = pow(gen[0]-mpp_peak[peak_number][0],2);
	for (j=1; j< m_dimNumber; j++)
		dummy += pow(gen[j]-mpp_peak[peak_number][j],2);

	dummy = mp_height[peak_number]- mp_width[peak_number]*dummy;

	maximum = dummy;
	dummy = pow(gen[0]-(mpp_peak[peak_number][0]+twin_peak[0]),2);
	for (j=1; j< m_dimNumber; j++)
		dummy += pow(gen[j]-(mpp_peak[peak_number][j]+twin_peak[0]),2);

	dummy =  mp_height[peak_number]+twin_peak[m_dimNumber+1]-((mp_width[peak_number]+twin_peak[m_dimNumber])*dummy);
	if (dummy > maximum)
		maximum = dummy;

	return maximum;
}
double MovingPeak::functionSelection(double  *gen, int peak_number){
	double dummy;
	switch(m_F){
	case 1: {
		dummy=constantBasisFunc(gen);
		break;
			}
	case 2: {
		dummy=fivePeakBasisFunc(gen);
		break;
			}
	case 3: {
		dummy=peakFunction1(gen, peak_number);
		break;
			}
	case 4: {
		dummy=peakFunctionCone(gen, peak_number);
		break;
			}
	case 5: {
		dummy=peakFunctionHilly(gen, peak_number);
		break;
			}
	case 6: {
		dummy=peakFunctionTwin(gen, peak_number);
		break;
			}
	}
	return dummy;
}
/* The following procedures may be used to change the step size over time */

double MovingPeak::get_delta_t(){
	return this->conHeight;
}
void MovingPeak::changeStepsizeRandom () /* assigns vlength a value from a normal distribution */
{
	m_vlength = Global::gp_normalPro->Next();
}

void MovingPeak::changeStepsizeLinear() /* sinusoidal change of the stepsize, */
{
	static int counter = 1;
	static double frequency = 3.14159/20.0;  /* returns to same value after 20 changes */

	m_vlength = 1+ sin((double)counter*frequency);
	counter ++;
}

int MovingPeak::getRightPeak()  /* returns 1 if current best individual is on highest mpp_peak, 0 otherwise */
{
	bool flag=false;

	for(int i=0;i<m_numPeaks;i++){
		if(mp_globalOptimaIdx[i]==true && m_currentPeak == i){
			flag=true;
			break;
		}
	}

	return flag;
}
void MovingPeak::setVlength(const double s){
	m_vlength=s;

	/*size_t start, end;
	start=m_proPar.str().find("Vlength:");
	for(int i=start;i<m_proPar.str().size();i++){
		if(m_proPar.str()[i]==';') {
			end=i;
			break;
		}
	}
	stringstream ss;
	ss<<"Vlength:"<<m_vlength<<"; ";
	string result=m_proPar.str();
	result.replace(start,end-start+1, ss.str());
	m_proPar.str(result);*/

}
void MovingPeak::setVlength(const int rtimes, int rpeak){
	if(this->isMFRB==false) return;
	this->m_vlength=rtimes*sqrt((this->mp_height[rpeak]/this->conHeight-1)/this->mp_width[rpeak]);
	//this->m_vlength*=6;
	/*size_t start, end;
	start=m_proPar.str().find("Vlength:");
	for(int i=start;i<m_proPar.str().size();i++){
	if(m_proPar.str()[i]==';') {
	end=i;
	break;
	}
	}
	stringstream ss;
	ss<<"Vlength:"<<m_vlength<<"; ";
	string result=m_proPar.str();
	result.replace(start,end-start+1, ss.str());
	m_proPar.str(result);*/
}

MovingPeak * MovingPeak::getMPs(){
	if(!MovingPeak::msp_MPs){
		Throw(Logic_error("the MPB problem is not initialized"));
	}

	return MovingPeak::msp_MPs;
}
MovingPeak * MovingPeak::getMFRs(){
	if(!MovingPeak::msp_MFRs){
		Throw(Logic_error("the MFRB problem is not initialized"));
	}

	return MovingPeak::msp_MFRs;
}
void MovingPeak::deleteMPs(){
	if(MovingPeak::msp_MPs!=0){
		//	freeMemory();
		delete MovingPeak::msp_MPs;
	}
	MovingPeak::msp_MPs=0;
}
void MovingPeak::deleteMFRs(){
	if(MovingPeak::msp_MFRs!=0){
		//	freeMemory();


		delete MovingPeak::msp_MFRs;
	}
	MovingPeak::msp_MFRs=0;
}

bool MovingPeak::isInitialized(){
	if(MovingPeak::msp_MPs!=0) return true;
	else return false;
}

void MovingPeak::initialize(int rDim, int rPeaks,float const rChangingRatio,const bool rFlagDimChange, const bool flagNumPeakChange){
	if(MovingPeak::msp_MPs){
		Throw(Logic_error("the MPB problem has been already initialized"));
		return;
	}
	MovingPeak::msp_MPs=new MovingPeak(MovingPeak_DOP,rDim,C_DECIMAL,rPeaks,rChangingRatio,rFlagDimChange,flagNumPeakChange);
}
void MovingPeak::initialize(const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks, float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
	if(MovingPeak::msp_MPs){
		Throw(Logic_error("the MPB problem has been already initialized"));
		return;
	}
	MovingPeak::msp_MPs=new MovingPeak(rId, rDimNumber,rEncoding,rNumPeaks,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
}

void MovingPeak::initialize(bool risMFRB,const int rId, const int rDimNumber, const Encoding rEncoding, const int rNumPeaks,const double par_RegionSize,const double stepSeverity,float const rChangingRatio,const bool rFlagDimChange,const bool rFlagNumPeakChange){
	if(risMFRB){
		if(MovingPeak::msp_MFRs){
			Throw(Logic_error("the MFRB problem has been already initialized"));
			return;
		}
		MovingPeak::msp_MFRs=new MovingPeak(risMFRB,rId, rDimNumber,rEncoding,rNumPeaks,par_RegionSize,stepSeverity,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);
	}
	else{
		if(MovingPeak::msp_MPs){
			Throw(Logic_error("the MPB problem has been already initialized"));
			return;
		}
		MovingPeak::msp_MPs=new MovingPeak(risMFRB,rId, rDimNumber,rEncoding,rNumPeaks,par_RegionSize,stepSeverity,rChangingRatio,rFlagDimChange,rFlagNumPeakChange);

	}
}

void MovingPeak::changeNumPeaks(){


	MovingPeak* mpb=new MovingPeak(MovingPeak_DOP,m_dimNumber,C_DECIMAL,m_numPeaksTemp,m_changePeakRatio,m_flagDimensionChange,m_flagNumPeaksChange);


	mpb->parameterSetting(this);
	mpb->calculateGlobalOptima();

	freeMemory();
	DynamicContinuous::freeMemory();

	allocateMemory(m_dimNumber,m_numPeaksTemp);
	DynamicContinuous::allocateMemory(m_dimNumber,m_numPeaksTemp);

	m_numPeaks=m_numPeaksTemp;

	*this=*mpb;
	delete mpb;

}

void MovingPeak::parameterSetting(DynamicProblem * rP){
	DynamicContinuous::parameterSetting(rP);

	MovingPeak *mpb=static_cast<MovingPeak *>(rP);
	int dim=m_dimNumberTemp<rP->getDimNumber()?m_dimNumberTemp:rP->getDimNumber();
	int peaks=m_numPeaks<rP->getNumberofPeak()?m_numPeaks:rP->getNumberofPeak();

	m_F=mpb->m_F;
	m_vlength=mpb->m_vlength; 
	m_lambda=mpb->m_lambda;
	m_useBasisFunction=mpb->m_useBasisFunction;
	m_calculateRightPeak=mpb->m_calculateRightPeak ; 
	m_standardHeight=mpb->m_standardHeight;
	m_standardWidth=mpb->m_standardWidth;

	m_peaksFound==mpb->m_peaksFound;
	gCopy(mp_shift,mpb->mp_shift,dim);
	gCopy(mp_coveredPeaks,mpb->mp_coveredPeaks,peaks);
	gCopy(mp_isTracked,mpb->mp_isTracked,peaks);
	gCopy(mp_heightOrder,mpb->mp_heightOrder,peaks);
	gCopy(mp_found,mpb->mp_found,peaks);


	for (int i=0; i<peaks; i++){
		gCopy(mpp_prevMovement[i],mpb->mpp_prevMovement[i],dim);

	}

}
MovingPeak &MovingPeak::operator=(MovingPeak &other){
	if(this==&other) return *this;

	DynamicContinuous::operator=(other);

	m_F=other.m_F;
	m_vlength=other.m_vlength; 
	m_lambda=other.m_lambda;
	m_useBasisFunction=other.m_useBasisFunction;
	m_calculateRightPeak=other.m_calculateRightPeak ; 
	m_standardHeight=other.m_standardHeight;
	m_standardWidth=other.m_standardWidth;
	m_peaksFound=other.m_peaksFound;

	gCopy(mp_shift,other.mp_shift,m_dimNumber);
	gCopy(mp_coveredPeaks,other.mp_coveredPeaks,m_numPeaks);
	gCopy(mp_isTracked,other.mp_isTracked,m_numPeaks);
	gCopy(mp_heightOrder,other.mp_heightOrder,m_numPeaks);
	gCopy(mp_found,other.mp_found,m_numPeaks);

	for (int i=0; i<m_numPeaks; i++){
		gCopy(mpp_prevMovement[i],other.mpp_prevMovement[i],m_dimNumber);

	}
	//added by Chenyang Bu <2015/1/23>
	this->par_chaoticChange=other.par_chaoticChange;
	for (int i=0; i<m_numPeaks; i++){
		gCopy(randArray[i],other.randArray[i],m_dimNumber);

	}
	gCopy(this->RegionRadius,other.RegionRadius,this->m_dimNumber);
	gCopy(this->RegionRadiusOrder,other.RegionRadiusOrder,this->m_dimNumber);
	this->times=other.times;
	this->times_con=other.times_con;
	this->conHeight=other.conHeight;
	this->mfr_IDGlobalRegion=other.mfr_IDGlobalRegion;
	this->isMFRB=other.isMFRB;
	//end of Chenyang Bu
	return *this;
}
int MovingPeak::getTrackNumber(int idex){
	return mp_isTracked[idex];
}

bool MovingPeak::isTracked(double const *gen){
	bool flag=false;
	for(int i=0;i<m_numPeaks;i++){
		double dis=0;
		for(int j=0;j<m_dimNumber;j++) dis+=(gen[j]-mpp_peak[i][j])*(gen[j]-mpp_peak[i][j]);
		dis=sqrt(dis);
		if(dis<=0.1){//Global::g_sigma
			int j=0;
			while(mp_heightOrder[j++]!=i&&j<m_numPeaks);
			if(!mp_found[i]){
				mp_isTracked[j-1]++;
				mp_found[i]=true;
				m_peaksFound++;
			}
			flag=true;
		}
	}

	return flag;
}
int MovingPeak::getPeaksFound(){
	return m_peaksFound;
}
void MovingPeak::getDisconnectedFeasibleRegions(){
	for(int i=0;i<this->m_numPeaks;i++){
		if(this->regionIndex[i]==-1){
			this->regionIndex[i]=this->numFeasibleRegions++;
			
		}
		for(int j=i+1;j<this->m_numPeaks;j++){
			double dis=0.0;
			for(int i1=0;i1<this->m_dimNumber;i1++){
				dis+=(this->mpp_peak[i][i1]-this->mpp_peak[j][i1])*(this->mpp_peak[i][i1]-this->mpp_peak[j][i1]);
			}
			dis=sqrt(dis);
			
			if(dis<=(this->RegionRadius[i]+this->RegionRadius[j])){
				this->regionIndex[j]=this->regionIndex[i];
			}
		}
	}
}
