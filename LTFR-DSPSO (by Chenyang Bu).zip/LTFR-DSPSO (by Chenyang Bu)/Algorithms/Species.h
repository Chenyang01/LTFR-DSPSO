#pragma once
#ifndef Species_h
#define Species_h
#include "../stdafx.h"

using namespace std;

class Species{
public:
	vector<int> fealist;
	vector<int> infealist;
	vector<int> totalList;
	int seed;
	int numTotal;
	int numFea;
	int numInfea;
	int numFeaInRegion[3];
	int numInfeaInRegion[3];
	int index;//distinguish each species with ordered numbers, i.e. 0,1,2,3 ...
	int nearestInfea;
	double disToInfea;//least distance between the seed and the infeasible pop
	int farestInfea;
	int numInRegion[3];
public:
	Species(int popSize);
	Species(const Species &C);
	Species& operator=(const Species &C);	//assignment operator
	~Species();
};
#endif
//};