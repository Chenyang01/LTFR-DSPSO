#pragma once
#ifndef Point_h
#define Point_h
#include "ModelInfo.h"
#include "../stdafx.h"
using namespace std;
class ModelInfo;

const double FeasThres=0;
class Point
{
	
protected:
	bool feasible;                      //in feasible region?	
	double MaxVio;                      //max violation
	double SumVio;                      //sum of absolute violations	
	double fitness;                      //the objective value 
	bool is_evaluated;                   //has the particle been evaluated? the value is true if it has already been evaluated
	void refresh();                     //refresh violation data
	
public:
	int index;
	double **nabla;                          //gradient matrix
	double *x;                          //location
	double *c;                          //values of each constraints
	double *v;                          //violation of each constraint
	ModelInfo *m_pModel;		//copy of model pointer
	//const ModelInfo* get_m_pModel()const {return m_pModel;}
    friend class MySwarm;
	friend class ModelInfo;

	
	Point(ModelInfo *m_pModel);           //makes a point, initializes
	~Point();                           //destructor
	Point(const Point &P);              //copy constructor
	Point& operator=(const Point &P);	//assignment operator
	bool operator<(const Point &P) const;   //for sorting points
	bool operator>(const Point &P) const;   //for sorting points

    bool is_feasible();
	double* getLocation();
	void getLocation(double *loc);      //copy location to loc
	double* getC();
	double* getV();
	double getMaxVio();                 //return the maxmum constraint violation
	double getSumVio();                 //return the sum of absolute constraint violations
	double getFitness();
	int getIndex();

	double getConVio(int i);            //get violation of constraint i
	double getJac(int i,int j);               //get jacobian value at offset i
	double getX(int ind);
	string OutputLocation();               //returns location in string format for output to file
	double getDist(Point *P);           //return the distance to other point 

	void setFea(bool fea);
	void setLocation(double *new_x);	//set point to specific location
	void setC(double*c);
	void setV(double*v);
	void setMaxVio(double value);
	void setSumVio(double value);
	void setFitness(double value);
	void setIndex(int value);

	void randLocation();		//set to random location in search space
	int addVec(double *nx, int n);      //add nx to x component wise, n is number of elements of nx
	bool dominate(Point& P);        //is P more promising?	

    void RangeKeeperBySetToBounds();			//reset out of bound variables
	void RangeKeeperByReflection();
	//in case the landscape has multiple disconnected feasible regions, this method check in which region
	//the given point belongs to
	int getRegionID();
	bool getIsEvaluated();
	void setIsEvaluated(bool val);
	bool isRedundant(Point & P);
	
};
#endif