/*************************************************************************
* Algorithm: Locating and Tracking Feasible Regions DSPSO (LTFR-DSPSO)
*************************************************************************
* Author: Chenyang Bu, Wenjian Luo and Lihua Yue
* Email: bucy1991@mail.ustc.edu.cn
* Language: C++ and MATLAB mixed programming
*************************************************************************
*  The codes were not developed professionally. The purpose of making the 
codes available is to allow other researchers to reproduce our reported results.

* If you make use of these codes, please cite our publications below. 
[1] Chenyang Bu, Wenjian Luo and Lihua Yue. Continuous Dynamic Constrained Optimization 
with an Ensemble of Locating and Tracking Feasible Regions Strategies. 
IEEE Transactions on Evolutionary Computation. doi: 10.1109/TEVC.2016.2567644
[2] Chenyang Bu, Wenjian Luo and Tao Zhu. Differential evolution with
a species-based repair strategy for constrained optimization. 
Proceedings of the 2014 IEEE Congress on Evolutionary Computation (CEC 2014). IEEE, 2014, pp. 967�C974.

* Permission is hereby granted to use this source code for any purpose without fee. 
However, for non-scientific purpose, please inform us the objective for using
"LTFR-DSPSO" before using the software:
E-mail address: bucy1991@mail.ustc.edu.cn
The reason is that we'd like to know the real applications.
*************************************************************************/
// Last modified: 18 May 2016
#ifndef SET_DEBUG_NEW_H
#define SET_DEBUG_NEW_H
#ifdef _DEBUG
#define DEBUG_CLIENTBLOCK   new( _CLIENT_BLOCK, __FILE__, __LINE__)
#else
#define DEBUG_CLIENTBLOCK
#endif
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#ifdef _DEBUG
#define new DEBUG_CLIENTBLOCK
#endif
#endif // end SET_DEBUG_NEW_H

#include "../stdafx.h"
#define CRTDBG_MAP_ALLOC
#include "Species.h"
#include "MySwarm.h"
using namespace std;

#define TimesOfRun 50
#ifdef TestGlobalValue
#define TimesOfRun 1
#endif
#ifdef TestFeasibleRatio
#define TimesOfRun 1
#endif

int main(){
	_CrtSetReportMode( _CRT_ERROR, _CRTDBG_MODE_DEBUG );	
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF|_CRTDBG_LEAK_CHECK_DF);

#ifdef UseLS
	if(!libMyAddInitialize()){
		cout<<"Could not initialize libMyAdd"<<endl;
		system("pause");
		exit(-1);
	}
#endif

	char fileName[ 255 ] ;	
	sprintf(fileName,"data\\");
	if(_access(fileName,0)==-1){
		if(_mkdir(fileName)){
			printf("make dir failed!");
			system("pasue");
			exit(0);
		}
	}

	ofstream outfile2;
	outfile2.open("data\\meanError.txt",ofstream::out|ofstream::app);
	if(!outfile2){
		outfile2<<"cannot open the outfile2!"<<endl;
		system("pasue");
		exit(0);

	}

#ifdef originalDSPSO
	////outfile1<<"[ 0 ]  Original DSPSO\n";
	outfile2<<"[ 0 ]  Original DSPSO\n";
#else
	////outfile1<<"[ 0 ]  Modified DSPSO\n";
	outfile2<<"[ 0 ]  Modified DSPSO\n";
#endif

#ifndef UseSortingRuleOfOriginalSPSO
	//outfile1<<"[ 1 ]  Deb's rules\n";
	outfile2<<"[ 1 ]  Deb's rules\n";
#else
	//outfile1<<"[ 1 ] SortAccordingToObjectiveValues\n";
	outfile2<<"[ 1 ] SortAccordingToObjectiveValues\n";
#endif

#ifdef UseLocatingFeasibleRegionsStrategy
	//outfile1<<"[ 2 ]  UseLocatingFeasibleRegionsStrategy\n";
	outfile2<<"[ 2 ]  UseLocatingFeasibleRegionsStrategy\n";
#endif

#ifdef UseTrackingCurrentFeasibleRegionsStrategy
	//outfile1<<"[ 3 ]  UseTrackingCurrentFeasibleRegionsStrategy\n";
	outfile2<<"[ 3 ]  UseTrackingCurrentFeasibleRegionsStrategy\n";
#endif
#ifdef	UseTrackingPreviouslyAppearedFeasibleRegionsStrategy //reload previous best solutions
	//outfile1<<"[ 4 ]  UseTrackingPreviouslyAppearedFeasibleRegionsStrategy\n";
	outfile2<<"[ 4 ]  UseTrackingPreviouslyAppearedFeasibleRegionsStrategy\n";
#endif
#ifdef UsePredictingFutureFeasibleRegionsStrategy //using species-based UsePredictingFutureFeasibleRegionsStrategy
	//outfile1<<"[ 5 ]  UsePredictingFutureFeasibleRegionsStrategy\n";
	outfile2<<"[ 5 ]  UsePredictingFutureFeasibleRegionsStrategy\n";
#endif
#ifdef UseLS
	//outfile1<<"[ 6 ]  UseLS\n";
	outfile2<<"[ 6 ]  UseLS\n";
#endif
#ifdef UsingRepair
	//outfile1<<"[ 7 ]  UsingRepair\n";
	outfile2<<"[ 7 ]  UseRepair\n";
#endif
#ifdef UseChangeDetectionStrategy
	outfile2<<"[ 8 ]  UseChangeDetectionStrategy\n";
#else
	outfile2<<"[ 8 ]  Changes are informed\n";
#endif
	//int problem[  ] ={3001,3003,8001,8003,7,8,10,11,16,10000};
	int problem[  ] ={G24v_3,G24w_3,G24v_3b,G24w_3b,G24_3,G24_3b,G24_4,G24_5,G24_7};
	int array_stepSeverity[]={1,2,8,16};
	int array_par_RegionSize []={2,4,8,16};
	double par1[  ] ={0.3,0.1,0.2,0.61,0.3,0.11,3.1,0.61};
	double par2[  ] ={2.79,2.79,2.99,1.36,2.79,2.52,2.99,1.36};
	double par3[  ] ={0.1,0.3,0.1,0.01,0.01,0.01,0.01,0.01};
	double error_all[ TimesOfRun ] ;
	double trackingError[ TimesOfRun ] ;
	double bestError_all[ TimesOfRun ] ;
	double NConst_all[ TimesOfRun ] ;
	double meanDisPerRun[ TimesOfRun ] ;
	double ARR[ TimesOfRun ] ;
	double NumRepair [TimesOfRun];
	double NEvalALS[TimesOfRun];
	double NConstRepair[TimesOfRun];

	int maxNumPeriods=10;
	int numPeaks=10, dim=2,  numRegions=5;
	int par_RegionSize=6;//$\nu$, a greater value is expected to result in larger feasible regions
	double stepSeverity=4; //$\zeta$, introduced for MFRB-R to make the change severity of each region center more controllable
	int ObjType=CT_Random, ConType=CT_Random;
	int numNEvalsPerPeriod=1000;
	int popSize=60;
	srand(time(0));
	double  SeedStep = 1.0/(double)(TimesOfRun+1);	


#ifndef G24 //MFRB
	///for(stepSeverity=2;stepSeverity<=10;stepSeverity+=2)
	for(numPeaks=10;numPeaks<=10;numPeaks+=5)
		for(ObjType=CT_Random;ObjType<= CT_Random ;ObjType+=1)
			//for(ConType=CT_RecurrentNoisy;ConType<= CT_RecurrentNoisy ;ConType+=1)//CT_RecurrentNoisy
			//for(par_RegionSize=2;par_RegionSize<=10;par_RegionSize=par_RegionSize+1)
			//for(stepSeverity=1;stepSeverity<=8;stepSeverity*=2)											

#ifndef TestEffectofDynamicSeverity
			for(dim=2;dim<=4;dim=dim+2)
				for(numRegions=5;numRegions<=20;numRegions=numRegions*2)
#else
			for(int index=0;index<4;index++)
#endif
			{
#ifdef MFRB_C 
				int i=mfrb_C;
				int ii=mfrb_C;
				ConType=CT_RecurrentNoisy;
				maxNumPeriods=60;
#ifdef TestEffectofDynamicSeverity
				par_RegionSize=array_par_RegionSize[index];
				numPeaks=10;
				dim=2;
				numRegions=5;
#endif
#else//MFRB-R
				int i=mfrb_R;
				int ii=mfrb_R;
				ConType=CT_Random;
#ifdef TestEffectofDynamicSeverity
				stepSeverity=array_stepSeverity[index];
				numPeaks=10;
				dim=2;
				numRegions=5;
#endif
#endif	
				cout<<"numPeak: "<<numPeaks<<", dim:"<<dim<<", stepSeverity: "<<stepSeverity<<", par_RegionSize: "<<par_RegionSize<<", numRegions: "<<numRegions<<", ObjType: "<<ObjType<<", ConType: "<<ConType<<endl;


#else //G24
	//for(numNEvalsPerPeriod=250;numNEvalsPerPeriod<=500;numNEvalsPerPeriod+=250)				
	for(int i=G24_u;i<=G24_7;i++)
		//for(int ii=0;ii<=8;ii++)
	//for(int ii=0;ii<=3;ii++)
	{	
		//int i=problem[ ii ] ;	
		if (i==G24_6d)i++;
		

		cout<<"problem: "<<i<<endl;
		outfile2<<"NEval: "<<numNEvalsPerPeriod<<endl<<endl<<"problem: "<<i<<endl;
#endif

#ifdef outputErrorInfo								

		sprintf(fileName,"data\\Comparison_%d.txt",i);
		ofstream outfile1;
		outfile1.open(fileName,ofstream::out|ofstream::app);
		if(!outfile1){
			outfile1<<"cannot open the //outfile1!"<<endl;
			system("pasue");
			exit(0);

		}

#endif
		double meanPeakCover=0., mean=0.0, meanNConst=0.0, std=0.0, stdNConst=0.0;
		double meanBestError=0.0, stdBestError=0.0;
		double meanTrackingError=0.0, stdTrackingError=0.0, meanDis=0., stdDis=0., meanARR=0., stdARR=0.;
		double feasible_time_ratio=0., trackingSpeed=0., ORT=0.0;
		int totalGen=0, totalInfeaGen=0;
		double detectRatio=0.0, detectInTimeRatio=0.0, detectErorrRatio=0.0;
		ChangeType mpb_type=(ChangeType)ObjType;
		ChangeType mfrb_type=(ChangeType)(ConType);

		double LSRate=0.0;
		int totalNEval=0;
		int totalLSNEval=0;
		double ratioALSCover=0.0, averageALSNumPerChange=0.0, totalNumRegions=0.0;
		double meanNumRepair=0.0, meanNEvalALS=0.0, meanNConstRepair=0.0;
		double stdNumRepair=0.0, stdNEvalALS=0.0, stdNConstRepair=0.0;

#ifndef G24
		outfile2<<"ProInfo [ popSize "<<popSize<<"  ] , [ dim "<<dim<<"  ] , [ numPeaks "<<numPeaks<<"  ] , [ numRegions, "<<numRegions<<" ] ,[ par_RegionSize "<<par_RegionSize<<" ] , [ stepSeverity "<<stepSeverity<<" ] \n";
		outfile2<<"[ MPB_changtype "<<mpb_type<<"  ] ,  [ MFRB_changeType "<<mfrb_type<<"  ] ,  [ NEvals "<<numNEvalsPerPeriod<<" ] , [ maxChangeNum "<<maxNumPeriods<<" ] "<<endl;
#ifdef outputErrorInfo
		outfile1<<"ProInfo [ popSize "<<popSize<<"  ] , [ dim "<<dim<<"  ] , [ numPeaks "<<numPeaks<<"  ] , [ numRegions, "<<numRegions<<" ] ,[ par_RegionSize "<<par_RegionSize<<" ] , [ stepSeverity "<<stepSeverity<<" ] \n";
		outfile1<<"[ MPB_changtype "<<mpb_type<<"  ] ,  [ MFRB_changeType "<<mfrb_type<<"  ] ,  [ NEvals "<<numNEvalsPerPeriod<<" ] , [ maxChangeNum "<<maxNumPeriods<<" ] "<<endl;
#endif

#endif									
		for(int j=0;j<TimesOfRun;j++){			
			cout<<j<<endl;										
			double S0=pow(dim,0.5)*20;
			double Q0=S0*1.5;
			gCreateRandAlg(SeedStep*(j+1)); // seed must satiesfy 0<seed<1
#ifndef G24
			if(i>=10000){
				gCreateRandPro(0.3);
				//cout<<SeedStep*(j+1)<<endl;
				gCreateRandAlg(SeedStep*(j+1)); // seed must satiesfy 0<seed<1
				MovingPeak::initialize(false,j,dim,C_UNSER_DEFINED,numPeaks);//init the objective function
				MovingPeak::getMPs()->setChangeType((ChangeType)ObjType);											
				Global::g_changeFre=numNEvalsPerPeriod;
				Global::g_tEvals=numNEvalsPerPeriod*maxNumPeriods;

#ifdef MFRB_C
				RotationDBG::initialize(true,j,dim,C_UNSER_DEFINED,numRegions,(ChangeType)ConType,par_RegionSize);	//init the constraint function								
				RotationDBG::getMFRs()->setChangeFre(numNEvalsPerPeriod);
				RotationDBG::getMFRs()->setChangeFre(numNEvalsPerPeriod);
				RotationDBG::getMFRs()->setMaxChangeNumber(Global::g_tEvals/numNEvalsPerPeriod);
#else
				MovingPeak::initialize(true,j,dim,C_UNSER_DEFINED,numRegions,par_RegionSize,stepSeverity);//init the constraint function
				MovingPeak::getMFRs()->setChangeType((ChangeType)ConType);
				MovingPeak::getMFRs()->setChangeFre(numNEvalsPerPeriod);
				MovingPeak::getMFRs()->setChangeFre(numNEvalsPerPeriod);
				MovingPeak::getMFRs()->setMaxChangeNumber(Global::g_tEvals/numNEvalsPerPeriod);
#endif
			}
#endif

			//ModelInfo ins(i,j,dim,S0,Q0,numNEvalsPerPeriod,maxNumPeriods);
			ModelInfo ins(i,j,dim,20,0.5,numNEvalsPerPeriod,maxNumPeriods);										



#ifdef ProInfo
			if(ins.Problem>=10000){
				ins.ofProInfo<<"dim: "<<ins.n_var<<", numPeak:"<<ins.mpb->getNumberofPeak()<<", numRegion: "<<ins.mfrb->getNumberofPeak()<<endl;
			}
#endif
			if(i>100&&i<10000){
				if(i%1000==1){
					ins.val_1=3.0;
					ins.val_2=3.0;//no use
					ins.val_3=3.0;//no use
				}else if(i%1000==3){
					ins.val_1=0.1 ;
					ins.val_2=0.1 ;
					ins.val_3=0.1 ;
				}

			}

#ifdef TestFeasibleRatio
			cout<<"Problem:  "<<i<<endl;
			ins.NEval=0;
			for(int test=0;test<1;test++){
				PSOAgent agent(&ins);
				int maxNum=10000000;
				int numFea=0, numInfea=0;
				for(int ii=1;ii<=maxNum;ii++){												
					agent.step();												
					ins.NEval--;
					if(agent.is_feasible()){
						numFea++;
						outfile1<<agent.OutputLocation()<<endl;													
					}
					agent.randLocation();
				}
				cout<<"Change: "<<test+1<<", "<<(double)numFea/(double)(maxNum)<<endl;

				system("pause");

				ins.NEval+=1000;
				ins.changeStep++;

				if(ins.Problem>=10000){
					ins.mpb->mpb_change();
					ins.mfrb->mfr_change();																								
					ins.delta_t=ins.mfrb->get_delta_t();
				}
			}
			ins.NEval=0;
			ins.changeStep=0;
			continue;

#endif
			MySwarm pop(popSize,&ins);
			
			if(j==0){
				outfile2<<"radius: "<<pop.getRadius()<<endl;
			}
#ifdef TestGlobalValue
			cout<<"Problem:  "<<i<<endl;
			ins.NEval=0;
			for(int test=0;test<=10;test++){
				ins.calculateDynamicGlobalOptimum();
				cout<<"Change "<<test+1<<"  "<<ins.getBestFitInActual()<<endl;
				cout<<"location: "<<ins.globalOptimum[0]<<", "<<ins.globalOptimum[1]<<endl;
				ins.NEval+=1000;
				ins.changeStep++;

				if(ins.Problem>=10000){
					ins.mpb->mpb_change();
					ins.mfrb->mfr_change();																								
					ins.delta_t=ins.mfrb->get_delta_t();
				}
			}
			ins.NEval=0;
			ins.changeStep=0;
			system("pause");
			//exit(0);
			continue;

#endif
			//main loop
			pop.mainStep();										

			//error_all[ j ] =pop.modifiedOfflineError/(double)ins.gen;//ins.offline_error;
			error_all[ j ] =ins.offline_error/(double)ins.gen;
#ifdef outputErrorInfo
			outfile1<<j<<"  "<<error_all[ j ]<<endl;
#endif
			bestError_all[ j ] =ins.bestError;
			trackingError[ j ] =ins.trackingError;
			NConst_all[ j ] =ins.NConst;
			totalNEval=ins.NEval;
			ARR[ j ] =ins.ARR_all;
			meanDisPerRun[ j ] =ins.meanDis;
			meanARR+=ins.ARR_all;
			mean+=error_all[ j ];//ins.offline_error;
			meanNConst+=ins.NConst;
			meanBestError+=ins.bestError;
			meanTrackingError+=ins.trackingError;
			//meanDis+=ins.meanDis;
			meanPeakCover+=ins.RegionCover;
			totalGen+=ins.gen;
			totalInfeaGen+=ins.numGenInfeasible;
			trackingSpeed+=ins.trackingSpeed_globalRegion;
			ORT+=pop.getORT();
			detectRatio+=pop.getTimeDetected();

			detectInTimeRatio+=pop.getTimeDetectedInTime();

			detectErorrRatio+=pop.getTimeDetectedError();

			ratioALSCover+=ins.NumCoverALS;
			averageALSNumPerChange+=ins.NumALS;
			totalNumRegions+=ins.TotalNumOfRegions;
			meanNEvalALS+=ins.NEvalALS;
			totalLSNEval=ins.NEvalALS;
			meanNConstRepair+=ins.NConstRepair;
			meanNumRepair+=ins.NumRepair;
			NEvalALS[j]=ins.NEvalALS;
			NConstRepair[j]=ins.NConstRepair;
			NumRepair[j]=ins.NumRepair;

			gDeleteRandAlg();
			if(i>=10000){
				gDeleteRandPro();

#ifdef MFRB_C
				RotationDBG::deleteMFRs();
#else
				MovingPeak::deleteMFRs();
#endif
				MovingPeak::deleteMPs();
			}
		}
		mean=mean/TimesOfRun;
		meanNConst=meanNConst/TimesOfRun;
		meanBestError=meanBestError/TimesOfRun;
		meanTrackingError=meanTrackingError/TimesOfRun;
		//meanDis/=TimesOfRun;
		meanARR/=TimesOfRun;
		meanPeakCover/=TimesOfRun;
		ORT/=(double)totalGen;//TimesOfRun;
		feasible_time_ratio=1-(double)totalInfeaGen/(double)totalGen;
		trackingSpeed/=TimesOfRun;
		detectRatio/=(double)(TimesOfRun*maxNumPeriods);
		detectInTimeRatio/=(double)(TimesOfRun*maxNumPeriods);
		detectErorrRatio/=(double)(TimesOfRun*maxNumPeriods);

		ratioALSCover/=totalNumRegions;
		averageALSNumPerChange/=(double)(TimesOfRun*maxNumPeriods);

		meanNEvalALS/=(double)(TimesOfRun);
		meanNConstRepair/=(double)(TimesOfRun);
		meanNumRepair/=(double)(TimesOfRun);

		for(int j=0;j<TimesOfRun;j++){
			std+=(mean-error_all[ j ] )*(mean-error_all[ j ] );
			stdNConst+=(meanNConst-NConst_all[ j ] )*(meanNConst-NConst_all[ j ] );
			stdBestError+=(meanBestError-bestError_all[ j ] )*(meanBestError-bestError_all[ j ] );
			stdTrackingError+=(meanTrackingError-trackingError[ j ] )*(meanTrackingError-trackingError[ j ] );
			//stdDis+=(meanDis-meanDisPerRun[ j ] )*(meanDis-meanDisPerRun[ j ] );
			stdARR+=(meanARR-ARR[ j ] )*(meanARR-ARR[ j ] );
			stdNEvalALS+=(meanNEvalALS-NEvalALS[j])*(meanNEvalALS-NEvalALS[j]);
			stdNConstRepair+=(meanNConstRepair-NConstRepair[j])*(meanNConstRepair-NConstRepair[j]);
			stdNumRepair+=(meanNumRepair-NumRepair[j])*(meanNumRepair-NumRepair[j]);
		}
		std=std/TimesOfRun;
		stdNConst=stdNConst/TimesOfRun;
		stdBestError/=TimesOfRun;
		stdTrackingError/=TimesOfRun;
		stdDis/=TimesOfRun;
		stdARR/=TimesOfRun;
		stdNEvalALS/=TimesOfRun;
		stdNConstRepair/=TimesOfRun;
		stdNumRepair/=TimesOfRun;

		std=sqrt(std);
		stdNConst=sqrt(stdNConst);
		stdBestError=sqrt(stdBestError);
		stdTrackingError=sqrt(stdTrackingError);
		stdDis=sqrt(stdDis);
		stdARR=sqrt(stdARR);
		stdNEvalALS=sqrt(stdNEvalALS);
		stdNConstRepair=sqrt(stdNEvalALS);
		stdNumRepair=sqrt(stdNEvalALS);

		LSRate=(double)totalLSNEval/(double)totalNEval;

		outfile2<<"[ Measure_1 ]  OfflineError  "<<mean<<"  std  "<<std<<endl;
		outfile2<<"[ Measure_2 ]  NConst  "<<meanNConst<<"  stdNConst  "<<stdNConst<<endl;
		outfile2<<"[ Measure_3 ]  BestError  "<<meanBestError<<"  stdBestError  "<<stdBestError<<endl;
		outfile2<<"[ Measure_4 ]  TrackingError  "<<meanTrackingError<<"  stdTrackingError  "<<stdTrackingError<<endl;		
#ifndef G24
		outfile2<<"[ Measure_5 ]  ORT "<<ORT<<endl;
		outfile2<<"[ Measure_6 ]  PeakCover "<<meanPeakCover<<endl;
#endif
		outfile2<<"[ Measure_7 ]  feasible_time_ratio "<<feasible_time_ratio<<endl;
		outfile2<<"[ Measure_8 ]  tracking_speed "<<trackingSpeed<<endl;
		outfile2<<"[ Measure_9 ]  LSRate "<<LSRate<<endl;
		outfile2<<"[ Measure_10 ]  detectRatio "<<detectRatio<<"  detectInTimeRatio "<<detectInTimeRatio<<endl;
		outfile2<<"[ Measure_11 ]  detectErorrRatio "<<detectErorrRatio<<endl;
		outfile2<<"[ Measure_12 ]  LSCover "<<ratioALSCover<<endl;
		outfile2<<"[ Measure_13 ]  averageLSTimes "<<averageALSNumPerChange<<endl;
		outfile2<<"[ Measure_14 ]  meanNEvalLSPerRun "<<meanNEvalALS<<" stdNEvalALS "<<stdNEvalALS<<endl;
		outfile2<<"[ Measure_15 ]  meanNConstRepair "<<meanNConstRepair<<" stdNConstRepair "<<stdNConstRepair<<endl;
		outfile2<<"[ Measure_16 ]  meanNumRepair "<<meanNumRepair<<" stdNumRepair "<<stdNumRepair<<endl;
		
		//outfile1<<"\n";
		outfile2<<"\n";
		
#ifdef outputErrorInfo
		outfile1.close();
#endif

	}
	

#ifdef UseLS
	libMyAddTerminate();
#endif
	outfile2.close();
	//#ifdef outputErrorInfo
	//							outfile1.close();
	//#endif
	_CrtDumpMemoryLeaks();							
	return 1;
}
