#include "MemoryEntry.h"


MemoryEntry::MemoryEntry(PSOAgent & fea,PSOAgent & infea, double value):feaInd(fea),infeaInd(infea){
	this->flag=true;
	this->dis=value;	
	
	
}
MemoryEntry::MemoryEntry(PSOAgent&fea):feaInd(fea),infeaInd(fea){
	this->flag=false;
	this->dis=1000000;	
}
MemoryEntry::MemoryEntry(PSOAgent&fea,bool isPbest):feaInd(fea),infeaInd(fea){
	this->flag=false;
	this->dis=1000000;
	if(isPbest){
		feaInd.ConvertToPoint(feaInd);
	}
}
MemoryEntry& MemoryEntry::operator=(const MemoryEntry &P){	
	if(this!=&P){		
	this->flag=P.flag;
	this->dis=P.dis;	
	this->feaInd=P.feaInd;
	this->infeaInd=P.infeaInd;
	}
	return *this;
}
MemoryEntry::MemoryEntry(const MemoryEntry& P):feaInd(P.feaInd),infeaInd(P.infeaInd){	
	this->flag=P.flag;
	this->dis=P.dis;	
}
PSOAgent & MemoryEntry::getFeaInd(){
	return this->feaInd;
}
PSOAgent & MemoryEntry::getInFeaInd(){
	return this->infeaInd;
}
void MemoryEntry::setFeaInd(PSOAgent &ind){
	this->feaInd=ind;
}
void MemoryEntry::setInfeaInd(PSOAgent&ind){
	if(ind.is_feasible()){
		cout<<"Wrong! ind should be infeasible!\n";
		system("pause");
		exit(0);
	}
	this->infeaInd=ind;
	this->dis=this->distance(ind.x,this->feaInd.x,this->infeaInd.m_pModel->n_var);
	this->flag=true;
}
void MemoryEntry::setInfeaInd(PSOAgent & ind,bool isPbest){
	if(ind.is_feasible())
		return;
	this->infeaInd=ind;
	if(isPbest){
		this->infeaInd.ConvertToPoint(infeaInd);
	}
	this->dis=this->distance(ind.x,this->feaInd.x,this->infeaInd.m_pModel->n_var);
	this->flag=true;
}
void MemoryEntry::updateInfeaInd(PSOAgent&ind){
	if(ind.is_feasible()){
		cout<<"Wrong! ind should be infeasible!\n";
		system("pause");
		exit(0);
	}
	double newdis=this->distance(ind.x,this->feaInd.x,this->infeaInd.m_pModel->n_var);
	if(dis>newdis){
		this->infeaInd=ind;
		this->dis=newdis;
	}
	
}
void MemoryEntry::updateInfeaInd(PSOAgent&ind,bool isPbest){
	
	PSOAgent newInd(ind);
	if(isPbest){		
		newInd.ConvertToPoint(newInd);		
	}
	if(newInd.is_feasible()){
		cout<<"Wrong! ind should be infeasible!\n";
		system("pause");
		exit(0);
	}
	double newdis=this->distance(newInd.x,this->feaInd.x,this->infeaInd.m_pModel->n_var);

	if(dis>newdis){
		this->infeaInd=newInd;
		this->dis=newdis;
	}
	
}
void MemoryEntry::updateInfeaInd(PSOAgent &ind, double disValue){
	if(ind.is_feasible())
		return;
	if(this->dis>disValue){
		this->dis=disValue;
		this->infeaInd=ind;	
	}
}
double MemoryEntry::distance(double*x1,double*x2,int n_var){
	double dis=0.0;
	for(int i=0;i<n_var;i++)
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	dis=sqrt(dis);
	return dis;

}
void MemoryEntry::setFlag(bool value){
	this->flag=value;
}
bool MemoryEntry::getFlag(){
	return this->flag;
}
MemoryEntry::~MemoryEntry(void)
{

}
bool MemoryEntry::operator<(const MemoryEntry &P)const{
	
	return (Point)this->feaInd < (Point)P.feaInd;
	
}   
bool MemoryEntry::operator>(const MemoryEntry &P)const{
	return (Point)this->feaInd > (Point)P.feaInd;
}  
