#include "../stdafx.h"
#include "PSOAgent.h"
#include <iomanip>
PSOAgent::PSOAgent(ModelInfo * m_pModel):Point(m_pModel)
{
#ifdef DEBUG
	cout<<"PSOAgent"<<endl;
#endif
	velocity=new double[m_pModel->n_var];
	pBest=new double[m_pModel->n_var];
	nBest=new double[m_pModel->n_var];
	seed=new double[m_pModel->n_var];

	c_pBest=new double[m_pModel->n_con];
	v_pBest=new double[m_pModel->n_con];

	double tempL;                               //temporary lower bonud
	double tempU;                               //temporary upper bound
	for(int i=0; i<m_pModel->n_var; i++){	//for each variable

		//get the search bounds
		if(m_pModel->LUv[2*i] > m_pModel->getNegInfty() && m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//both known
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = m_pModel->LUv[2*i];         //set lower
		}
		else if(m_pModel->LUv[2*i] > m_pModel->getNegInfty()){
			//only upper undetermined
			tempL = m_pModel->LUv[2*i];         //set lower
			tempU = tempL+m_pModel->getBound(); //artificial upper
		}
		else if(m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//only lower undetermined
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = tempU-m_pModel->getBound(); //artificial lower
		}
		else{
			//both bounds undetermined
			tempL = -m_pModel->getBound();      //artificial lower
			tempU = m_pModel->getBound();       //artificial upper
		}

		//calculate random number within bounds
		velocity[i]=(tempU-tempL)*m_pModel->getRandomDoubleFrom0To1()+tempL;
		//50% of v[i] are in an opposite direction
		double randNum=m_pModel->getRandomDoubleFrom0To1();
		if(randNum<=0.5)velocity[i]*=-1;

		//initialize the pBest and nBest
		pBest[i]=x[i];
		nBest[i]=x[i];
		seed[i]=x[i];
	}
	if(this->m_pModel->n_con==0){
		this->isFea_pBest=true;
		this->pBestValue=0;
		MaxV_pBest=0;
	}
	else{
		this->isFea_pBest=false;
		this->pBestValue=this->m_pModel->getInfty();
		MaxV_pBest=this->m_pModel->getInfty();
	}
	this->pBestFit=this->m_pModel->getInfty();
	this->nBestValue=this->m_pModel->getInfty();
	this->MaxV_pBest=this->m_pModel->getInfty();
	this->flag_localSearch=false;
	this->isSeed=false;
	isActive=true;
#ifdef DEBUG
	cout<<"PSOAgent constructor end"<<endl;
#endif
}

PSOAgent::PSOAgent(const PSOAgent &P):Point(P){
#ifdef DEBUG
	cout<<"PSOAgent copy constructor"<<endl;
#endif
	velocity=new double[m_pModel->n_var];
	pBest=new double[m_pModel->n_var];
	nBest=new double[m_pModel->n_var];
	seed=new double[m_pModel->n_var];

	c_pBest=new double[m_pModel->n_con];
	v_pBest=new double[m_pModel->n_con];

	int i;
	for(i=0;i<m_pModel->n_var;i++){
		this->velocity[i]=P.velocity[i];
		this->pBest[i]=P.pBest[i];
		this->nBest[i]=P.nBest[i];
		this->seed[i]=P.seed[i];
	}
	for(i=0;i<m_pModel->n_con;i++){
		this->c_pBest[i]=P.c_pBest[i];
		this->v_pBest[i]=P.v_pBest[i];
	}

	this->nBestValue=P.nBestValue;
	this->pBestValue=P.pBestValue;
	this->isFea_pBest=P.isFea_pBest;
	this->MaxV_pBest=P.MaxV_pBest;
	this->pBestFit=P.pBestFit;
	this->flag_localSearch=P.flag_localSearch;
	this->isSeed=P.isSeed;
#ifdef DEBUG
	cout<<"copy constructor end."<<endl;
#endif
}
PSOAgent& PSOAgent::operator=(const PSOAgent &P){
#ifdef DEBUG
	cout<<"PSOAgent assignment operator"<<endl;
#endif
	if(this!=&P){
		Point::operator =(P);				
		int i;
		for(i=0;i<m_pModel->n_var;i++){
			this->velocity[i]=P.velocity[i];
			this->pBest[i]=P.pBest[i];
			this->nBest[i]=P.nBest[i];
			this->seed[i]=P.seed[i];
		}
		for(i=0;i<m_pModel->n_con;i++){
			this->c_pBest[i]=P.c_pBest[i];
			this->v_pBest[i]=P.v_pBest[i];
		}
		this->nBestValue=P.nBestValue;
		this->pBestValue=P.pBestValue;
		this->isFea_pBest=P.isFea_pBest;
		this->MaxV_pBest=P.MaxV_pBest;
		this->pBestFit=P.pBestFit;
		this->flag_localSearch=P.flag_localSearch;
		this->isSeed=P.isSeed;
	}
#ifdef DEBUG
	cout<<"PSOAgent assignment operator end"<<endl;
#endif
	return *this;
}
bool PSOAgent::operator < (const PSOAgent & P)const{
#ifdef UseSortingRuleOfOriginalSPSO
	return (this->fitness < P.fitness);
#else
	//both feasible
	if(this->isFea_pBest && P.isFea_pBest){		
		return (this->pBestFit < P.pBestFit);			
	}
	else if(P.isFea_pBest)
		return false;
	else if(this->isFea_pBest)
		return true;
	//both infeasible
	else{
		return (this->pBestValue<P.pBestValue);			
	}
#endif
}
bool PSOAgent::operator > (const PSOAgent & P)const{
#ifdef UseSortingRuleOfOriginalSPSO
	return (this->fitness < P.fitness);
#else
	//both feasible
	if(this->isFea_pBest && P.isFea_pBest){		
		return (this->pBestFit > P.pBestFit);			
	}
	else if(P.isFea_pBest)
		return true;
	else if(this->isFea_pBest)
		return false;
	//both infeasible
	else{
		return (this->pBestValue > P.pBestValue);			
	}
#endif
}

void PSOAgent::randIndividual(){
	this->setIsEvaluated(false);
	MaxVio=this->m_pModel->getInfty();			
	SumVio=this->m_pModel->getInfty();
	fitness=m_pModel->getInfty();
	if(this->m_pModel->n_con>0)
		feasible=false;//default to infeasible
	else 
		feasible=true;
	this->index=-1;
	randLocation();//set to random location in search space
	double tempL;                               //temporary lower bonud
	double tempU;                               //temporary upper bound
	for(int i=0; i<m_pModel->n_var; i++){	//for each variable

		//get the search bounds
		if(m_pModel->LUv[2*i] > m_pModel->getNegInfty() && m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//both known
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = m_pModel->LUv[2*i];         //set lower
		}
		else if(m_pModel->LUv[2*i] > m_pModel->getNegInfty()){
			//only upper undetermined
			tempL = m_pModel->LUv[2*i];         //set lower
			tempU = tempL+m_pModel->getBound(); //artificial upper
		}
		else if(m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//only lower undetermined
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = tempU-m_pModel->getBound(); //artificial lower
		}
		else{
			//both bounds undetermined
			tempL = -m_pModel->getBound();      //artificial lower
			tempU = m_pModel->getBound();       //artificial upper
		}

		//calculate random number within bounds
		velocity[i]=(tempU-tempL)*m_pModel->getRandomDoubleFrom0To1()+tempL;
		//50% of v[i] are in an opposite direction
		double randNum=m_pModel->getRandomDoubleFrom0To1();
		if(randNum<=0.5)velocity[i]*=-1;

		//initialize the nBest
		//pBest[i]=x[i];//a slight difference with the original DSPSO is that the pBest would not be reset in this function
		nBest[i]=x[i];
		//seed[i]=x[i];
	}
	/*if(this->m_pModel->n_con==0)
		this->isFea_pBest=true;
	else
		this->isFea_pBest=false;
	this->pBestValue=this->m_pModel->getInfty();
	this->nBestValue=this->m_pModel->getInfty();
	this->MaxV_pBest=this->m_pModel->getInfty();
	this->flag_localSearch=false;
	this->isSeed=false;*/

}
PSOAgent::~PSOAgent(void)
{
#ifdef DEBUG
	cout<<"~PSOAgent\n";
#endif
	delete[]velocity;
	velocity=NULL;
	delete[] pBest;
	pBest=NULL;
	delete[] nBest;
	nBest=NULL;
	delete[] c_pBest;
	c_pBest=NULL;
	delete[] v_pBest;
	v_pBest=NULL;
	delete[] seed;
	seed=NULL;
	
}

void PSOAgent::computeFitness(){
	this->setIsEvaluated(true);
	this->setIsActive(true);
	//if(this->m_pModel->NEval>(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return;
	if(this->m_pModel->n_con>0){
		m_pModel->EvaluateC(x,c);
		m_pModel->ConstraintViolation(x,c,v,SumVio,MaxVio,feasible);
	}
#ifdef originalDSPSO
	if(1){
#else
	if(feasible){
#endif
		this->m_pModel->EvaluateF(x,fitness);
		
	}

	
	/*if(this->m_pModel->has_change&&!(this->m_pModel->dummyIsFeasible(x)))
		return;*/
	/******update the best point********/	
	//update the best point if the individual is feasible
	if(this->is_feasible()&&(this->m_pModel->fea_bestPoint==false||fitness<this->m_pModel->fit_bestPoint)){				
		this->m_pModel->updateBest(fitness,true,x,0.0);
	}
	//update the best point if both the individual and the current best are infeasible
	else if(this->is_feasible()==false&&this->m_pModel->fea_bestPoint==false&&SumVio<this->m_pModel->Sumvio_bestPoint){		
		this->m_pModel->updateBest(fitness,false,x,this->SumVio);
		
	}
	/******update the best point end********/
	return;
}

void PSOAgent::step(){
	this->RangeKeeperByReflection();	
	
	computeFitness();	
	
	//update the pbest
	//if(this->m_pModel->NEval > (this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return;

	if((this->feasible==false&&this->isFea_pBest==false&&SumVio<pBestValue)||(this->feasible&&!this->isFeasible_pBest())){
		this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
		
	}
	if((this->is_feasible()&&this->isFeasible_pBest())||this->m_pModel->n_con==0){
		//both the parent and the children are feasible

		if(this->fitness<this->pBestFit){
			this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);			
		}

	}

	return;
}
bool PSOAgent::getIsSeed(){
	return this->isSeed;
}
void PSOAgent::setIsSeed(bool feasible){
	this->isSeed=feasible;
} 
void PSOAgent::step_pBest(){	
	this->RangeKeeperByReflection_pBest();
	if(this->m_pModel->n_con>0){
		this->m_pModel->EvaluateC(pBest,c_pBest);
		this->m_pModel->ConstraintViolation(pBest,c_pBest,v_pBest,pBestValue,MaxV_pBest,isFea_pBest);
	}
#ifdef originalDSPSO
	if(1){
#else
	if(isFeasible_pBest()){
#endif	
		this->m_pModel->EvaluateF(pBest,pBestFit);
	}
	this->updateBestFoundSoFar_pBest();
}

void PSOAgent::update(){
	// do the normal constriction PSO stuff with species seeds as nbests
	for (int k=0; k <m_pModel->n_var; k++) 
	{
		
		{              
			velocity[k] = 0.729843788*(velocity[k]
			+ 2.05 * m_pModel->getRandomDoubleFrom0To1() * (pBest[k] - x[k]) 
				+ 2.05 * m_pModel->getRandomDoubleFrom0To1() * (nBest[k] - x[k]));			
		}

		// Adjust the velocity vector so that the agent cannot go beyond the search space, preventing the population from explosion
		// However, like the original DSPSO, the velocity is not constrained
		/*if (velocity[k] >m_pModel->maxVelocity[k]) 
		velocity[k] = m_pModel->maxVelocity[k];
		else if (velocity[k] < m_pModel->minVelocity[k]) 
		velocity[k] =  m_pModel->minVelocity[k];*/
		//this->RangerKeeper_velocity();

		// Based on the new velocity, update the agent's position
		x[k] = x[k] + velocity[k];	
	}
	this->setIsEvaluated(false);
	// Adjust the position vector so that the agent's new location varies
	// It is hoped the method below increases the overall population diversity                                
	Point::RangeKeeperByReflection();
}

double PSOAgent::getPresentValue(){
	return SumVio;
}
double PSOAgent:: getPBestValue() {
	return pBestValue;
}
double PSOAgent::getPBestFit(){
	return this->pBestFit;
}
double PSOAgent:: getNBestValue() {
	return nBestValue;
}
double* PSOAgent::getPresent(){
	return x;
}
void PSOAgent::getPBest(double *loc){
	for(int i=0;i<m_pModel->n_var;i++)
		loc[i]=pBest[i];
	return;
}
void PSOAgent::getNBest(double *loc){
	for(int i=0;i<m_pModel->n_var;i++)
		loc[i]=nBest[i];
	return;
}
double* PSOAgent::getC_PBest(){
	return c_pBest;
}
double* PSOAgent::getV_PBest(){
	return v_pBest;
}
double PSOAgent::getMaxV_PBest(){
	return this->MaxV_pBest;
}
bool PSOAgent::isFeasible_pBest(){
	return isFea_pBest;
}
bool PSOAgent::getIsActive(){
	return this->isActive;
}

void PSOAgent::setPresent(double* location) {
	for (int j=0; j < m_pModel->n_var; j++)
		x[j] = location[j];
	this->RangeKeeperByReflection();
}
void PSOAgent::setPresentValue(double value) {
	SumVio= value;
}
void PSOAgent::setPBest(double* location) {
	for (int j=0; j < m_pModel->n_var; j++)
		pBest[j] = location[j];
	this->RangeKeeperByReflection_pBest();
}
void PSOAgent::setPBestValue(double value) {
	pBestValue = value;
}
void PSOAgent::setPBestFit(double value){
	this->pBestFit=value;
}
void PSOAgent::setNBest(double* location) {
	for (int j=0; j < m_pModel->n_var; j++)
		nBest[j] = location[j];
}
void PSOAgent::setNBestValue(double value) {
	this->nBestValue = value;
}
void PSOAgent::setVelocity(double* location){	
	for (int j=0; j < m_pModel->n_var; j++)
		this->velocity[j]=location[j];
}

void PSOAgent::updateVelocity(double* newloc,double * oldloc){
	for(int i=0;i<this->m_pModel->n_var;i++){		
		this->velocity[i]=newloc[i]-oldloc[i];
	}
}

void PSOAgent::setC_PBest(double*c){
	for (int j=0; j < m_pModel->n_con; j++)
		this->c_pBest[j]=c[j];
}
void PSOAgent::setV_PBest(double*v){
	for (int j=0; j < m_pModel->n_con; j++)
		this->v_pBest[j]=v[j];
}
void PSOAgent::setMaxV_PBest(double MaxVio){
	this->MaxV_pBest=MaxVio;
}
void PSOAgent::setFea_pBest(bool feasible){
	this->isFea_pBest=feasible;
}
void PSOAgent::setIsActive(bool value){
	this->isActive=value;
}

void PSOAgent::RangerKeeper_velocity(){
	                              //temporary upper bound
	for(int i=0; i<m_pModel->n_var; i++){	//for each variable
		if(this->velocity[i]>this->m_pModel->maxVelocity[i]){
			this->velocity[i]=this->m_pModel->maxVelocity[i];
		}else if(this->velocity[i]<this->m_pModel->minVelocity[i]){
			this->velocity[i]=this->m_pModel->minVelocity[i];
		}

	}
}
void PSOAgent::ConvertToPoint(Point& P){

	for(int i=0; i< m_pModel->n_var; i++)
		P.x[i]=pBest[i];	
	for(int i=0; i< m_pModel->n_con; i++){
		P.c[i]=c_pBest[i];
		P.v[i]=this->v_pBest[i];		
	}
	P.setMaxVio(MaxV_pBest);
	P.setSumVio(pBestValue);
	P.setFea(isFea_pBest);
	P.setFitness(this->getPBestFit());	
}

void PSOAgent::updateThroughLocalSearch(double*location,double value,double conVio,bool is_pbest){
#ifdef DEBUG
	cout<<"updateThroughLocalSearch "<<endl;
#endif
	if(!is_pbest){//update the current location
		this->setPresent(location);	
		this->setFitness(value);
		this->updateVelocity(location,x);
		if(this->m_pModel->n_con>0){
			this->m_pModel->EvaluateC(x,c);
			this->m_pModel->ConstraintViolation(x,c,v,this->SumVio,this->MaxVio,this->feasible);
		}	

		/******update the best point********/	
		//update the best point if the individual is feasible
		if(this->is_feasible()&&(this->m_pModel->fea_bestPoint==false||fitness<this->m_pModel->fit_bestPoint)){				
			this->m_pModel->updateBest(fitness,true,x,0.0);
		}
		//update the best point if both the individual and the current best are infeasible
		else if(this->is_feasible()==false&&this->m_pModel->fea_bestPoint==false&&SumVio<this->m_pModel->Sumvio_bestPoint){		
			this->m_pModel->updateBest(fitness,false,x,this->SumVio);
		}
		/******update the best point end********/

		//update the pbest
		if(SumVio<pBestValue||(this->feasible&&this->isFeasible_pBest()&&this->getFitness()<this->getPBestFit())){
			this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
		}
		if((pBestValue==0.0&&SumVio==0.0)||this->m_pModel->n_con==0){
			//both the parent and the children are feasible
			if(this->fitness<this->pBestFit){
				this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
			}
		}	
	}
	else{//update the pbest
		this->setPBest(location);
		this->setPBestFit(value);
		this->updateVelocity(location,pBest);
		if(this->m_pModel->n_con>0){
			this->m_pModel->EvaluateC(pBest,c_pBest);
			this->m_pModel->ConstraintViolation(pBest,c_pBest,v_pBest,pBestValue,MaxV_pBest,isFea_pBest);
		}
		//update the best solution found so far
		this->updateBestFoundSoFar_pBest();
	}
	
}
void PSOAgent::reinitialization(PSOAgent& P){

	/******************reset the current solution*******************/
	this->setLocation(P.x);
	this->setFitness(P.getFitness());
	this->setSumVio(P.getSumVio());
	this->setC(P.c);
	this->setV(P.v);
	this->setMaxVio(P.getMaxVio());
	this->setFea(P.is_feasible());
	this->setVelocity(P.velocity);

/*	double tempL;                               //temporary lower bonud
	double tempU;                               //temporary upper bound
	for(int i=0; i<m_pModel->n_var; i++){	//for each variable

		//get the search bounds
		if(m_pModel->LUv[2*i] > m_pModel->getNegInfty() && m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//both known
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = m_pModel->LUv[2*i];         //set lower
		}
		else if(m_pModel->LUv[2*i] > m_pModel->getNegInfty()){
			//only upper undetermined
			tempL = m_pModel->LUv[2*i];         //set lower
			tempU = tempL+m_pModel->getBound(); //artificial upper
		}
		else if(m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//only lower undetermined
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = tempU-m_pModel->getBound(); //artificial lower
		}
		else{
			//both bounds undetermined
			tempL = -m_pModel->getBound();      //artificial lower
			tempU = m_pModel->getBound();       //artificial upper
		}

		//calculate random number within bounds
		velocity[i]=(tempU-tempL)*m_pModel->getRandomDoubleFrom0To1()+tempL;	
		//50% of v[i] are in an opposite direction
		double randNum=m_pModel->getRandomDoubleFrom0To1();
		if(randNum<=0.5)velocity[i]*=-1;
	}
	*/
	/******************end reset the current solution*******************/

	
	//update the pbest
	if((!this->is_feasible()&&!this->isFeasible_pBest()&&SumVio<pBestValue)||(this->feasible&&!this->isFeasible_pBest())){
		this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
	}
	if((this->is_feasible()&&this->isFeasible_pBest())||this->m_pModel->n_con==0){
		//both the parent and the children are feasible
		if(this->fitness<this->pBestFit){
			this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
		}

	}

	/*****************update the pbest end*********************/

	
}
void PSOAgent::resetPBest(){
	this->setPBestFit(this->m_pModel->getInfty());
	if(this->m_pModel->n_con>0){
		this->setFea_pBest(false);
	}else
		this->setFea_pBest(true);
	this->setPBestValue(this->m_pModel->getInfty());
}

void PSOAgent::stepAfterChange(PSOAgent&P){
	for(int i=0; i< m_pModel->n_var; i++)
		x[i]=P.x[i];
	this->step();

}
void PSOAgent::Reinitialization(){
	//reevaluate the pbest
	if(this->m_pModel->n_con>0){
		m_pModel->EvaluateC(this->pBest,this->c_pBest);
		m_pModel->ConstraintViolation(this->pBest,this->c_pBest,this->v_pBest,this->pBestValue,this->MaxV_pBest,this->isFea_pBest);
	}else
		this->setFea_pBest(true);

#ifdef originalDSPSO
	if(1){
#else
	if(isFeasible_pBest()){
#endif	
		this->m_pModel->EvaluateF(this->pBest,this->pBestFit);
	}else{
		this->setPBestFit(this->m_pModel->getInfty());
	}
	this->updateBestFoundSoFar_pBest();
	
}
string PSOAgent::OutputPBest(){
	stringstream ss;
	ss << "[";
	for(int i=0; i<m_pModel->n_var-1; i++){
		ss <<setiosflags(ios::fixed)<<setprecision(6)<< this->pBest[i] << ", ";
	}
	ss << pBest[m_pModel->n_var-1];
	ss << "];" ;//<< endl;
	return ss.str();
}
string PSOAgent::OutputVelocity(){
	stringstream ss;
	ss << "[";
	for(int i=0; i<m_pModel->n_var-1; i++){
		ss <<setiosflags(ios::fixed)<<setprecision(6)<< this->velocity[i] << ", ";
	}
	ss << velocity[m_pModel->n_var-1];
	ss << "];" ;//<< endl;
	return ss.str();
}
string PSOAgent::OutputNBest(){
	stringstream ss;
	ss << "[";
	for(int i=0; i<m_pModel->n_var-1; i++){
		ss <<setiosflags(ios::fixed)<<setprecision(6)<< this->nBest[i] << ", ";
	}
	ss << nBest[m_pModel->n_var-1];
	ss << "];" ;//<< endl;
	return ss.str();
}
int PSOAgent::getRegionID_pBest(){
	if(this->m_pModel->Problem<10000){
		int size=this->m_pModel->_segmentPivotPoints.size();
		int left, right; //index of the two end of the segment
		left=0;right=1;
		double xCoord=this->pBest[0];
		int count=0;
		//return ceil(xCoord);
		while (right<size)
		{
			if (this->m_pModel->_segmentPivotPoints[right].second==true)
			{
				count++;
				//if the given point belongs to the current segment
				if ( (xCoord >= this->m_pModel->_segmentPivotPoints[left].first) && (xCoord <= this->m_pModel->_segmentPivotPoints[right].first))	
				{
					return count;
				}
				else 
				{
					left=right;
					right++;
				}
			}
			else
			{
				right++;
			}
		}
	}else{
		int i=0,numRegion=this->m_pModel->mfrb->getNumberofPeak();
		for(i=0;i<numRegion;i++){
			if(this->m_pModel->mfrb->isInRegion(this->pBest,i)){
			return i;
			}
		}
	}
	if(this->m_pModel->dummyIsFeasible(this->pBest)){
		cout<<"Location: "<<this->OutputPBest()<<endl;
		
	}
	return -1;
}
void PSOAgent::RangeKeeperByReflection_pBest(){
		double exceed;
	double range;
	double max,min;
	for(int i=0; i<m_pModel->n_var; i++){		//for each variable
		//badElement=pBest[i];
		max=m_pModel->LUv[2*i+1];
		min=m_pModel->LUv[2*i];
		range=max-min;
		if(pBest[i] < min) {
			exceed=min-pBest[i];
			if(exceed>range)
				exceed-=((int)(exceed/range))*range;
			pBest[i]=min+exceed;//pBest[i]=min+IN*range;
		}
		else if(pBest[i] > max){
			exceed=pBest[i]-max;
			if(exceed>range)
				exceed-=((int)(exceed/range))*range;
			pBest[i]=max-exceed;//pBest[i]=min+IN*range;
		}
		//cout << m_pModel->LUv[2*i] << " " << pBest[i] << " " << m_pModel->LUv[2*i+1] << endl;
	}
}
bool PSOAgent::dominate_pBest(PSOAgent& P){

	//returns false if the pbest of P is more promising than the pbest of this particle
	if(this->isFeasible_pBest() && P.isFeasible_pBest()){
		//both feasible
		if(this->getPBestFit()<=P.getPBestFit())
			return true;
		else
			return false;
	}
	else if(P.isFeasible_pBest())
		return false;
	else if(this->isFeasible_pBest())
		return true;
	else{
		if(this->getPBestValue()<=P.getPBestValue())
			return true;
		else return false;
	}

	//return mp;
}
void PSOAgent::updateBestFoundSoFar_pBest(){
	/*if(this->m_pModel->has_change&&!(this->m_pModel->dummyIsFeasible(pBest)))
		return;*/
	/******update the best point********/	
	//update the best point if the individual is feasible
	if(this->isFeasible_pBest()&&(this->m_pModel->fea_bestPoint==false||getPBestFit()<this->m_pModel->fit_bestPoint)){				
		this->m_pModel->updateBest(this->getPBestFit(),true,this->pBest,0.0);
	}
	//update the best point if both the individual and the current best are infeasible
	else if(this->isFeasible_pBest()==false&&this->m_pModel->fea_bestPoint==false&&this->getPBestValue()<this->m_pModel->Sumvio_bestPoint){		
		this->m_pModel->updateBest(this->getPBestFit(),false,this->pBest,this->pBestValue);
		
	}
	/******update the best point end********/
	
}
void PSOAgent::updateBestFoundSoFar(){
	/*if(this->m_pModel->has_change&&!(this->m_pModel->dummyIsFeasible(x)))
		return;*/
	//update the pbest
	if((this->feasible==false&&this->isFea_pBest==false&&SumVio<pBestValue)||(this->feasible&&!this->isFeasible_pBest())){		
		this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
	}
	if((this->is_feasible()&&this->isFeasible_pBest())||this->m_pModel->n_con==0){
		//both the parent and the children are feasible
		if(this->fitness<this->pBestFit){
			this->updatePBest(x,c,v,MaxVio,feasible,fitness,SumVio);
		}
	}

	/******update the best point********/	
	//update the best point if the individual is feasible
	if(this->is_feasible()&&(this->m_pModel->fea_bestPoint==false||fitness<this->m_pModel->fit_bestPoint)){				
		this->m_pModel->updateBest(fitness,true,x,0.0);
	}
	//update the best point if both the individual and the current best are infeasible
	else if(this->is_feasible()==false&&this->m_pModel->fea_bestPoint==false&&SumVio<this->m_pModel->Sumvio_bestPoint){		
		this->m_pModel->updateBest(fitness,false,x,this->SumVio);
		
	}
	/******update the best point end********/
	////update the best point if the individual is feasible
	//if(this->is_feasible()&&(this->m_pModel->fea_bestPoint==false||fitness<this->m_pModel->fit_bestPoint)){				
	//	this->m_pModel->updateBest(fitness,true,x,0.0);
	//}
	////update the best point if both the individual and the current best are infeasible
	//else if(this->is_feasible()==false&&this->m_pModel->fea_bestPoint==false&&SumVio<this->m_pModel->Sumvio_bestPoint){		
	//	this->m_pModel->updateBest(fitness,false,x,this->SumVio);
	//	
	//}
}
void PSOAgent::updatePBest(double * x1, double* c1,double *v1,double MaxVio1,double fea1,double fitness1, double SumVio1){
	setPBestValue(SumVio1);
	setPBest(x1);
	this->setC_PBest(c1);
	this->setV_PBest(v1);
	this->setMaxV_PBest(MaxVio1);
	this->setFea_pBest(fea1);
	this->setPBestFit(fitness1);

}


