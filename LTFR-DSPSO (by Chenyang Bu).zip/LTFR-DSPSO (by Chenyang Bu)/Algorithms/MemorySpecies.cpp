#include "MemorySpecies.h"

MemorySpecies::MemorySpecies(void)
{
	this->memlist.clear();
	this->num=0;
}

MemorySpecies::~MemorySpecies(void)
{
	this->memlist.clear();
	this->memlist.shrink_to_fit();
}
