/*************************************************************************
* Algorithm: Locating and Tracking Feasible Regions DSPSO (LTFR-DSPSO)
*************************************************************************
* Author: Chenyang Bu, Wenjian Luo and Lihua Yue
* Email: bucy1991@mail.ustc.edu.cn
* Language: C++ and MATLAB mixed programming
*************************************************************************
*  The codes were not developed professionally. The purpose of making the 
codes available is to allow other researchers to reproduce our reported results.

* If you make use of these codes, please cite our publications below. 
[1] Chenyang Bu, Wenjian Luo and Lihua Yue. Continuous Dynamic Constrained Optimization 
with an Ensemble of Locating and Tracking Feasible Regions Strategies. 
IEEE Transactions on Evolutionary Computation. doi: 10.1109/TEVC.2016.2567644
[2] Chenyang Bu, Wenjian Luo and Tao Zhu. Differential evolution with
a species-based repair strategy for constrained optimization. 
Proceedings of the 2014 IEEE Congress on Evolutionary Computation (CEC 2014). IEEE, 2014, pp. 967�C974.

* Permission is hereby granted to use this source code for any purpose without fee. 
However, for non-scientific purpose, please inform us the objective for using
   "LTFR-DSPSO" before using the software:
       E-mail address: bucy1991@mail.ustc.edu.cn
The reason is that we'd like to know the real applications.
*************************************************************************/
// Last modified: 18 May 2016

#pragma once
#pragma runtime_checks( "scu", off )
#ifndef MySwarm_h
#define MySwarm_h

#include "ModelInfo.h"
#include "PSOAgent.h"
#include "Species.h"
#include "MemoryEntry.h"
#include "MemorySpecies.h"

#include "../stdafx.h"
class Point;
class ModelInfo;
class PSOAgent;
class ConstraintConsensus;
class hillPointIndex;
class Species;
class MemoryEntry;
using namespace std;
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>

//namespace DCOP{

class MySwarm
{
public://private:
	double modifiedOfflineError;
	int popSize;//the population size 
	int GradientSteps;// the maximum repeated times of gradient-based repair (i.e., $R_g$)
	ModelInfo * m_pModel;//the problem model
	double nBestValue;//store temp neighbour best value
	bool has_change;//whether a change is detected	
	int maxNumPerSpecies;//the maximum particle number in a species	
	double radius;//the species radius
	double ORT;//measure
	int time_detected;//measure, count the time the change is detected correctly
	int time_detectedError;
	int time_detectedInTime;
	int maxSpeNum;//the allowed maximum species number, functioning by limiting the radius
	int maxLSTimesPerPeriod;
	int currentLSTimes;
	int maxLSNEval;//the allowed maximum function evalutions per local search
	int numToCheck;//$N_d$, the maximum number of particles to be re-evaluated for problems with static constraints of without a constraint

	double *nBest;//store temp neighbour best
	bool flag_pbest;//determine whether using the current location or pbest
	vector<PSOAgent> population;        //the population	
	vector<PSOAgent> prePop;
	vector<Species> preSpecies;
	//vector<PSOAgent> preprePop;
	//vector<Species> prepreSpecies;
	vector<PSOAgent> promisingPool;        //the individuals to be added to the population in the reinitialization procedure
	vector<PSOAgent> Pool;//the repalce pool
	vector<PSOAgent> bestInGen; //record the best found solution in each generation 
	vector<PSOAgent> infeaSet; //the memory set of infeasible particles for detecting changes
	vector<int> infeaPop;//temp infeaisble population
	vector<int> feaPop;	//temp feasible population
	vector<Species> currentSpecies;	//the index of current species
	//vector<double> deltaX;
	deque<MemoryEntry> LocalMemory;//the local memory at time $t$, i.e. the LM(t) 
	deque<MemoryEntry> preMemory;	
	deque<MemoryEntry> memorySeeds;	//the seeds of the memory LM(t)
	vector<MemorySpecies> memory;//merged from LM(0), LM(1), ... , LM(t)
	vector<MemorySpecies> bestMemory;//previously found best solutions
	vector<MemoryEntry> preLocalMemory; //the local memory at time $t-1$	
	vector<vector<double>> LSMemory;//for ALS
	vector<double> LSRadius;//for ALS
	vector<double> tmpVec;
	//vector<double> bestFitness_inGen;	
	
	ofstream outputLS;
	ofstream ofStreamRegionID;
	ofstream ofStreamRegionID_pBest;
	ofstream ofRegionIDFeaInds;
	ofstream outputRepair;
	ofstream ofProInfo;
	ofstream ofDetection;
	ofstream ofPopInfo;
public:	
	MySwarm(int num,ModelInfo* m_pModel);
	~MySwarm(void);

	void SPSO_basicStep();
	void mainStep();

	bool detectChange();
	void Reinitialization();
	bool locatingFeasibleRegionsStrategy();
	void trackingPreviouslyFeasibleRegionsStrategy();
	void predictingFutureFeasibleRegionsStrategy();
	void updateSpeciesRadius();
	void allocateNeighbourBest();
	void replaceRedundantParticlesInSpecies();

	void updateOfflineError();
	void updateLocalMemoryPerGen();
	void updateMemoryPerChange();
	void addIntoMemory(PSOAgent& ind);
	void updateMeasurePerGen();
	void addInfeaParticlesIntoMemory();
	void replaceStrategy();

	void classifyMemoryIntoSpecies();
	void DividingIntoSpecies(vector<PSOAgent>& vec,bool flag=true);	


	//gradient-based methods
	bool repairAndLocalSearch(PSOAgent&ind);
	void repair(PSOAgent&ind);
	int GradientRepairOperation(double* x, double* newInd, double* c);
	int ginverse(gsl_matrix* A, gsl_matrix* G);
	int gsolve(gsl_matrix* A, gsl_vector* b, gsl_vector* x);
	int Gsolve(double* a, int m, int n, double* b, double* x);
	bool LocalSearch(PSOAgent&ind);
	void LocalSearch_sqp(PSOAgent&ind,double*location,double& fitness,double& conVio);	
	bool CheckForLocalSearch(double*x1);
	//end gradient-based methods
	double getRadius();
	double getORT();
	int getTimeDetected();
	int getTimeDetectedInTime();
	int getTimeDetectedError();
	double distance(double*x1,double*x2);
	bool isRedundant(double *x1,double*x2);	
	void outputRegionIDOfPop();	
	void calculatePopulationCenter(double *x);
	double diversity(double *x);	
	template < class T > void ClearVector( vector< T >& vt );
};

#endif