#include "../stdafx.h"
#include "Point.h"
#include <cmath> //abs, pow
#include <sstream>
using namespace std;

Point::Point(ModelInfo *m_pModel)
{
#ifdef DEBUG
	cout << "point constructor " << endl;
#endif
	this->m_pModel = m_pModel;
	x = new double[m_pModel->n_var];    //an element for each variable
	if(this->m_pModel->n_con>0){

		c = new double[m_pModel->n_con];    //an element for each constraint
		v = new double[m_pModel->n_con];    //an element for each constraint

		for(int i=0;i<m_pModel->n_con;i++){
			c[i]=0;
			v[i]=0;
		}     
		nabla = new double*[m_pModel->n_con];//for each non zero constraint
		for(int ii=0;ii<m_pModel->n_con;ii++){
			nabla[ii]=new double[m_pModel->n_var];
		}
	}
	
	fitness=m_pModel->getInfty();
	if(this->m_pModel->n_con>0){
		feasible=false;//default to infeasible
		MaxVio=this->m_pModel->getInfty();			
		SumVio=this->m_pModel->getInfty();
	}
	else{ 
		feasible=true;
		MaxVio=0;			
		SumVio=0;
	}
	this->index=-1;
	is_evaluated=false;
	randLocation();//set to random location in search space
#ifdef DEBUG
	cout<<"point constructor end"<<endl;
#endif
}
Point::~Point(){
#ifdef DEBUG
	cout << "point destructor "<< endl;
#endif
	delete [] x;
	x=NULL;
	if(this->m_pModel->n_con>0){
		delete [] c;
		c=NULL;
		delete [] v;
		v=NULL;
		for(int ii=0;ii<m_pModel->n_con;ii++){
			delete[]nabla[ii];
			nabla[ii]=NULL;
		}
		delete[] nabla;
		nabla=NULL;
	}
#ifdef DEBUG
	cout << "point destructor end "<< endl;
#endif
}

Point::Point(const Point &P){
#ifdef DEBUG
	cout << "Point copy constructor" << endl;
#endif
	this->m_pModel = P.m_pModel;
	x = new double[m_pModel->n_var];
	for(int i=0; i< m_pModel->n_var; i++)
		x[i]=P.x[i];
	if(this->m_pModel->n_con>0){
		nabla = new double*[m_pModel->n_con];//;
		for(int ii=0;ii<P.m_pModel->n_con;ii++){
			nabla[ii]=new double[m_pModel->n_var];
		}
		for(int j=0;j<P.m_pModel->n_con;j++){
			for(int i=0; i< m_pModel->n_var; i++)
				nabla[j][i]=P.nabla[j][i];
		}

		c = new double[m_pModel->n_con];
		v = new double[m_pModel->n_con];
		for(int i=0; i< m_pModel->n_con; i++){
			c[i]=P.c[i];
			v[i]=P.v[i];
		}
	}
	feasible = P.feasible;
	MaxVio = P.MaxVio;		
	SumVio = P.SumVio;
	fitness=P.fitness;
	is_evaluated=P.is_evaluated;
#ifdef DEBUG
	cout << "Point copy constructor end" << endl;
#endif
}

Point& Point::operator=(const Point &P){
#ifdef DEBUG
	cout << "assignment operator" << endl;
#endif
	if(this != &P)
	{
		m_pModel = P.m_pModel;
		for(int i=0; i< m_pModel->n_var; i++)
			x[i]=P.x[i];
		if(this->m_pModel->n_con>0){
			for(int j=0;j<m_pModel->n_con;j++)
				for(int i=0; i< m_pModel->n_var; i++)
					nabla[j][i]=P.nabla[j][i];
			for(int i=0; i< m_pModel->n_con; i++){
				c[i]=P.c[i];
				v[i]=P.v[i];
			}
		}
		feasible = P.feasible;
		MaxVio = P.MaxVio;
		SumVio = P.SumVio;
		fitness = P.fitness;
		is_evaluated=P.is_evaluated;
	}
	return *this;
} 

bool Point::operator<(const Point& P) const{
#ifdef UseSortingRuleOfOriginalSPSO
	return (this->fitness < P.fitness);
#else
	if(this->feasible==true&&P.feasible==true)
		return (this->fitness < P.fitness);
	else if(this->feasible==false&&P.feasible==false)
		return (this->SumVio < P.SumVio);
	else
		return this->feasible;
#endif
}

bool Point::operator>(const Point& P) const{
#ifdef UseSortingRuleOfOriginalSPSO
	return (this->fitness < P.fitness);
#else
	if(this->feasible==true&&P.feasible==true)
		return (this->fitness > P.fitness);
	else if(this->feasible==false&&P.feasible==false)
		return (this->SumVio > P.SumVio);
	else
		return P.feasible;
#endif
}

void Point::randLocation(){
	double tempL;                               //temporary lower bonud
	double tempU;                               //temporary upper bound
	for(int i=0; i<m_pModel->n_var; i++){	//for each variable

		if(m_pModel->LUv[2*i] > m_pModel->getNegInfty() && m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//both known
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = m_pModel->LUv[2*i];         //set lower
		}
		else if(m_pModel->LUv[2*i] > m_pModel->getNegInfty()){
			//only upper undetermined
			tempL = m_pModel->LUv[2*i];         //set lower
			tempU = tempL+m_pModel->getBound(); //artificial upper
		}
		else if(m_pModel->LUv[2*i+1] < m_pModel->getInfty()){
			//only lower undetermined
			tempU = m_pModel->LUv[2*i+1];       //set upper
			tempL = tempU-m_pModel->getBound(); //artificial lower
		}
		else{
			//both bounds undetermined
			tempL = -m_pModel->getBound();      //artificial lower
			tempU = m_pModel->getBound();       //artificial upper
		}		
		//calculate random number within bounds
		x[i]=(tempU-tempL)*m_pModel->getRandomDoubleFrom0To1()+tempL;		
		
	}	
	RangeKeeperByReflection();	//make sure point is in search space
	
	//refresh();		//refresh the violation data
}

void Point::RangeKeeperBySetToBounds(){
#ifdef DEBUG
	cout << "setToBounds" << endl;
#endif
	double badElement;
	for(int i=0; i<m_pModel->n_var; i++){		//for each variable
		badElement=x[i];
		if(x[i] < m_pModel->LUv[2*i]) {
			x[i] = m_pModel->LUv[2*i];			//reset to lower bound if violated
		}
		else if(x[i] > m_pModel->LUv[2*i+1]){
			x[i] = m_pModel->LUv[2*i+1];		//reset to upper bound if violated
		}
	}
#ifdef DEBUG
	cout << "setToBounds end" << endl;
#endif
}
void Point::RangeKeeperByReflection(){
	double exceed;
	double range;
	double max,min;
	for(int i=0; i<m_pModel->n_var; i++){		//for each variable
		max=m_pModel->LUv[2*i+1];
		min=m_pModel->LUv[2*i];
		range=max-min;
		if(x[i] < min) {
			exceed=min-x[i];
			if(exceed>range)
				exceed-=((int)(exceed/range))*range;
			x[i]=min+exceed;
		}
		else if(x[i] > max){
			exceed=x[i]-max;
			if(exceed>range)
				exceed-=((int)(exceed/range))*range;
			x[i]=max-exceed;
		}
	}
}

void Point::refresh(){
#ifdef DEBUG
	cout << "refresh" << endl;
#endif

	//initialize violations
	MaxVio=0.0;			
	SumVio=0.0;
	feasible=false;		//default to infeasible

	//get constraint function values at current point
	if(this->m_pModel->n_con>0)
		m_pModel->EvaluateC(x,c);

	//calculate constraint violations
	//constraints of form: LUrhs[2*i] < c(i) < LUrhs[2*i+1]
	m_pModel->ConstraintViolation(x,c,v,SumVio,MaxVio,feasible);
#ifdef DEBUG
	cout << "refresh end" << endl;
#endif
}

void Point::setLocation(double *new_x){

	for(int i=0; i<m_pModel->n_var; i++){		//for each variable
		x[i]=new_x[i];
	}
	RangeKeeperByReflection();	//make sure point is in search space
}

double Point::getMaxVio(){
	return MaxVio;
}

double Point::getSumVio(){
	return SumVio;
}

double Point::getConVio(int i){
	if(i<m_pModel->n_con && i > -1)
		return v[i];
	else{
		cout << "Out of range: Point::getConVio()" << endl;
		return 1;
	}
}


double Point::getJac(int i,int j){
	if(i<m_pModel->n_con && i > -1&&j<m_pModel->n_var&&j>-1)
		return nabla[i][j];
	else{
		cout << "Out of range: Point::getJac()" << endl;
		return 1;
	}
}

int Point::addVec(double *nx, int n){
#ifdef DEBUG
	cout << "addVec" << endl;
#endif
	if(n!=m_pModel->n_var){		//if new vector isn't right size
		cout << "Error: wrong number of elements in nx" << endl;
		return 1;			//return unsuccessfully
	}
	else{
		for(int i=0; i<n; i++)          //add each element
			x[i]+=nx[i];

		this->RangeKeeperByReflection();			//make sure point is in search space
		refresh();			//refresh the violation data
	}
#ifdef DEBUG
	cout << "addVec end" << endl;
#endif
	return 0;
}
//loc=x
void Point::getLocation(double* loc){
	for(int i=0; i<m_pModel->n_var; i++)
		loc[i]=x[i];
}
//return the distance between P and current particle (current solution)
double Point::getDist(Point* P){

	double dist = 0;
	double *loc;
	loc = new double[m_pModel->n_var];
	P->getLocation(loc);
	for(int i=0; i<m_pModel->n_var; i++){
		dist+=pow(x[i]-loc[i], 2);
	}
	dist = sqrt(dist);

	delete [] loc;
	return dist;
}
//output current solution
string Point::OutputLocation(){
	stringstream ss;
	ss << "[";
	for(int i=0; i<m_pModel->n_var-1; i++){
		ss << x[i] << ", ";
	}
	ss << x[m_pModel->n_var-1];
	ss << "];";// << endl;
	return ss.str();
}
//return whether the particle is better than P
//if return true, the particle is better
//otherwise, P is better
bool Point::dominate(Point& P){
	//both feasible
	if(this->feasible && P.is_feasible()){		
		return (this->getFitness()<=P.getFitness());			
	}
	else if(P.is_feasible())
		return false;
	else if(this->is_feasible())
		return true;
	//both infeasible
	else{
		return (this->getSumVio()<=P.getSumVio());			
	}

}
//return whether it is feasible or not
bool Point::is_feasible(){
	return feasible;
}
double Point::getFitness(){
	return this->fitness;
}
int Point::getIndex(){
	return this->index;
}
void Point::setFea(bool fea){
	this->feasible=fea;
}
void Point::setC(double*c){
	for(int i=0;i<m_pModel->n_con;i++){
		this->c[i]=c[i];
	}
}
void Point::setV(double *v){
	for(int i=0;i<m_pModel->n_con;i++){
		this->v[i]=v[i];
	}
}
void Point::setMaxVio(double value){
	this->MaxVio=value;
}
void Point::setSumVio(double value){
	this->SumVio=value;
}
void Point::setFitness(double value){
	this->fitness=value;
}
void Point::setIndex(int value){
	this->index=value;
}
//get the index of region number
int Point::getRegionID(){
	if(this->m_pModel->Problem<10000){
		int size=this->m_pModel->_segmentPivotPoints.size();
		int left, right; //index of the two end of the segment
		left=0;right=1;
		double xCoord=this->x[0];
		int count=0;
		//return ceil(xCoord);
		while (right<size)
		{
			if (this->m_pModel->_segmentPivotPoints[right].second==true)
			{
				count++;
				//if the given point belongs to the current segment
				if ( (xCoord >= this->m_pModel->_segmentPivotPoints[left].first) && (xCoord <= this->m_pModel->_segmentPivotPoints[right].first))	
				{
					return count;
				}
				else 
				{
					left=right;
					right++;
				}
			}
			else
			{
				right++;
			}
		}
	}else{
		int i=0,numRegion=this->m_pModel->mfrb->getNumberofPeak();
		for(i=0;i<numRegion;i++){
			if(this->m_pModel->mfrb->isInRegion(this->x,i)){
				return this->m_pModel->mfrb->getRealRegionIndex(i);
			}
		}
	}
	/*if(this->m_pModel->dummyIsFeasible(this->x)){
		cout<<"Location: "<<this->OutputLocation()<<endl;
		
	}*/
	return -1;
}
bool Point::isRedundant(Point & P){
	for(int i=0;i<this->m_pModel->n_var;i++){
		if(this->x[i]!=P.x[i])
			return false;
	}
	return true;
}
bool Point::getIsEvaluated(){
	return this->is_evaluated;
}
void Point::setIsEvaluated(bool val){
	this->is_evaluated=val;
}