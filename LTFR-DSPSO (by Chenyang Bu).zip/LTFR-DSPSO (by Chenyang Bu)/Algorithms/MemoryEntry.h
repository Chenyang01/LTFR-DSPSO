#pragma once
#ifndef MemoryEntry_h
#define MemoryEntry_h
#include "PSOAgent.h"
using namespace std;
class Point;
class PSOAgent;
class MemoryEntry
{
private:
	PSOAgent feaInd;//the seed of a species
	PSOAgent infeaInd;//the infeasible individual which is the nearest with the seed in the species
	bool flag;//whether it is an old particle in memory (i.e. the feaInd has the corresponding infeaind	
	double dis;//the distance value between the seed ( feaInd ) and the infeaInd	

public:
	MemoryEntry(PSOAgent & fea,PSOAgent & infea,double value);
	MemoryEntry(PSOAgent&fea);
	MemoryEntry(PSOAgent&fea,bool isPbest);
	MemoryEntry(const MemoryEntry &P);	
	MemoryEntry& operator=(const MemoryEntry &P);
	bool operator<(const MemoryEntry &P) const;   //for sorting points
	bool operator>(const MemoryEntry &P) const;   //for sorting points
	void setFeaInd(PSOAgent & ind);
	
	void updateFeaInd(PSOAgent & ind,double radius);
	void setFeaInd1(PSOAgent&ind);
	void setInfeaInd(PSOAgent & ind);
	void setInfeaInd(PSOAgent & ind,bool isPbest);
	PSOAgent & getFeaInd();
	PSOAgent & getInFeaInd();
	bool getFlag();	
	void setFlag(bool value);	
	void updateInfeaInd(PSOAgent&ind);
	void updateInfeaInd(PSOAgent & ind,bool isPbest);
	bool IsInASpecies(PSOAgent &ind,double radius);//check whether the ind and the memory are in the same species
	void updateInfeaInd(PSOAgent &ind, double disValue);	
	double getDis(){return dis;}
	double distance(double*x1,double*x2,int n_var);
	~MemoryEntry(void);
};
#endif