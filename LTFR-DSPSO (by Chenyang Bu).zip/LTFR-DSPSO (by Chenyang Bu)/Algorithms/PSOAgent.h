#pragma once
#ifndef PSOAgent_h
#define PSOAgent_h
#include "Point.h"
#include "ModelInfo.h"
#include "../stdafx.h"
using namespace std;
class ModelInfo;
class Point;

class PSOAgent:
	public Point
{
protected:	
	double pBestValue;//the sum violation of pBest(SumVio) 
	double pBestFit;// the objective value of pBest(fitness)
	double nBestValue;	
	double MaxV_pBest;//the max violaton of pBest
	bool isFea_pBest;//is pBest feasible ?  
	bool flag_localSearch;//is true if has been searched locally
	bool isSeed;
	bool isActive;//detemining whether the particle should be evaluated in the current generation, 1: yes, 0: no
	
public:	
	PSOAgent(ModelInfo *m_pModel);
	PSOAgent(const PSOAgent &P);              //copy constructor
	PSOAgent& operator=(const PSOAgent &P);	//assignment operator	
	bool operator < (const PSOAgent & P) const;
	bool operator > (const PSOAgent & P) const;
	friend class PSOAgent;
	friend class Point;	
	friend class MySwarm;

	double *velocity;//the velocity of the point
	double* pBest;//the location 
	double* nBest;
	double *c_pBest;//the value of constraint funtions for pBest
	double * v_pBest;//violation of pBest
	double * seed;	


	~PSOAgent(void);
	void step();
	void step_pBest();	
	void computeFitness(); //the function evaluation for the pso agents	
	void update();
	void updateVelocity(double* newloc,double * oldloc);

	double getPresentValue();
	double getPBestValue();
	double getPBestFit();
	double getNBestValue();
	double* getPresent();
	void getPBest(double *loc);
	void getNBest(double *loc);
	double* getVelocity();
	double* getC_PBest();
	double* getV_PBest();
	double getMaxV_PBest();
	bool isFeasible_pBest();
	bool getIsActive();	
	bool getIsSeed();

	void setPresent(double* location);
	void setPresentValue(double value);
	void setPBestValue(double value);
	void setPBestFit(double value);
	void setNBestValue(double value);
	void setPBest(double* location);
	void setNBest(double* location);
	void setVelocity(double*location);	
	void setC_PBest(double*c);
	void setV_PBest(double*v);
	void setMaxV_PBest(double MaxVio);
	void setFea_pBest(bool feasible);
	void setFlag_localSearch(bool feasible);
	void setIsSeed(bool feasible);
	void setIsActive(bool value);

	void ConvertToPoint(Point& P);
	
	void updateThroughLocalSearch(double*location,double value,double conVio, bool is_pbest=false);//return true if the pbest has been updated	
	void Reinitialization();
	void stepAfterChange(PSOAgent& P);
	void reinitialization(PSOAgent&P);
	void resetPBest();
	void updatePBest(double * x1, double* c1,double *v1,double MaxVio1,double fea1,double fitness1, double SumVio1);
	void RangerKeeper_velocity();
	void RangeKeeperByReflection_pBest();
	void randIndividual();

	string OutputPBest();
	string OutputVelocity();
	string OutputNBest();
	int getRegionID_pBest();
	bool dominate_pBest(PSOAgent&P);
	void updateBestFoundSoFar();
	void updateBestFoundSoFar_pBest();	
};

#endif