#include "Species.h"

Species::Species(int popSize){
	this->numFea=0;
	this->numInfea=0;
	this->index=-1;
	this->nearestInfea=-1;
	this->disToInfea=-1.0;
	this->farestInfea=-1;
	this->numTotal=0;
	for(int i=0;i<3;i++){
		this->numInRegion[i]=0;
		this->numFeaInRegion[i]=0;
		this->numInfeaInRegion[i]=0;
	}

}
Species::~Species(){
	if(!this->fealist.empty()){
		this->fealist.clear();
		
	}
	this->fealist.shrink_to_fit();
	if(!this->infealist.empty()){
		this->infealist.clear();
		
	}
	this->infealist.shrink_to_fit();
	if(!this->totalList.empty())
	{	this->totalList.clear();
	    
	}
	this->totalList.shrink_to_fit();

}


Species::Species(const Species &C){
	this->fealist=C.fealist;
	this->infealist=C.infealist;
	this->totalList=C.totalList;	
	this->seed=C.seed;
	this->numFea=C.numFea;
	this->numInfea=C.numInfea;
	this->nearestInfea=C.nearestInfea;
	this->disToInfea=C.disToInfea;
	this->farestInfea=C.farestInfea;
	this->numTotal=C.numTotal;
	for(int i=0;i<3;i++){
		this->numInRegion[i]=C.numInRegion[i];
		this->numFeaInRegion[i]=C.numFeaInRegion[i];
		this->numInfeaInRegion[i]=C.numInfeaInRegion[i];
	}
	
};
Species& Species::operator=(const Species &C){
	if(this!=&C){
		this->fealist=C.fealist;
		this->infealist=C.infealist;
		this->totalList=C.totalList;		
		this->seed=C.seed;
		this->numFea=C.numFea;
		this->numInfea=C.numInfea;
		this->nearestInfea=C.nearestInfea;
		this->disToInfea=C.disToInfea;
		this->farestInfea=C.farestInfea;
		this->numTotal=C.numTotal;
		for(int i=0;i<3;i++){
			this->numInRegion[i]=C.numInRegion[i];
			this->numFeaInRegion[i]=C.numFeaInRegion[i];
			this->numInfeaInRegion[i]=C.numInfeaInRegion[i];
		}
	}
	return *this;
}
