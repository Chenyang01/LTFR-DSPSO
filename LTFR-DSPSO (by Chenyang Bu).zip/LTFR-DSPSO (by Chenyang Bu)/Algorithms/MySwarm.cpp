/*************************************************************************
* Algorithm: Locating and Tracking Feasible Regions DSPSO (LTFR-DSPSO)
*************************************************************************
* Author: Chenyang Bu, Wenjian Luo and Lihua Yue
* Email: bucy1991@mail.ustc.edu.cn
* Language: C++ and MATLAB mixed programming
*************************************************************************
*  The codes were not developed professionally. The purpose of making the 
codes available is to allow other researchers to reproduce our reported results.

* If you make use of these codes, please cite our publications below. 
[1] Chenyang Bu, Wenjian Luo and Lihua Yue. Continuous Dynamic Constrained Optimization 
with an Ensemble of Locating and Tracking Feasible Regions Strategies. 
IEEE Transactions on Evolutionary Computation. doi: 10.1109/TEVC.2016.2567644
[2] Chenyang Bu, Wenjian Luo and Tao Zhu. Differential evolution with
a species-based repair strategy for constrained optimization. 
Proceedings of the 2014 IEEE Congress on Evolutionary Computation (CEC 2014). IEEE, 2014, pp. 967�C974.

* Permission is hereby granted to use this source code for any purpose without fee. 
However, for non-scientific purpose, please inform us the objective for using
   "LTFR-DSPSO" before using the software:
       E-mail address: bucy1991@mail.ustc.edu.cn
The reason is that we'd like to know the real applications.
*************************************************************************/
// Last modified: 18 May 2016
#include "MySwarm.h"
#ifdef UseLS
#include "mclmcrrt.h" // mwArray 
#include "matrix.h"
#include "../libMyAdd.h"
#endif
#define ZERO_THRESHOLD	1e-20
#define Delta 0.0001
#define pi PI
MySwarm::MySwarm(int num,ModelInfo* Model)
{
#ifdef DEBUG
	cout<<"initialize"<<endl;
#endif

	popSize=num;//population size	
	this->m_pModel=Model;//the pointer containing problem information	

	//this->deltaX.resize(this->m_pModel->n_var);	
	nBest=new double[m_pModel->n_var];
	population.reserve(popSize);	
	prePop.reserve(popSize);
	promisingPool.reserve(2*popSize);
	this->preLocalMemory.reserve(popSize);
	//this->memoryOfCurrentPeriod.reserve(popSize);
	this->tmpVec.resize(this->m_pModel->n_var);
	this->bestInGen.reserve((this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)/popSize);

	numToCheck=5;
	modifiedOfflineError=0.0;
	time_detected=0;//count the times of detected changes
	time_detectedError=0;//count the times of false detection
	time_detectedInTime=0;//count the times that the changes are detected timely
	this->ORT=0.0;//measure: ORT
	maxSpeNum=15;// the expected maximum number of the species; used to adjust the radius
#ifdef G24
	// a parameter determing the maximum times of local search in each time period
	if(this->m_pModel->NEvalEveryPeroid>=1000)
		maxLSTimesPerPeriod=100;//no limitation for G24, since G24 has at most three feasible regions
	else if(this->m_pModel->NEvalEveryPeroid>=500)
		maxLSTimesPerPeriod=5;
	else
		maxLSTimesPerPeriod=3;
#else
	maxLSTimesPerPeriod=8;// a parameter determing the maximum times of local search in each time period
#endif
	maxLSNEval=50;//the allowed maximum function evalutions per local search
	currentLSTimes=0; // count the times of local search in the current time period
	this->maxNumPerSpecies=(int)(this->popSize/4);//maximum species population ($p_{max}$)
	this->GradientSteps=50;//max times of gradient-based repair for each particle		
	this->updateSpeciesRadius();//set the species radius
	this->flag_pbest=false;	
	m_pModel->gen=0;//generation
	char str[200];
#ifdef ProInfo

	sprintf(str,"data\\ProInfo_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);

	this->ofProInfo.open(str,ofstream::out|ofstream::app);
	this->ofProInfo<<"radius: "<<radius<<endl;
	//cout<<"radius: "<<radius<<endl;	
#endif
	this->m_pModel->calculateDynamicGlobalOptimum();
	this->m_pModel->updateSegmentPivotPoints();
	/******** initialise the population**************/
	//for each particle
	for(int i=0;i<popSize;i++){
		PSOAgent agent(m_pModel);			
		//agent.step();//evaluate the constraints and update the pBest		
		population.push_back(agent);
	}
	/********end initialise the population**************/

#ifdef OutputDection
	//sprintf(str,"data\\Detection_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	sprintf(str,"data\\Detection_%d.txt",this->m_pModel->Problem);
	this->ofProInfo.open(str,ofstream::out|ofstream::app);
#endif
#ifdef OutputLS
	sprintf(str,"data\\LocalSearchInfo_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->outputLS.open(str,ofstream::out|ofstream::app);
	sprintf(str,"data\\RegionIDInfo_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->ofStreamRegionID.open(str,ofstream::out|ofstream::app);
	sprintf(str,"data\\RegionIDPBestInfo_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->ofStreamRegionID_pBest.open(str,ofstream::out|ofstream::app);
	sprintf(str,"data\\RegionIDPBestFeaInds_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->ofRegionIDFeaInds.open(str,ofstream::out|ofstream::app);
#endif
#ifdef OutputPopInfo

	sprintf(str,"data\\PopInfo_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->ofPopInfo.open(str,ofstream::out|ofstream::app);
#endif
#ifdef OutputRepair
	sprintf(str,"data\\RepairInfo_Pro_%d_run_%d.txt",this->m_pModel->Problem,this->m_pModel->runID);
	this->outputRepair.open(str,ofstream::out|ofstream::app);
#endif


#ifdef DEBUG
	cout<<"initialize end"<<endl;
#endif

}
MySwarm::~MySwarm(void)
{	
	this->ClearVector(this->prePop);
	this->ClearVector(this->preSpecies);
	//this->ClearVector(this->preprePop);
	//this->ClearVector(this->prepreSpecies);
	this->ClearVector(bestMemory);
	this->ClearVector(feaPop);
	this->memorySeeds.clear();
	this->memorySeeds.shrink_to_fit();
	this->ClearVector(infeaPop);
	this->ClearVector(memory);
	this->ClearVector(population);
	this->ClearVector(promisingPool);
	//this->ClearVector(bestFitness_inGen);
	this->ClearVector(infeaSet);
	this->ClearVector(bestInGen);	
	this->LocalMemory.clear();
	this->LocalMemory.shrink_to_fit();
	preMemory.clear();
	preMemory.shrink_to_fit();


	//this->ClearVector(deltaX);
	for(int i=0;i<LSMemory.size();i++)
		this->ClearVector(this->LSMemory[i]);
	this->ClearVector(LSMemory);
	this->ClearVector(LSRadius);
	this->ClearVector(currentSpecies);
	this->ClearVector(preLocalMemory);	
	this->ClearVector(tmpVec);
	this->ClearVector(bestMemory);

	delete[] this->nBest;
	nBest=NULL;

#ifdef OutputLS
	this->outputLS.close();
	this->ofStreamRegionID.close();
	this->ofStreamRegionID_pBest.close();	
	this->ofRegionIDFeaInds.close();
#endif
#ifdef OutputRepair
	outputRepair.close();
#endif
#ifdef ProInfo
	this->ofProInfo.close();
#endif
#ifdef OutputPopInfo

	this->ofPopInfo.close();
#endif
#ifdef OutputDection
	this->ofProInfo.close();
#endif
}
//Alg. 1
void MySwarm::DividingIntoSpecies(vector<PSOAgent>& vec,bool flag){
	//if(this->m_pModel->NEval>(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return;
	if(!this->currentSpecies.empty())
		this->currentSpecies.clear();
	
	
	sort(vec.begin(),vec.end(),less<Point>());
#ifdef TestSorting
	for(int i=0;i<this->popSize;i++){
		this->ofProInfo<<i<<", "<<vec[i].OutputLocation()<<", "<<"isfea: "<<vec[i].is_feasible()<<", fit "<<vec[i].getFitness()<<", conVio: "<<vec[i].getSumVio()<<endl;
	}
	ofProInfo<<"\n";
#endif
	/******sort the population end*******/


	//identify the seeds and clustering
	int numspe=0;//the number of currentSpecies,start from 1
	//int numprocessed=0;


	//while(numprocessed<this->popSize)
	for(int loop=0;loop<vec.size();loop++)
	{				
		bool foundSpecies=false;
		for(int i=0;i<numspe && !foundSpecies;i++){			
			if(this->distance(vec[loop].x,vec[this->currentSpecies[i].seed].x)<=this->radius){
				foundSpecies=true;
				if(maxNumPerSpecies == 0 || (this->currentSpecies[i].numTotal < this->maxNumPerSpecies)){							
					if(vec[loop].is_feasible()){
						this->currentSpecies[i].fealist.push_back(loop);
						this->currentSpecies[i].numFea++;

					}else{
						this->currentSpecies[i].infealist.push_back(loop);
						this->currentSpecies[i].numInfea++;
					}
					this->currentSpecies[i].totalList.push_back(loop);
					this->currentSpecies[i].numTotal++;
				}else{
					// particles to be reinitialised
					// the particles are not allocated to a new species until the following iteration
					if(flag){
						vec[loop].randIndividual();
						vec[loop].setIsActive(false);
						//this->replacePool.push_back(loop);
					}
				}
			}
		}
		if(!foundSpecies){
			numspe++;
			Species newCluster(this->popSize);			
			if(vec[loop].is_feasible()){
				newCluster.numFea++;
				newCluster.fealist.push_back(loop);

			}else{
				newCluster.numInfea++;						
				newCluster.infealist.push_back(loop);
			}
			newCluster.seed=loop;//set the seed of the species			
			newCluster.numTotal++;
			newCluster.totalList.push_back(loop);
			this->currentSpecies.push_back(newCluster);
		}
		//is_processed[loop]=true;
		//numprocessed++;
	}

#ifdef OutputTest1
	ofPopInfo<<"output the seeds:\n";
	for(int i=0;i<this->currentSpecies.size();i++){
		this->ofPopInfo<<i<<", "<<vec[this->currentSpecies[i].seed].OutputLocation()<<", "<<"isfea: "<<vec[this->currentSpecies[i].seed].is_feasible()<<", fit "<<vec[this->currentSpecies[i].seed].getFitness()<<", conVio: "<<vec[this->currentSpecies[i].seed].getSumVio()<<endl;
	}
	ofPopInfo<<"\n";
#endif
	/*delete[] popIndex;*/
	//	delete[] is_processed;
	return;


}
//Alg. 1
void MySwarm::classifyMemoryIntoSpecies(){
	if(!this->memorySeeds.empty())
		this->memorySeeds.clear();
	int numMem=this->LocalMemory.end()-this->LocalMemory.begin();
	bool* is_processed=new bool[numMem];//store whether each individual has been processed or not
	for(int i=0;i<numMem;i++){		
		is_processed[i]=false;
	}

	/******sort the population*******/
	sort(this->LocalMemory.begin(),this->LocalMemory.end(),less<MemoryEntry>());
#ifdef TestSorting
	this->ofProInfo<<"gen: "<<this->m_pModel->gen<<", before classify"<<endl;
	for(int i=0;i<numMem;i++){
		this->ofProInfo<<i<<", "<<this->LocalMemory[i].getFeaInd().OutputLocation()<<", "<<"isfea: "<<this->LocalMemory[i].getFeaInd().is_feasible()<<", fit "<<this->LocalMemory[i].getFeaInd().getFitness()<<", conVio: "<<this->LocalMemory[i].getFeaInd().getSumVio()<<endl;
	}
#endif
	/******sort the population end*******/


	//identify the seeds 
	int numspe=0;//the number of species,start from 1
	int numprocessed=0;


	while(numprocessed<numMem){
		int tmp=0;
		//get the best unprocessed
		for(int i=0;i<numMem;i++){
			if(!is_processed[i]){
				tmp=i;
				break;
			}
		}
		bool found=false;
		int index=-1;
		for(int i=0;i<numspe;i++){			
			if(this->distance(this->LocalMemory[tmp].getFeaInd().x,this->memorySeeds[i].getFeaInd().x)<=this->radius){
				found=true;
				
#ifdef UseChangeDetectionStrategy
				if(this->memorySeeds[i].getFlag()==false&&this->LocalMemory[tmp].getFlag()==true){
					this->memorySeeds[i].setInfeaInd(this->LocalMemory[tmp].getInFeaInd());
				}
#endif
				break;
			}			

		}
		if(!found){			
			numspe++;
			this->memorySeeds.push_back(this->LocalMemory[tmp]);			
		}
		is_processed[tmp]=true;
		numprocessed++;
	}
#ifdef OutputRepair
	this->outputRepair<<"classify memory into species gen "<<this->m_pModel->gen<<",  NUM of SPECIES: "<<(this->memorySeeds.end()-this->memorySeeds.begin())<<endl;
	for(deque<MemoryEntry>::iterator li=this->memorySeeds.begin();li!=this->memorySeeds.end();li++){
		this->outputRepair<<"SPECIES No."<<(li-this->memorySeeds.begin())<<", seed: "<<li->seed;//<<this->population[li->infealist[0]].OutputPBest()
		this->outputRepair<<"  feasible:"<<this->population[li->seed].is_feasible()<<", REGION_seed: "<<this->population[li->seed].getRegionID();
		//this->outputRepair<<this->population[li->infealist[0]].is_feasible()<<", REGION_seed: ";
		/*if(li->numFea!=0){
		this->outputRepair<<"feasible! "<<", REGION_seed: "<<this->population[li->fealist[0]].getRegionID();
		}
		else
		this->outputRepair<<"Infea! "<<", REGION_seed: "<<this->population[li->infealist[0]].getRegionID();*/
		this->outputRepair<<", NUM: "<<(li->numInfea+li->numFea)<<endl;
		//if(this->population[li->infealist[0]].is_feasible())
		//this->outputRepair<<", fitness:"<<this->population[li->infealist[0]].getPBestFit();
		this->outputRepair<<"Infea: "<<(li->numInfea)<<", Fea:"<<(li->numFea)<<endl;
		this->outputRepair<<"Region1: "<<li->numInRegion[0]<<", Region2: "<<li->numInRegion[1]<<", Region3: "<<li->numInRegion[2]<<endl;
		this->outputRepair<<"FEA_1: "<<li->numFeaInRegion[0]<<", INfea_1: "<<li->numInfeaInRegion[0]<<endl;
		this->outputRepair<<"FEA_2: "<<li->numFeaInRegion[1]<<", INfea_2: "<<li->numInfeaInRegion[1]<<endl;
		this->outputRepair<<"FEA_3: "<<li->numFeaInRegion[2]<<", INfea_3: "<<li->numInfeaInRegion[2]<<endl;
	}
	this->outputRepair<<endl;

#endif

#ifdef TestSorting
	this->ofProInfo<<"after classify"<<endl;
	for(int i=0;i<this->memorySeeds.size();i++){
		this->ofProInfo<<i<<", "<<this->memorySeeds[i].getFeaInd().OutputLocation()<<", "<<"isfea: "<<this->memorySeeds[i].getFeaInd().is_feasible()<<", fit "<<this->memorySeeds[i].getFeaInd().getFitness()<<", conVio: "<<this->memorySeeds[i].getFeaInd().getSumVio()<<endl;
	}
#endif

	//delete[] popIndex;
	delete[] is_processed;
	return;
}
//Alg. 2 main loop 
void MySwarm::mainStep(){	
	this->m_pModel->gen=0;
	//the main loop of LTFR-DSPSO
	while(this->m_pModel->NEval<(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){		
		
		/***********1. activate all the particles and evaluate them*************/
		for(int i=0;i<this->popSize;i++){
			
			if(!this->population[i].getIsEvaluated()||!this->population[i].getIsActive()){
				this->population[i].step();
				this->population[i].setIsActive(true);
			}
		}
		/***********end activate all the particles and evaluate them*************/
		

		/***************2. divide current solutions into species***************/		
		this->DividingIntoSpecies(this->population);
	
		/***************end divide current solutions into species***************/	
		
		/***********3. update the memory set LM(t)************/		
#ifndef originalDSPSO
		this->updateLocalMemoryPerGen();
		
		addInfeaParticlesIntoMemory();
#endif
		/***********end update the memory LM(t)************/

		
		/**************4. locate feasible regions strategy************/
		bool flag_detected=false;
#ifdef UseLocatingFeasibleRegionsStrategy
		this->flag_pbest=false;
		flag_detected=this->locatingFeasibleRegionsStrategy();
		if(this->m_pModel->NEval <= (this->m_pModel->NEval*this->m_pModel->getMaxStep())){
			if(this->m_pModel->has_change){//a real change happens
				if(flag_detected){
					time_detectedInTime++;
				}			
			}

			if(flag_detected)		//a change is detected	
			{			
				if(this->m_pModel->informedChange==false){//if there is not a real change happened
					time_detectedError++;
				}else//a real change is detected
				{
					time_detected++;				
					this->m_pModel->informedChange=false;//reset the value
				}			
				this->Reinitialization();//reinitialize when a change is detected	
				this->DividingIntoSpecies(this->population);
			}//end if(flag_detected)
		}
#endif //end of #ifdef locateCurrent
		/**************end locate feasible regions strategy************/

		/**************5. allocate each seed to be the nbest***********/
		this->allocateNeighbourBest();
		/**************end allocate each seed to be the nbest***********/

		/*************6. replace redundant particles in species************/
		replaceRedundantParticlesInSpecies();
		/*************end replace redundant particles in species************/


		/************7. basic PSO step************/
		this->SPSO_basicStep();
		/************end basic PSO step************/



		/*************8. the change dectection strategy**********/
#ifdef UseChangeDetectionStrategy
		flag_detected=this->detectChange();
#else 
		flag_detected=this->m_pModel->informedChange;
#endif
		
		if(this->m_pModel->NEval <= (this->m_pModel->NEval*this->m_pModel->getMaxStep())){
			if(this->m_pModel->has_change){//a real change happens
				if(flag_detected){
					time_detectedInTime++;
				}else{
#ifdef OutputDection
					this->ofDetection<<"run: "<<this->m_pModel->runID<<", problem:"<<this->m_pModel->Problem<<", NEval: "<<this->m_pModel->NEval<<endl; 
#endif
				}
				this->m_pModel->has_change=false;
			}

			if(flag_detected)		//a change is detected	
			{			
				if(this->m_pModel->informedChange==false){//if there is not a real change happened
					time_detectedError++;
				}else//a real change is detected
				{
					time_detected++;				
					this->m_pModel->informedChange=false;//reset the value
				}			
				this->Reinitialization();//reinitialize when a change is detected			
			}
			{//no change is detected
#ifndef originalDSPSO
				preMemory=this->LocalMemory;					
				//this->prepreSpecies=this->preSpecies;
				//this->preprePop=this->prePop;
				this->preSpecies=this->currentSpecies;
				this->prePop=this->population;

#endif
			}//end if(flag_detected)
		}	
		/*************end change dectection strategy**********/
		
		/**********9. update the measure per generation*************/
		this->updateMeasurePerGen();
		/**********end update the measure per generation*************/	
	}

#ifdef DEBUG
	cout<<"main step end\n";
#endif
}
//Step 17 of Alg. 2
//assign each species seed to all paticles in the same species as the neighbourhood best (i.e., nbest)
void MySwarm::allocateNeighbourBest(){
	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){
		for(vector<int>::iterator particleIndex=li->totalList.begin();particleIndex!=li->totalList.end();particleIndex++){
			this->population[*particleIndex].setNBest(this->population[li->seed].x);
		}
	}
}
//Step 18 of Alg. 2
void MySwarm::replaceRedundantParticlesInSpecies(){
	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){
		if(li->numTotal<=1)continue;
		for(int i=1;i<li->numTotal;i++){
#ifdef UseSortingRuleOfOriginalSPSO
			if(this->population[li->seed].fitness==this->population[li->totalList[i]].fitness){
#else
			//In the original SPSO, the particles, who have the same fitness as the seed, are considered to be redundant.
			//However, because only feasible particles have fitness in our version, a slight change is made that
			//only the paritlces having the same location as the seed are regarded as redundant 
			if(this->isRedundant(this->population[li->seed].x,this->population[li->totalList[i]].x)){
#endif			
				this->population[li->totalList[i]].randIndividual();
			}
		}
	}
}
//Step 19 of Alg. 2
//the basic step of PSO
void MySwarm::SPSO_basicStep(){
	//note that the particles that caused the speices population to exceed the parameter $p_{max}$ would not be evluated until the next generation
	for(int i=0;i<this->popSize;i++){
		if(this->population[i].getIsActive()){
			this->population[i].update();//move			
			//this->population[i].step();//evaluate			
		}
	}
}
//Alg. 3
bool MySwarm::locatingFeasibleRegionsStrategy(){	
	//if(this->m_pModel->NEval>(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return false;
	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){
		//speices-based repair (SRS) and speices-based local search (SLS)
		if(repairAndLocalSearch(this->population[li->seed])){
			return true;//a change is detected
		}
	}	
	return false;
}
//Alg. 4 graident-based repair
void MySwarm::repair(PSOAgent&ind){
	double*location=new double[this->m_pModel->n_var];
	for(int i=0;i<this->m_pModel->n_var;i++)location[i]=0;
	double fitness=this->m_pModel->getInfty(), conVio=this->m_pModel->getInfty();
	//if flag_pbest is true, then choose current location, rather than pbest, to conduct the procedure
	if(!flag_pbest){
		/*************gradient based repair******************/
		//repair the seeds of each species
#ifdef UseRepair	
		if(!ind.is_feasible()){
			PSOAgent old1(ind);
			this->GradientRepairOperation(ind.x,ind.x,ind.c);
			ind.updateVelocity(ind.x,old1.x);//update the velocity using Eq. 14
			ind.step();//evaluate
			if(old1.dominate(ind)){
				ind=old1;
			}
		}
	}
	else{	
		if(!ind.isFeasible_pBest()){//if the ind is not feasible, repair it
			PSOAgent old1(ind);
			this->GradientRepairOperation(ind.pBest,ind.pBest,ind.c_pBest);
			ind.updateVelocity(ind.pBest,old1.pBest);//update the velocity using Eq. 14
			ind.step_pBest();//evaluate the new pbest
			if(old1.dominate_pBest(ind))
				ind=old1;
		}
	}
#endif
		
		/*************end gradient based repair ******************/

}
int MySwarm::GradientRepairOperation(double* x, double* newInd, double* c)
{
#ifdef DEBUG
	cout<<"GradientRepairOperation\n";
#endif
	if(this->m_pModel->NEval<=(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
		this->m_pModel->NumRepair++;//count the number of repair	
	}
	double* dx=new double [this->m_pModel->n_var];
	double **nabla = new double*[m_pModel->n_con];//;
	double* tmp=new double[this->m_pModel->n_con*this->m_pModel->n_var];

	for(int ii=0;ii<this->m_pModel->n_con;ii++){
		nabla[ii]=new double[m_pModel->n_var];
	}
	for(int ii=0;ii<this->m_pModel->n_con;ii++){
		for(int jj=0;jj<this->m_pModel->n_var;jj++){
			nabla[ii][jj]=0.0;
		}
	}

	int t,num,k;
	double e,v,r;

	if(newInd!=x){
		for(int j=0;j<this->m_pModel->n_var;j++)
			newInd[j]=x[j];

	}
	for(t=0;t<this->GradientSteps;t++){
		if(t>0){
			this->m_pModel->EvaluateC(newInd,c);
			if(this->m_pModel->NEval<=(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
				this->m_pModel->NConstRepair++;
			}
		}
		e=0.0;
		num=0;
		for(k=0;k<this->m_pModel->Inequalities;k++){
			v=c[k];
			if(v>0){
				e+=v;
				num++;
			}
		}
		for(; k<this->m_pModel->n_con; k++) {
			v=fabs(c[k])-Delta;
			if(v>0) { e+=v; num++; }
		}
		//return if feasible
		if(e==0){
			delete[]dx;			
			dx=NULL;
			for(int j=0;j<this->m_pModel->n_con;j++){
				delete[] nabla[j];
				nabla[j]=NULL;
			}
			delete[]nabla;
			nabla=NULL;
			delete[]tmp;			
			tmp=NULL;

			return 1;
		}
		//considering  Epsilon value
		// if(e<Epsilon)return 1;

		//for reducing computation time
		/*if(num==1){
		r=this->m_pModel->getRandomDoubleFrom0To1();
		if(r<this->SKIP_MOVE_RATE)return 1;
		}*/

		//Calculate gradient of C

		this->m_pModel->EvaluateNabla(newInd,c,nabla);
		//Eliminate satisfied inequalities
		num=0;
		for(k=0;k<this->m_pModel->Inequalities;k++){
			if(c[k]>0){
				if(num<k){
					for(int j=0;j<this->m_pModel->n_var;j++){
						nabla[num][j]=nabla[k][j];

					}
					c[num]=c[k];
				}
				num++;
			}
		}
		for(; k<this->m_pModel->n_con; k++) {
			v=(c[k]>=0? c[k] : -c[k]);
			if(v>Delta) {
				if(num<k) {
					for(int j=0; j<this->m_pModel->n_var; j++)
						nabla[num][j]=nabla[k][j];
#if 1 // considering Delta value
					if(c[k]>0)
						c[num]=c[k]-Delta;
					else	c[num]=c[k]+Delta;
#else // ignoring Delta value
					c[num]=c[k];
#endif
				}
				num++;
			}
		}

		for(int ii=0;ii<this->m_pModel->n_con;ii++){
			for(int jj=0;jj<this->m_pModel->n_var;jj++){
				tmp[ii*this->m_pModel->n_var+jj]=nabla[ii][jj];
			}
		}
		if(!Gsolve(tmp,num,this->m_pModel->n_var,c,dx)){			
			delete[]dx;			
			dx=NULL;
			for(int j=0;j<this->m_pModel->n_con;j++){
				delete[] nabla[j];
				nabla[j]=NULL;
			}
			delete[]nabla;			
			nabla=NULL;
			delete[]tmp;			
			tmp=NULL;
			return 0;
		}

		for(int j=0;j<this->m_pModel->n_var;j++){
			newInd[j]=newInd[j]-dx[j];			
			if(newInd[j]<this->m_pModel->LUv[j*2])				
				newInd[j]=this->m_pModel->LUv[j*2];
			else if(newInd[j]>this->m_pModel->LUv[j*2+1])
				newInd[j]=this->m_pModel->LUv[j*2+1];
		}
	}

	delete[]dx;
	dx=NULL;
	for(int j=0;j<this->m_pModel->n_con;j++){
		delete[] nabla[j];
		nabla[j]=NULL;
	}
	delete[]nabla;	
	nabla=NULL;
	delete[]tmp;	
	tmp=NULL;
#ifdef DEBUG
	cout<<"GradientRepairOperation end\n";
#endif
	return 0;
}
int MySwarm::ginverse(gsl_matrix* A, gsl_matrix* G)
{
#ifdef Test
	cout<<"ginverse\n";
#endif
	int transpose, i, succeed;
	gsl_matrix *temp;
	double v;

	int m=A->size1;
	int n=A->size2;

	if(m<n) {
		// A is transposed, since gsl_linalg_SV_decomp needs m>=n.
		transpose=1;
		gsl_matrix_transpose_memcpy(G, A);
		temp=A; A=G; G=temp;
		i=m; m=n; n=i;
	}
	else	transpose=0;

	gsl_vector *s=gsl_vector_alloc(n);
	gsl_matrix *S=gsl_matrix_alloc(n, n);
	gsl_matrix *V=gsl_matrix_alloc(n, n);
	gsl_vector *work=gsl_vector_alloc(n);
	gsl_matrix *B=gsl_matrix_alloc(n, n);

	/* A = U S V^T (A is replaced with U) */
	gsl_linalg_SV_decomp (A, V, s, work);

#ifdef DEBUG
	printf("U=");
	gsl_matrix_fprintf(stdout, A, "%f");
	printf("s=");
	gsl_vector_fprintf(stdout, s, "%f");
	printf("V=");
	gsl_matrix_fprintf(stdout, V, "%f");
#endif

	/* A^- = V S^- U^T */
	gsl_matrix_set_zero(S);
	for(i=0; i<n; i++) {
		v=gsl_vector_get(s, i);
		if(v>ZERO_THRESHOLD)
			gsl_matrix_set(S, i, i, 1.0/v);
	}
	succeed=(gsl_matrix_get(S, 0, 0)>0);
	if(succeed) {
		gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, V, S, 0.0, B);
		gsl_blas_dgemm(CblasNoTrans, CblasTrans, 1.0, B, A, 0.0, G);

#ifdef DEBUG
		printf("B=");
		gsl_matrix_fprintf(stdout, B, "%f");
		printf("G=");
		gsl_matrix_fprintf(stdout, G, "%f");
#endif

		if(transpose) { // return A, because A and G are swapped
			gsl_matrix_transpose_memcpy(A, G);
		}
	}	
	gsl_matrix_free(V);	
	gsl_matrix_free(S);
	gsl_matrix_free(B);
	gsl_vector_free(s);
	gsl_vector_free(work);
#ifdef Test
	cout<<"ginverse end\n";
#endif
	return succeed;
}
int MySwarm::gsolve(gsl_matrix* A, gsl_vector* b, gsl_vector* x)
{
#ifdef Test
	cout<<"gsolve\n";
#endif	
	gsl_matrix *G=gsl_matrix_alloc(A->size2, A->size1);
	int succeed;	
	succeed=ginverse(A, G);	
	if(succeed)
		gsl_blas_dgemv(CblasNoTrans, 1.0, G, b, 0.0, x);	
	gsl_matrix_free(G);	
#ifdef Test
	cout<<"gsolve end\n";
#endif
	return succeed;
}
int MySwarm::Gsolve(double* a, int m, int n, double* b, double* x)
{
#ifdef Test
	cout<<"Gsolve\n";
#endif
	//The explanation of "gsl_matrix_view_array" is given below (from "https://www.gnu.org/software/gsl/manual/html_node/Matrix-views.html").
	//Function: gsl_matrix_view gsl_matrix_view_array (double * base, size_t n1, size_t n2)
	//The function "gsl_matrix_view_array" returns a matrix view of the array base. 
	//The matrix has n1 rows and n2 columns. The physical number of columns in memory is also given by n2. 
	//Mathematically, the (i,j)-th element of the new matrix is given by,
    //m'(i,j) = base[i*n2 + j]
    //where the index i runs from 0 to n1-1 and the index j runs from 0 to n2-1.
	gsl_matrix_view Av=gsl_matrix_view_array(a, m, n);
	gsl_vector_view bv=gsl_vector_view_array(b, m);
	gsl_vector_view xv=gsl_vector_view_array(x, n);	
	gsl_matrix *A=&Av.matrix;
	gsl_vector *B=&bv.vector;
	gsl_vector *X=&xv.vector;
	
#ifdef Test
	cout<<"Gsolve end\n";
#endif
	return gsolve(A, B, X);
	
}
//Alg. 5 Adaptive Local Search (ALS)
bool MySwarm::LocalSearch(PSOAgent&ind){	
	//if(this->m_pModel->NEval>(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return false;
	//temp variables preparing for local search
	double*location=new double[this->m_pModel->n_var];
	for(int i=0;i<this->m_pModel->n_var;i++)location[i]=0;
	double fitness=this->m_pModel->getInfty(), conVio=this->m_pModel->getInfty();
	//if flag_pbest is true, then choose current location, rather than pbest, to conduct the procedure
	if(!flag_pbest){
		
#ifdef UseLS			
		if(!ind.is_feasible()||!(this->CheckForLocalSearch(ind.x))){
			delete[] location;
			location=NULL;
			return false;
		}
		if((this->m_pModel->NEval+this->maxLSNEval)/this->m_pModel->NEvalEveryPeroid==this->m_pModel->changeStep){//to make sure no change would happen within the procedure
			if(this->m_pModel->n_con>0){
				//as the local search operator requires a lot of function evaluations, reevaluating its constraints is to ensure that the time is not wasted
				this->m_pModel->EvaluateC(ind.x,ind.c);
				this->m_pModel->ConstraintViolation(ind.x,ind.c,ind.v,ind.SumVio,ind.MaxVio,ind.feasible);
				if(!ind.is_feasible()){
					// a change is detected
					delete[] location;
					location=NULL;
					return true;
				}
			}
			//apply the local search operator on ind
			PSOAgent old2=ind;			
			this->LocalSearch_sqp(ind,location,fitness,conVio);	
			ind.updateThroughLocalSearch(location,fitness,conVio);

#ifdef UseRepair	
			if(!ind.is_feasible()){
				PSOAgent old3(ind);// the post-local-search particle
				this->GradientRepairOperation(ind.x,ind.x,ind.c);//conduct gradient-based repair
				ind.updateVelocity(ind.x,old3.x);
				ind.step();//evaluate
				if(old3.dominate(ind)){
					ind=old3;
				}
			}
#endif

			if(ind.is_feasible()){
				double LSDis=this->distance(old2.x,ind.x);	

				for(int i=0;i<this->m_pModel->n_var;i++){
					this->tmpVec[i]=old2.x[i];
				}
				this->LSMemory.push_back(tmpVec);//the location before local search
				this->LSRadius.push_back(LSDis);

				for(int i=0;i<this->m_pModel->n_var;i++){
					this->tmpVec[i]=ind.x[i];
				}
				this->LSMemory.push_back(tmpVec);//the location after local search
				this->LSRadius.push_back(LSDis);				
			}
			if(old2.dominate(ind)){
				ind=old2;
			}
		}

#endif
		/*************end adaptive local search (ALS) *****************/
	}
	//if flag_pbest is true, then choose pbest to conduct the procedure
	//in this version, it is not used
	else{		
		
		/*************adaptive local search (ALS) *****************/
#ifdef UseLS				
		/****local seach*****/		
		if(ind.isFeasible_pBest()&&(this->CheckForLocalSearch(ind.pBest))&&(this->m_pModel->NEval+maxLSNEval)/this->m_pModel->NEvalEveryPeroid==this->m_pModel->changeStep){	
			if(this->m_pModel->n_con>0){
				this->m_pModel->EvaluateC(ind.pBest,ind.c_pBest);
				this->m_pModel->ConstraintViolation(ind.pBest,ind.c_pBest,ind.v_pBest,ind.pBestValue,ind.MaxV_pBest,ind.isFea_pBest);
				if(!ind.isFeasible_pBest()){
					// a change is detected
					delete[] location;
					location=NULL;
					return true;
				}
			}
			PSOAgent old2=ind;
			this->LocalSearch_sqp(ind,location,fitness,conVio);		
			ind.updateThroughLocalSearch(location,fitness,conVio,true);			
#ifdef UseRepair
			//if the individual acquired by local search is infeasible, then repair it again
			if(!ind.isFeasible_pBest()){
				PSOAgent old3(ind);// the post-local-search particle
				this->GradientRepairOperation(ind.pBest,ind.pBest,ind.c_pBest);
				ind.updateVelocity(ind.pBest,old3.pBest);
				ind.step_pBest();//evaluate
				if(old3.dominate_pBest(ind))
					ind=old3;
			}
#endif
			if(ind.isFeasible_pBest()){
				double LSDis=this->distance(ind.pBest,old2.pBest);
				for(int i=0;i<this->m_pModel->n_var;i++){
					this->tmpVec[i]=old2.pBest[i];
				}				
				this->LSMemory.push_back(tmpVec);//the location before local search
				this->LSRadius.push_back(LSDis);
				for(int i=0;i<this->m_pModel->n_var;i++){
					this->tmpVec[i]=ind.pBest[i];
				}
				this->LSMemory.push_back(tmpVec);//the location after local search
				this->LSRadius.push_back(LSDis);

			}
			if(old2.dominate_pBest(ind)){
				ind=old2;
			}
		}//end if local search	
#endif
		/*************end adaptive local search (ALS) *****************/
	}//end if(!flag_pbest)
	delete[] location;
	location=NULL;
	return false;

}
//the procedure of conducting the local search operator (SQP)
//note that in this function, the mixed programming of C++ and MATLAB is used, because
//the matlab function fmincon is employed by calling the dynamic link library (dll) "libMyAdd.dll"
void MySwarm::LocalSearch_sqp(PSOAgent&ind,double*tmpX,double &tmpFit,double& SumVio){
	this->currentLSTimes++;
#ifdef UseLS
#ifdef DEBUG
	cout<<"Before local search\nthe best feasible solution:"<<ind.x[0]<<" , "<<ind.x[1]<<endl;
	cout<<"NEval so far: "<<this->m_pModel->NEval<<endl;
#endif
	//matlab
	bool get_feasible=false;
	int times=0;

#ifdef OutputLS
	this->outputLS<<"Gen: "<<setfill('0')<<setw(4)<<this->m_pModel->gen<<"  ||Before local search NEval:"<<setfill('0')<<setw(5)<<this->m_pModel->NEval<<"  ||    ";
	if(this->flag_pbest==true){
		this->outputLS<<"solution:["<<setiosflags(ios::fixed)<<setprecision(6)<<ind.pBest[0]<<" , "<<setiosflags(ios::fixed)<<setprecision(6)<<ind.pBest[1]<<"]  "<<"fitness:  "<<setiosflags(ios::fixed)<<setprecision(6)<<ind.getPBestFit()<<"  ||  ";
		this->outputLS<<"region: "<<ind.getRegionID_pBest()<<endl;
		if(this->m_pModel->Problem>=10000){
			this->outputLS<<"true fitness: "<<this->m_pModel->mpb->dummyEval(ind.pBest)<<endl;
			this->outputLS<<"true constraints violation:"<<this->m_pModel->delta_t-this->m_pModel->mfrb->dummyEval(ind.pBest)<<endl;
		}
	}else{
		this->outputLS<<"solution:["<<setiosflags(ios::fixed)<<setprecision(6)<<ind.x[0]<<" , "<<setiosflags(ios::fixed)<<setprecision(6)<<ind.x[1]<<"]  "<<"fitness:  "<<setiosflags(ios::fixed)<<setprecision(6)<<ind.getFitness()<<"  ||  ";
		this->outputLS<<"region: "<<ind.getRegionID()<<endl;
		if(this->m_pModel->Problem>=10000){
			this->outputLS<<"true fitness: "<<this->m_pModel->mpb->dummyEval(ind.x)<<endl;
			this->outputLS<<"true constraints violation:"<<this->m_pModel->delta_t-this->m_pModel->mfrb->dummyEval(ind.x)<<endl;
		}
	}


#endif

	mwArray x_old(1,this->m_pModel->n_var,mxDOUBLE_CLASS);
	mwArray x_new(1,this->m_pModel->n_var,mxDOUBLE_CLASS);
	mwArray numEval(1,1,mxDOUBLE_CLASS);
	mwArray numConst(1,1,mxDOUBLE_CLASS);
	mwArray fitness(1,1,mxDOUBLE_CLASS);
	mwArray conVio(1,1,mxDOUBLE_CLASS);
	mwArray left(1,this->m_pModel->n_var,mxDOUBLE_CLASS);
	mwArray right(1,this->m_pModel->n_var,mxDOUBLE_CLASS);
	mwArray S0(1,1,mxDOUBLE_CLASS);
	mwArray k0(1,1,mxDOUBLE_CLASS);
	mwArray P(1,1,mxDOUBLE_CLASS);
	mwArray flag_change(1,1,mxDOUBLE_CLASS);
	mwArray Period(1,1,mxDOUBLE_CLASS);
	mwArray val1(1,1,mxDOUBLE_CLASS);
	mwArray val2(1,1,mxDOUBLE_CLASS);
	mwArray val3(1,1,mxDOUBLE_CLASS);
	mwArray flag(1,1,mxDOUBLE_CLASS);//just for test

	mwArray numPeaks(1,1,mxDOUBLE_CLASS);
	mwArray numRegions(1,1,mxDOUBLE_CLASS);
	mwArray mpb_changeType(1,1,mxDOUBLE_CLASS);
	mwArray mfrb_changeType(1,1,mxDOUBLE_CLASS);
	mwArray con_par(1,1,mxDOUBLE_CLASS);
	mwArray times_con(1,1,mxDOUBLE_CLASS);
	mwArray times_len(1,1,mxDOUBLE_CLASS);
	double rPeaks,rRegions,tmpCT_mpb,tmpCT_mfrb;
	ChangeType ct_mpb,ct_mfrb;

	if(this->m_pModel->Problem>=10000){
		rPeaks=this->m_pModel->mpb->getNumberofPeak();
		rRegions=this->m_pModel->mfrb->getNumberofPeak();
		ct_mpb=this->m_pModel->mpb->getChangeType();
		ct_mfrb=this->m_pModel->mfrb->getChangeType();

		switch(ct_mpb){
		case CT_Random:
			tmpCT_mpb=0.;
			break;
		case CT_Linear:
			tmpCT_mpb=1.0;
			break;
		case CT_Cyclic:
			tmpCT_mpb=2.0;
			break;
		case CT_Decay:
			tmpCT_mpb=3.0;
			break;
		case CT_Chaotic:
			tmpCT_mpb=4.0;
			break;
		case CT_None:
			tmpCT_mpb=5.0;
			break;
		case CT_Recurrent:
			tmpCT_mpb=6.0;
			break;
		case CT_RecurrentNoisy:
			tmpCT_mpb=7.0;
			break;
		default:
			tmpCT_mpb=8.0;
			break;

		}


		switch(ct_mfrb){
		case CT_Random:
			tmpCT_mfrb=0.;
			break;
		case CT_Linear:
			tmpCT_mfrb=1.0;
			break;
		case CT_Cyclic:
			tmpCT_mfrb=2.0;
			break;
		case CT_Decay:
			tmpCT_mfrb=3.0;
			break;
		case CT_Chaotic:
			tmpCT_mfrb=4.0;
			break;
		case CT_None:
			tmpCT_mfrb=5.0;
			break;
		case CT_Recurrent:
			tmpCT_mfrb=6.0;
			break;
		case CT_RecurrentNoisy:
			tmpCT_mfrb=7.0;
			break;
		default:
			tmpCT_mfrb=8.0;
			break;

		}

	}
	else{
		rPeaks=1;
		rRegions=1.;
		tmpCT_mfrb=0;
		tmpCT_mpb=0;

	}

	numPeaks.SetData(&rPeaks,1);
	numRegions.SetData(&rRegions,1);
	mfrb_changeType.SetData(&tmpCT_mfrb,1);
	con_par.SetData(&this->m_pModel->delta_t,1);
	mpb_changeType.SetData(&tmpCT_mpb,1);

	if(this->flag_pbest==true){
		x_old.SetData(ind.pBest,this->m_pModel->n_var);
#ifdef G24
		if(this->m_pModel->NEval <= (this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
			this->m_pModel->numALSInEachRegion[ind.getRegionID_pBest()-1]++;
		}
#else				
		int i=0,numRegion=ind.m_pModel->mfrb->getNumberofPeak();		

		if(this->m_pModel->NEval <= (this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
			this->m_pModel->numALSInEachRegion[ind.getRegionID_pBest()]++;
		}
#endif

	}
	else{
		x_old.SetData(ind.x,this->m_pModel->n_var);
#ifdef G24
		if(this->m_pModel->NEval <= (this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
			this->m_pModel->numALSInEachRegion[ind.getRegionID()-1]++;
		}
#else		

		if(this->m_pModel->NEval <= (this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid)){
			this->m_pModel->numALSInEachRegion[ind.getRegionID()]++;
		}
#endif

	}
	numEval.SetData(&this->m_pModel->NEval,1);
	S0.SetData(&this->m_pModel->S,1);
	k0.SetData(&this->m_pModel->k,1);
	P.SetData(&this->m_pModel->Problem,1);

	double* tempLb=new double[this->m_pModel->n_var];
	double* tempUb=new double[this->m_pModel->n_var];
	for(int i=0;i<this->m_pModel->n_var;i++){
		tempLb[i]=this->m_pModel->LUv[i*2];
		tempUb[i]=this->m_pModel->LUv[i*2+1];
	}
	left.SetData(tempLb,this->m_pModel->n_var);
	right.SetData(tempUb,this->m_pModel->n_var);
	val1.SetData(&this->m_pModel->val_1,1);
	val2.SetData(&this->m_pModel->val_2,1);
	val3.SetData(&this->m_pModel->val_3,1);
	double testflag=0.0;
#ifdef TestEffectofDynamicSeverity
	testflag=1.0;
#endif
	flag.SetData(&testflag,1);

	Period.SetData(&this->m_pModel->NEvalEveryPeroid,1);
#ifndef G24
	times_con.SetData(&this->m_pModel->mfrb->getTimes_con(),1);
	times_len.SetData(&this->m_pModel->mfrb->getTimes_len(),1);
#else
	double no_use=0.0;
	times_con.SetData(&no_use,1);
	times_len.SetData(&no_use,1);
#endif

	localSearch(6,x_new,fitness,conVio,numEval,numConst,flag_change,numEval,x_old,left,right,S0,k0,P,Period,val1,val2,val3,flag,numPeaks, numRegions, mpb_changeType, mfrb_changeType, con_par,times_con,times_len);//2,x_new,fitness,numEval,x_old);

	delete[] tempLb;
	delete[] tempUb;

	for(int i=0;i<this->m_pModel->n_var;i++){
		tmpX[i]=x_new.Get(1,i+1);
	}

	tmpFit=fitness.Get(1,1);
	SumVio=conVio.Get(1,1);	

	double NEval_new=numEval.Get(1,1);

	this->m_pModel->NConst+=(int)numConst.Get(1,1);	
	int NEval_old=this->m_pModel->NEval;
	this->m_pModel->NEval=NEval_new;	
	if(this->m_pModel->NEval<=(this->m_pModel->NEvalEveryPeroid*this->m_pModel->getMaxStep())){
		this->m_pModel->NumALS++;
		this->m_pModel->NEvalALS+=NEval_new-NEval_old;
	}
	int tmpTime=this->m_pModel->changeStep;
	this->m_pModel->changeStep=(int)(this->m_pModel->NEval/this->m_pModel->NEvalEveryPeroid);
	double HasChanged_matlab=flag_change.Get(1,1);	
#ifdef OutputLS	
	this->outputLS<<"         "<<"  ||After  local search NEval:"<<setfill('0')<<setw(5)<<this->m_pModel->NEval<<"  ||    ";
	this->outputLS<<"solution:["<<setiosflags(ios::fixed)<<setprecision(6)<<tmpX[0]<<" , "<<setiosflags(ios::fixed)<<setprecision(6)<<tmpX[1]<<"]  "<<"fitness:  "<<setiosflags(ios::fixed)<<setprecision(6)<<tmpFit<<"  || isFeasible  "<<this->m_pModel->dummyIsFeasible(tmpX)<<endl<<endl;
#endif
	
#ifdef Test
	cout<<"local search end\n";
#endif
#endif

}
//part of Alg. 5
bool MySwarm::CheckForLocalSearch(double*x1){
	//if(this->m_pModel->NEval>=(this->m_pModel->getMaxStep()*this->m_pModel->NEvalEveryPeroid))return false;
	if(this->currentLSTimes >= this->maxLSTimesPerPeriod)
		return false;//the maximum times of local search has been reached

	bool flag=true;
	double* x2=new double[this->m_pModel->n_var];

	for(vector<vector<double>>::iterator li=this->LSMemory.begin();li!=this->LSMemory.end();li++){
		for(int i=0;i<this->m_pModel->n_var;i++){
			x2[i]=(*li)[i];
		}		

		if(this->distance(x1,x2)<this->LSRadius[li-this->LSMemory.begin()]){
			flag=false;// x1 would not be selected for local search
			break;
		}
	}
	delete[]x2;
	return flag;
}
//part of Alg. 6
void MySwarm::updateLocalMemoryPerGen(){
#ifdef DEBUG
	cout<<"updateLocalMemoryPerGen "<<this->m_pModel->gen<<endl;
#endif
	bool flag_changed=false;	
#ifdef OutputLS1
	this->outputLS<<"updateLocalMemoryPerGen "<<this->m_pModel->gen<<endl;
	this->outputLS<<"memory so far \n";
	for(vector<MemoryEntry>::iterator lj=this->LocalMemory.begin();lj!=this->LocalMemory.end();lj++){	
		this->outputLS<<lj->getFeaInd().OutputLocation();
	}
	this->outputLS<<endl<<"before update memory size: "<<this->LocalMemory.size()<<endl;
	for(vector<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){
		for(vector<MemoryEntry>::iterator lj=li+1;lj!=this->LocalMemory.end();lj++){
			outputLS<<"index ["<<li-this->LocalMemory.begin()<<", "<<lj-this->LocalMemory.begin()<<"] "<<this->distance(li->getFeaInd().x,lj->getFeaInd().x)<<endl;
		}

	}
#endif

	bool flag=false;	
	//add all feasible seeds into the memory
	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){	
		if(!this->population[li->seed].is_feasible())
			continue;
		flag=false;
		MemoryEntry tmpMem(this->population[li->seed]);
		this->LocalMemory.push_back(tmpMem);

	}

	//add all feasible pbest into the memory
	for(int i=0;i<this->popSize;i++){
		if(this->population[i].isFeasible_pBest()){
			MemoryEntry tmpMem(this->population[i],true);
			this->LocalMemory.push_back(tmpMem);
		}
	}
#ifdef OutputTest1
	ofPopInfo<<"before \n";
	for(int i=0;i<this->LocalMemory.size();i++)
		this->ofPopInfo<<i<<", "<<this->LocalMemory[i].getFlag()<<", InfeaInd"<<this->LocalMemory[i].getInFeaInd().OutputLocation()<<", dis:"<<this->LocalMemory[i].getDis()<<", feaInd:"<<this->LocalMemory[i].getFeaInd().OutputLocation()<<endl;
	ofPopInfo<<"\n";
#endif
	//classify the memory into species
	this->classifyMemoryIntoSpecies();
	//only the seeds in the memory are reserved
	this->LocalMemory=this->memorySeeds;

	//clear the temporary memory
	this->memorySeeds.clear();
	this->memorySeeds.shrink_to_fit();
#ifdef OutputTest1
	ofPopInfo<<"middle \n";
	for(int i=0;i<this->LocalMemory.size();i++)
		this->ofPopInfo<<i<<", "<<this->LocalMemory[i].getFlag()<<", InfeaInd"<<this->LocalMemory[i].getInFeaInd().OutputLocation()<<", dis:"<<this->LocalMemory[i].getDis()<<", feaInd:"<<this->LocalMemory[i].getFeaInd().OutputLocation()<<endl;
	ofPopInfo<<"\n";
#endif


#ifdef DEBUG
	cout<<"updateLocalMemoryPerGen end  "<<this->m_pModel->gen<<endl;
#endif
}
//part of Alg. 6
//the codes are prepared for detecting changes in infeasible areas in Alg. 10
void MySwarm::addInfeaParticlesIntoMemory(){
#ifdef UseChangeDetectionStrategy
	for(int i=0;i<this->popSize;i++){		
		if(this->population[i].getIsActive()==false||this->population[i].is_feasible())continue;
		for(deque<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){			
			if(li->getFlag()==false){
				li->setInfeaInd(this->population[i]);				
			}else{
				li->updateInfeaInd(this->population[i]);				
			}	

		}
	}

	//for(int i=0;i<this->popSize;i++){
	//	if(this->population[i].isFeasible_pBest())continue;
	//	for(deque<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){
	//		if(li->getFlag()==false){
	//			li->setInfeaInd(this->population[i],true);
	//		}else{
	//			li->updateInfeaInd(this->population[i],true);
	//		}
	//	}
	//}
#ifdef OutputTest1
	ofPopInfo<<"finally \n";
	for(int i=0;i<this->LocalMemory.size();i++)
		this->ofPopInfo<<i<<", "<<this->LocalMemory[i].getFlag()<<", InfeaInd"<<this->LocalMemory[i].getInFeaInd().OutputLocation()<<", dis:"<<this->LocalMemory[i].getDis()<<", feaInd:"<<this->LocalMemory[i].getFeaInd().OutputLocation()<<endl;
	ofPopInfo<<"\n";
#endif
#endif
}
//Alg. 7
void MySwarm::updateMemoryPerChange(){
	/***/
	//for solutions stored in memory, a MemorySpecies represents a species
	//memlist[0] represents the seed of each species
	/***/
	for(deque<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){

		////if it is the best point in the period
		//if(this->isRedundant(li->getFeaInd().x,tmpInd.x))//li->getFeaInd().getPBestFit()==tmpInd.getPBestFit()&&
		//	continue;
		if(!this->memory.empty()){
			bool tmpFlag=false;
			double tmpDis=-1.0;
			for(vector<MemorySpecies>::iterator lj=this->memory.begin();lj!=this->memory.end();lj++){
				tmpDis=this->distance(lj->memlist[0].x,li->getFeaInd().x);
				if(tmpDis>=0.&&tmpDis<this->radius){//if in the same species
					lj->memlist.push_back(li->getFeaInd());
					lj->num++;
					tmpFlag=true;
					break;
				}
				//else if(tmpDis==0.0){//if the two points are the same, do nothing
				//	tmpFlag=true;
				//	break;
				//}
			}
			if(!tmpFlag){//if the point in the current memroy is not in the same species with the point in memory, then add it to a new cluster
				MemorySpecies tmpCluster;
				tmpCluster.memlist.push_back(li->getFeaInd());
				tmpCluster.num++;
				this->memory.push_back(tmpCluster);
			}
		}else{
			MemorySpecies tmpCluster;
			tmpCluster.memlist.push_back(li->getFeaInd());
			tmpCluster.num++;
			this->memory.push_back(tmpCluster);
		}

	}
	//record the best memory	

	
	PSOAgent previousBestSolution(this->bestInGen[this->m_pModel->gen-1]);
	previousBestSolution.ConvertToPoint(previousBestSolution);//x=pbest

	if(!this->bestMemory.empty()){
		bool tmpFlag=false;
		double tmpDis=-1.0;
		for(vector<MemorySpecies>::iterator lj=this->bestMemory.begin();lj!=this->bestMemory.end();lj++){
			tmpDis=this->distance(lj->memlist[0].x,previousBestSolution.x);
			if(tmpDis>=0.&&tmpDis<this->radius){//if in the same species
				lj->memlist.push_back(previousBestSolution);
				lj->num++;
				tmpFlag=true;
				break;
			}
			//else if(tmpDis==0.0){//if the two points are the same, do nothing
			//	tmpFlag=true;
			//	break;
			//}
		}
		if(!tmpFlag){//if the point in the current memroy is not in the same species with the point in memory, then add it to a new cluster
			MemorySpecies tmpCluster;
			tmpCluster.memlist.push_back(previousBestSolution);
			tmpCluster.num++;
			this->bestMemory.push_back(tmpCluster);
		}
	}else{
		MemorySpecies tmpCluster;
		tmpCluster.memlist.push_back(previousBestSolution);
		tmpCluster.num++;
		this->bestMemory.push_back(tmpCluster);
	}
	//end record the best memory 
}
//Alg. 8
void MySwarm::trackingPreviouslyFeasibleRegionsStrategy(){
#ifdef UseTrackingPreviouslyAppearedFeasibleRegionsStrategy
	/*int loop = index;
	int numPool=this->replacePool.end()-this->replacePool.begin();	*/
	//recall the best solutions found in previous periods
	//conduct repair and local search on these solutions	
	for(int i=0;(i<this->bestMemory.end()-this->bestMemory.begin());i++){
		int randnum=this->m_pModel->getRandomInt(this->bestMemory[i].num);
		/*******repair and local search********/
		PSOAgent agent(this->bestMemory[i].memlist.at(randnum));
		/*agent.ConvertToPoint(agent);*/
		agent.resetPBest();
		agent.step();//evaluate
		this->flag_pbest=false;
		this->repair(agent);
		
		/*******repair and local search end********/
		this->promisingPool.push_back(agent);
		this->Pool.push_back(agent);
		//population[this->replacePool[loop++]].reinitialization(agent);
#ifdef OutputTest1
		outfile<<"BestMemory :  num("<<numBest<<")  "<<loop<<"  "<<this->bestMemory[i].memlist.at(randnum).OutputPBest()<<"  after local search: "<<tmpInd.OutputPBest()<<endl;
#endif
	}

#ifdef OutputLS
	this->outputLS<<"end recall best memory\n";
	this->outputRepair<<"end recall best memory\n";
#endif

#ifdef OutputLS
	this->outputLS<<"recall all memory\n";
	this->outputRepair<<"recall all memory\n";
#endif

	for(int i=0;i<(this->memory.end()-this->memory.begin()) ;i++){
		int randnum=this->m_pModel->getRandomInt(this->memory[i].num);
		/*******repair and local search********/
		PSOAgent agent(this->memory[i].memlist.at(randnum));
		agent.resetPBest();
		agent.step();//evaluate
		this->flag_pbest=false;
		this->repair(agent);
		/*******repair and local search end********/	
		this->promisingPool.push_back(agent);
		this->Pool.push_back(agent);
		//population[this->replacePool[loop++]].reinitialization(agent);
#ifdef OutputLS1
		outfile<<"memory :  num("<<numMem<<")  "<<loop<<"  "<<this->memory[i].memlist.at(randnum).OutputPBest()<<"  after local search:"<<tmpInd.OutputPBest()<<endl;
#endif
	}
#ifdef OutputLS
	this->outputLS<<"end recall all memory\n";
	this->outputRepair<<"end recall all memory\n";
#endif
	
#endif

}
//Alg. 9 Species-based prediction
void MySwarm::predictingFutureFeasibleRegionsStrategy(){
#ifdef UsePredictingFutureFeasibleRegionsStrategy
#ifdef OutputLS
	this->outputLS<<"species-based predition\n";
	this->outputRepair<<"species-based predition\n";
#endif
#ifdef OutputTest1
	outfile<<"the num of memory:  "<<this->LocalMemory.end()-this->LocalMemory.begin()<<endl;
#endif
	/*int loop=index;
	int numPool=this->replacePool.end()-this->replacePool.begin();	*/
	if(!this->preLocalMemory.empty()){
		for(deque<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){
			double dis=this->m_pModel->getInfty();
			vector<MemoryEntry>::iterator p;
			for(vector<MemoryEntry>::iterator lj=this->preLocalMemory.begin();lj!=this->preLocalMemory.end();lj++){
				
				double temp=this->distance(li->getFeaInd().x,lj->getFeaInd().x);
				if(temp<dis){
					dis=temp;
					p=lj;
				}
			}
			double * direction=new double[this->m_pModel->n_var];
			double* newLoc=new double[this->m_pModel->n_var];
			for(int i=0;i<this->m_pModel->n_var;i++){
				direction[i]=li->getFeaInd().x[i]-p->getFeaInd().x[i];
				newLoc[i]=li->getFeaInd().x[i]+direction[i];
			}				
			/*******repair and local search********/
			PSOAgent agent(this->m_pModel);
			agent.setLocation(newLoc);	
			agent.updateVelocity(newLoc,li->getFeaInd().x);//update the velocity
			agent.resetPBest();
			agent.step();//evaluate
#ifdef OutputLS1
			outfile<<"through prediction: "<<tmpInd.OutputPBest()<<"  ";
#endif
			this->flag_pbest=false;
			this->repair(agent);				
			/*******repair and local search********/
			//replace using the newly created individual

			//population[this->replacePool[loop++]].reinitialization(agent);
			this->promisingPool.push_back(agent);
			this->Pool.push_back(agent);
#ifdef OutputLS1
			outfile<<"after repair and local search: "<<tmpInd.OutputPBest()<<endl;
#endif
			delete[]direction;
			delete[]newLoc;
			break;


		}

	}
	
#ifdef OutputLS
	this->outputLS<<"species-based predition end\n";
	this->outputRepair<<"species-based predition end\n";
#endif
#endif
}
//Alg. 10
bool MySwarm::detectChange(){
#ifdef DEBUG
	cout<<"detect change\n";
#endif	
	this->has_change=false;	
#ifdef DSPSO
	for(int count=0;count<numToCheck&&count<this->currentSpecies.size();count++){
		int index=this->currentSpecies[count].seed;
		double curFit=this->population[index].getPBestFit();
		bool curIsFea=this->population[index].isFeasible_pBest();
		if(this->m_pModel->n_con>0){//n_con is the number of constraints
			this->m_pModel->EvaluateC(population[index].pBest,population[index].c_pBest);
			this->m_pModel->ConstraintViolation(population[index].pBest,population[index].c_pBest,population[index].v_pBest,population[index].pBestValue,population[index].MaxV_pBest,population[index].isFea_pBest);
			if(population[index].isFeasible_pBest()!=curIsFea){
				this->has_change=true;	// a change is detected					
				//cout<<1<<endl;
				break;
			}
		}
		this->m_pModel->EvaluateF(this->population[index].pBest,this->population[index].pBestFit);		
		if(curFit!=this->population[index].getPBestFit()){
			this->has_change=true;// a change is detected			
			//cout<<2<<endl;
			break;
		}
	}
#else //the change detection strategy of LTFR-DSPSO

	/***********dectect whether the constraints have a change**********************/
	if(preMemory.empty())return false;

	deque<MemoryEntry>::iterator li=this->preMemory.begin();
	if(this->m_pModel->n_con>0){
		for(int i=0;li!=this->preMemory.end();li++){
			//cout<<"ID: "<<i++<<endl;
			//detect the infeasible individuals in the memory
			if(this->m_pModel->n_con>0){//n_con is the number of constraints
				if(li->getFlag()){
					this->m_pModel->EvaluateC(li->getInFeaInd().x,li->getInFeaInd().c);
					this->m_pModel->ConstraintViolation(li->getInFeaInd().x,li->getInFeaInd().c,li->getInFeaInd().v,li->getInFeaInd().SumVio,li->getInFeaInd().MaxVio,li->getInFeaInd().feasible);
					if(li->getInFeaInd().is_feasible()){
						this->has_change=true;	// a change is detected
						//cout<<1<<endl;
						//cout<<1<<endl;
						break;
					}
				}
			}

			//detect the feasible indiviudals in the memory			
			this->m_pModel->EvaluateC(li->getFeaInd().x,li->getFeaInd().c);
			this->m_pModel->ConstraintViolation(li->getFeaInd().x,li->getFeaInd().c,li->getFeaInd().v,li->getFeaInd().SumVio,li->getFeaInd().MaxVio,li->getFeaInd().feasible);//li->getFeaInd().isFea_pBest
			if(!li->getFeaInd().is_feasible()){	
				this->has_change=true;// a change is detected
				//cout<<2<<endl;
				//cout<<2<<endl;
				break;
			}
		}
	}
	/***********dectect whether the constraints have a change end**********************/
	/******************detect whether the objective function values have a change************************/
	if(this->m_pModel->Problem<1000&&this->m_pModel->Problem!=7&&this->m_pModel->Problem!=8&&this->m_pModel->Problem!=10&&this->m_pModel->Problem!=11&&this->m_pModel->Problem!=16){
		li=this->preMemory.begin();
		int count=0;
		for(;li!=this->preMemory.end()&&count<this->numToCheck;li++){
			count++;
			double tmpFit=li->getFeaInd().getFitness();
			this->m_pModel->EvaluateF(li->getFeaInd().x,li->getFeaInd().fitness);		
			if(tmpFit!=li->getFeaInd().getFitness()){
				this->has_change=true;// a change is detected
				//cout<<3<<endl;
				//cout<<3<<endl;
				break;
			}
		}
	}
	/******************detect whether the objective function values have a change end************************/	
#endif
	return has_change;

#ifdef DEBUG
	cout<<"detect change end\n";
#endif

}
//Alg. 11 Re-initialization when a change is detected
void MySwarm::Reinitialization(){	
#ifdef DEBUG
	cout<<"Reinitialization"<<endl;
#endif
#ifdef OutputInfomationPerChange
	ofstream outfile;
	outfile.open(this->m_pModel->output,ofstream::out|ofstream::app);
	if(!outfile){
		cout<<"cannot open the outfile!"<<endl;
		system("pause");
		exit(0);
	}
#endif

	//reset the values	
#ifndef originalDSPSO
	this->population=this->prePop;
	//this->preSpecies=this->currentSpecies;
	this->currentSpecies=this->preSpecies;
	LocalMemory=preMemory;
#endif
	this->updateSpeciesRadius();//update the radius if a dynamic radius is adopted
	this->LSMemory.clear();
	this->LSRadius.clear();	
	if(!promisingPool.empty())promisingPool.clear();
	if(!this->Pool.empty())this->Pool.clear();
	this->LSRadius.clear();
	if(!this->LSMemory.empty())
		this->LSMemory.clear();
	this->currentLSTimes=0;	

	/***********1. update the memory sets, i.e. $memory$ and $bestMem$***********/
#ifndef originalDSPSO
	updateMemoryPerChange();
#endif
	/***********end 1. update the memory sets, i.e. $memory$ and $bestMem$***********/

	/*********2. reset the particles**********/
	for(int i=0;i<popSize;i++){
		population[i].setPBestFit(this->m_pModel->getInfty());
		population[i].setFitness(this->m_pModel->getInfty());
		if(this->m_pModel->n_con>0){
			population[i].setFea_pBest(false);
			population[i].setFea(false);
		}
		//reevaluate each pbest 	
		population[i].Reinitialization();		
	}
	/*********end reset the particles**********/
#ifndef originalDSPSO
	/*************************3. tracking current feasible regions strategy**************************/
#ifdef UseTrackingCurrentFeasibleRegionsStrategy	
	
	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){	
		this->population[li->seed].step();//reevalute the seeds
		//speices-based repair (SRS) 
		this->flag_pbest=false;
		repair(this->population[li->seed]);
		if(this->population[li->seed].is_feasible()){
			this->promisingPool.push_back(this->population[li->seed]);
		}		
	}

	allocateNeighbourBest();

	for(vector<Species>::iterator li=this->currentSpecies.begin();li!=this->currentSpecies.end();li++){			
		//make other particles follow the seeds
		for(int i=1;i<li->numTotal;i++){
			this->population[li->totalList[i]].update();
			this->population[li->totalList[i]].step();
		}
	}
#else 
	for(int i=0;i<popSize;i++){
		population[i].step();
	}
#endif
	/*************************end tracking current feasible regions strategy**************************/

	trackingPreviouslyFeasibleRegionsStrategy();//5. tracking previouly appeared feasible regions strategy

	predictingFutureFeasibleRegionsStrategy();//6. species-based prediction

	this->replaceStrategy();//4. the replace strategy

	/*******record the current memory of this period***********/
	this->preLocalMemory.clear();//the memory, recording the current local memory, is used for the prediction strategy in the next time period
	this->preLocalMemory.insert(this->preLocalMemory.end(),this->LocalMemory.begin(),this->LocalMemory.end());
	/*******record the current memory of this period end*********/
#endif
#ifdef Test
	outfile<<endl;
	for(vector<MemoryEntry>::iterator li=this->LocalMemory.begin();li!=this->LocalMemory.end();li++){
		outfile<<"memory: "<<li->getFeaInd().pBest[0]<<"  "<<li->getFeaInd().pBest[1]<<"   fit  "<<li->getFeaInd().getPBestFit()<<endl;
	}
	outfile<<endl;
#endif
	this->LocalMemory.clear();	
	this->preMemory.clear();
	this->promisingPool.clear();
	this->Pool.clear();
	
#ifdef OutputInfomationPerChange
	outfile.close();
#endif
#ifdef DEBUG
	cout<<"Reinitialization end"<<endl;
#endif
}
//Alg. 12
void MySwarm::replaceStrategy(){
	//promisingPool��Ϊ���ָ��ٲ��Եõ��ĸ���
	//��promisingPool�еĸ��尴��Deb����������򣬽�������
	sort(promisingPool.begin(),promisingPool.end(),less<Point>());//����
	//���ζ�pool�е�ÿ�����и���Ӧ��ALS���ԣ��Ծ����Ƿ������оֲ�����
	for(int i=0;i<promisingPool.size() && this->currentLSTimes < this->maxLSTimesPerPeriod;i++){
		if(promisingPool[i].is_feasible()){
			PSOAgent tmp=promisingPool[i];
			this->LocalSearch(promisingPool[i]);
			if(!tmp.isRedundant(promisingPool[i])){
				this->Pool.push_back(promisingPool[i]);
			}
		}
	}
	//����Ⱥpop�еĸ������pool
	for(int i=0;i<this->popSize;i++){
		if(this->population[i].getIsActive()){			
			this->Pool.push_back(this->population[i]);
		}
	}
	this->population.clear();
	//this->Pool.insert(this->Pool.end(),this->population.begin(),this->population.end());
	if(this->Pool.size()<this->popSize){
		this->population.insert(this->population.end(),this->Pool.begin(),this->Pool.end());
		for(int i=this->Pool.size()+1;i<=this->popSize;i++){
			PSOAgent tmp(this->m_pModel);
			tmp.step();
			this->population.push_back(tmp);
		}
		return;
	}

	vector<bool> flag;
	flag.resize(this->Pool.size(),false);

	//��pool����
	sort(this->Pool.begin(),this->Pool.end(),less<Point>());

	

	//��pool����õ�species
	this->DividingIntoSpecies(this->Pool,false);//classify the new population into species

	int N_pop=0;
	for(int i=0;i<this->currentSpecies.size();i++){		
		if(this->Pool[this->currentSpecies[i].seed].is_feasible()&&N_pop<this->popSize){			
			for(int j=0;j<this->currentSpecies[i].numTotal && N_pop<this->popSize && j<3; j++){
				this->population.push_back(this->Pool[this->currentSpecies[i].totalList[j]]);
				flag[this->currentSpecies[i].totalList[j]]=true;
				N_pop++;
			}
		}
		if(!this->Pool[this->currentSpecies[i].seed].is_feasible()&&N_pop<this->popSize && this->currentSpecies[i].numTotal>=3){			
			for(int j=0;j<this->currentSpecies[i].numTotal && N_pop<this->popSize && j<3; j++){
				this->population.push_back(this->Pool[this->currentSpecies[i].totalList[j]]);
				flag[this->currentSpecies[i].totalList[j]]=true;
				N_pop++;
			}
		}
	}

	//��ʣ����õĸ��������Ⱥ,ֱ����Ⱥ������Ŀ�ﵽpopsize
	for(int i=0;i<this->Pool.size() && N_pop<this->popSize;i++){
		if(!flag[i]){
			this->population.push_back(this->Pool[i]);
			flag[i]=true;
			N_pop++;
		}
	}
	flag.clear();
	flag.shrink_to_fit();

}
void MySwarm::updateOfflineError(){

	if(this->bestInGen[this->m_pModel->gen].isFeasible_pBest()){
		double tmp=(bestInGen[this->m_pModel->gen].getPBestFit()-this->m_pModel->globalValue);
		if(tmp<0.0){
			tmp=0.0;
		}
		this->modifiedOfflineError+=tmp;
	}else{
		if(this->m_pModel->Problem<10000){
			this->modifiedOfflineError+=2.5;
		}else{
			this->modifiedOfflineError+=this->m_pModel->globalValue;
		}
	}
}
void MySwarm::updateMeasurePerGen(){

	int bestIndex=0;		
	for(int i=0;i<this->popSize;i++){
		//#ifdef UseSortingRuleOfOriginalSPSO
		//		if(this->population[i].getPBestFit()>this->population[bestIndex].getPBestFit()){
		//#else
		if(this->population[i].dominate_pBest(this->population[bestIndex])){			
			//#endif		
			bestIndex=i;
		}
	}		
	//record the best solution		
	this->bestInGen.push_back(this->population[bestIndex]);
#ifdef OutputPopInfo
	ofPopInfo<<"gen: "<<this->m_pModel->gen<<", NEval:"<<this->m_pModel->NEval<<endl;
	ofPopInfo<<"bestfit:   "<<this->m_pModel->fit_bestPoint<<", isfea: "<<this->m_pModel->fea_bestPoint<<endl;
	ofPopInfo<<"pbestfit: "<<this->bestInGen[this->m_pModel->gen].getPBestFit()<<", isfea: "<<this->bestInGen[this->m_pModel->gen].isFeasible_pBest()<<", loc: "<<this->bestInGen[this->m_pModel->gen].OutputPBest()<<endl;
#endif

	this->updateOfflineError();

	this->m_pModel->setOfflineError();

#ifndef G24

	bool flag=false;
	int found=0,peakNum=0;
	if(this->m_pModel->Problem>=10000){
		//calculate ORT
		for(int i=0;i<this->popSize;i++){	

			if(this->m_pModel->mfrb->isInGlobalRegion(this->population[i].x)){
				flag=true;
				break;
			}

			if(this->m_pModel->mfrb->isInGlobalRegion(this->population[i].pBest)){
				flag=true;
				break;
			}

		}
		if(flag){
			this->ORT++;
		}
		//no use?
		int numFea=0;
		for(int i=0;i<this->popSize;i++){
			if(this->population[i].getIsActive()&&this->population[i].is_feasible()){
				numFea++;
				this->feaPop.push_back(i);
			}
		}

		//update region cover
		for(int i=0;i<this->popSize;i++){
			for(int j=0;j<this->m_pModel->mfrb->getNumberofPeak();j++){
				if(this->m_pModel->mfrb->isInRegion(this->population[i].x,j)){
					this->m_pModel->numIndEachRegion[this->m_pModel->mfrb->getRealRegionIndex(j)]++;
					break;
				}				
			}
		}
		for(int i=0;i<this->popSize;i++){
			for(int j=0;j<this->m_pModel->mfrb->getNumberofPeak();j++){
				if(this->m_pModel->mfrb->isInRegion(this->population[i].pBest,j)){
					this->m_pModel->numIndEachRegion[this->m_pModel->mfrb->getRealRegionIndex(j)]++;	
					break;
				}			
			}
		}
		for(int i=0;i<this->m_pModel->mfrb->getNumberOfDisconnectedFeasibleRegions();i++){			
			if(this->m_pModel->numIndEachRegion[i]>0){
				found++;
			}						
		}
		this->m_pModel->peak_found=(double)found;
	}
	//add the best fitness in this gen to the vector
	//this->bestFitness_inGen.push_back(this->m_pModel->fit_bestPoint);
#endif
#ifdef OutputLS
	//output the region ID of each ind
	this->outputRegionIDOfPop();
#endif
	//count infeasilbe generations
	//if(this->m_pModel->fea_bestPoint==false)
	if(this->bestInGen[this->m_pModel->gen].isFeasible_pBest()==false)
		this->m_pModel->numGenInfeasible++;


	//the generation counter increases
	this->m_pModel->gen=this->m_pModel->gen+1;


}
void MySwarm::updateSpeciesRadius(){
#ifndef DefineDynamicRadius
	if(this->m_pModel->Problem==10000&&this->m_pModel->n_var==4){
		radius=30;
	}
	else if(this->m_pModel->Problem>=10000){		
		radius=20;			
	}else
		radius=0.7;
#else
	double maxdis=this->m_pModel->LUv[1]-this->m_pModel->LUv[0];//for problems with the same range in each dimension
	double coefficient=1.0;					
	for(int i=0;i<this->m_pModel->n_var/2;i++)coefficient*=(i+1);//coefficient=(n/2)!
	//just for the case the dimension is even, otherwise please refer to Eq. 26 
	double radius=pow(pi,-0.5)*pow(coefficient/(double)this->maxSpeNum,(double)1.0/(double)this->m_pModel->n_var)*(double)maxdis;
#endif
}
bool MySwarm::isRedundant(double *x1, double *x2){
	bool flag=true;
	for(int i=0;i<this->m_pModel->n_var;i++){
		if(x1[i]!=x2[i]){
			flag=false;
			break;
		}
	}
	return flag;
}
bool MySwarm::repairAndLocalSearch(PSOAgent&ind){
	this->flag_pbest=false;
	this->repair(ind);
	if(this->LocalSearch(ind))return true;
	return false;

}
void MySwarm::outputRegionIDOfPop(){
#ifdef OutputPopInfo
	this->ofStreamRegionID<<"gen:  "<<this->m_pModel->gen<<endl;
	this->ofStreamRegionID_pBest<<"gen:  "<<this->m_pModel->gen<<endl;
	this->ofRegionIDFeaInds<<"gen:  "<<this->m_pModel->gen<<endl;
	for(int i=0;i<this->popSize;i++){
		this->ofStreamRegionID<<setfill('0')<<setw(2)<<i<<"  isFeasible:"<<this->population[i].is_feasible()<<"   RegionID:"<<this->population[i].getRegionID()<<"  fitness: "<<this->population[i].getFitness()<<endl;
		this->ofStreamRegionID_pBest<<setfill('0')<<setw(2)<<i<<"  isFeasible:"<<this->population[i].isFeasible_pBest()<<"   RegionID:"<<this->population[i].getRegionID_pBest()<<"  fitness: "<<this->population[i].getPBestFit()<<endl;
		if(this->population[i].isFeasible_pBest()){
			this->ofRegionIDFeaInds<<setfill('0')<<setw(2)<<i<<"   RegionID:"<<this->population[i].getRegionID_pBest()<<",  ";
			this->ofRegionIDFeaInds<<"location:["<<setiosflags(ios::fixed)<<setprecision(6)<<this->population[i].pBest[0]<<" , "<<setiosflags(ios::fixed)<<setprecision(6)<<this->population[i].pBest[1]<<"]  "<<"fitness:  "<<setiosflags(ios::fixed)<<setprecision(6)<<this->population[i].getPBestFit()<<endl;
		}
	}
#endif
}
double MySwarm::getRadius(){
	return radius;
}
double MySwarm::getORT(){
	return this->ORT;
}

double MySwarm::distance(double*x1,double*x2){
	double dis=0.0;
	for(int i=0;i<this->m_pModel->n_var;i++)
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	dis=sqrt(dis);
	return dis;

}

int MySwarm::getTimeDetected(){
	return this->time_detected;
}
int MySwarm::getTimeDetectedInTime(){
	return time_detectedInTime;
}
int MySwarm::getTimeDetectedError(){
	return this->time_detectedError;
}
template < class T >
void MySwarm::ClearVector( vector< T >& vt ) 
{		
	vt.clear();
	vt.shrink_to_fit();
}