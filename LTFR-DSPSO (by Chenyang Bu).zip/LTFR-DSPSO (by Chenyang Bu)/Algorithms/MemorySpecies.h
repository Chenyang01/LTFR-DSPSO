#pragma once
#ifndef MemorySpecies_h
#define MemorySpecies_h
#include "PSOAgent.h"
#include "../stdafx.h"
using namespace std;
class PSOAgent;
class MemorySpecies
{
public:
	vector<PSOAgent> memlist;
	int num;
	MemorySpecies(void);
	~MemorySpecies(void);
};
#endif