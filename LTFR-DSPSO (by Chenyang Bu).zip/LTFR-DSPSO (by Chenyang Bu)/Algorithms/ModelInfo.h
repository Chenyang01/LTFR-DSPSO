#pragma once
#ifndef ModelInfo_h
#define ModelInfo_h
#include "../Problems\DOPs\MovingPeak.h"
#include "../Problems\DOPs\RotationDBG.h"
#include "../stdafx.h"
using namespace std;


#define DELTA 1.0e-12
#define DELTA_1 1.0e12

typedef struct 
{
	int NEval;
	double error;
}Record;
class ModelInfo
{
public:
	/****problem information*****/
	MovingPeak * mpb;//objective function of moving peaks benchmark
#ifdef MFRB_C
	RotationDBG *mfrb;//constraint function of moving feasible regions benchmark
#else
	MovingPeak * mfrb;//the MPB adopted as constraint function 
#endif
	int n_var;		//number of variables
	int n_con;		//number of constraints
	int Inequalities; /* number of inequalities */
	int Equalities;		/* number of equalities */
	//int nzc;		//number of nonlinear constraints
	int NEval;//count the number of function evalutions
	int NConst;//number of feasibility checkings
	int NGradient;//count the number of calls for gradient
	int changeStep;//current time period
	int gen;//generation
	int NEvalEveryPeroid;//number of function evalutions per change
	int Problem;	//the identifier of tested problems
	double S;//determines the severity of constraint changes
	double k;//determines the change severity of objetive function of G24
	int maxNumVar;//in case the number of variables changes
	double val_1;//parameter of G24-2-1 or G24-2-2
	double val_2;//parameter of G24-2-2
	double val_3;//parameter of G24-2-2
	double globalValue;	//the acutual global value
	double delta_t;//delta(t), the constaint parameter of MFRB, appeared in Eq. 16
	int runID;//the index of runs	
	bool informedChange;//the value would be true if there is a real change 
	bool has_change;
	int maxChangeNum;
	//ThanhNT added 08 July 09
	//In my experiment I need a measure to decide how many individuals is in a certain disconnected feasible region.
	//In order to implement that, I need to create a vector<pair<double,bool>> _segmentPivotPoints 
		//to store the segments of each disconnected region
	//The first element is the coordination of the segment point, 
		//and the second is to decide whether that segment point really divide the 
		//landscape into disconnected regions.
	//The segment pivot points are (0,0) - (1,0) - (2,0) - (3,0). In the case of G24 the pivot
	//points always lie on the x axis.
	vector<pair<double,bool>> _segmentPivotPoints; 
	int _disconnectedFeasibleRegionsNum;
	//end of ThanhNT
	//ThanhNT added 06 Nov 08
	//due to the nature of G24, the position of the dynamic global optimum switch from one moving local optimum to another. As a result,
	//we can store a list of moving local optima and then calculate where the global optimum is in
	vector<vector<double> > _listOfOptima;
	//end of ThanhNT
	vector<double> _staticGlobalOptimum; 
	vector<double> globalOptimum;
	
	/*****measure*****/
	int NumALS;
	int NEvalALS;
	int NumRepair;
	int NConstRepair;
	int NumCoverALS;
	vector<int> numALSInEachRegion;
	int TotalNumOfRegions;

	double trackingError;
	double offline_error;
	double mean_offline_error;
	double bestError;	
	double meanDis;
	double bestFitPerPeriod;
	double ARR;//absoulte recover rate per period
	double ARR_all;
	double RegionCover;
	int numGenInfeasible;
	double peak_found;
	bool found_globalRegion;
	double trackingSpeed_globalRegion;
	int gen_in_a_period;	
	vector<int> numIndEachRegion;
	/*****measure end*****/

	double *LUrhs;	//lower and upper bounds of constraints
	double *LUv;		//lower and upper bounds of variables
	//int ** has_x;
	double * maxVelocity;
	double * minVelocity;	
	double* loc_bestPoint;
	
	double* c_bestPoint;
	char* output;// the file name for output
	

	
	double abound;              //artificial bound for unbounded variables
	double Infinity;            //largest number
	double negInfinity;         //most negative number	

	/*****record the information related to best found particle*****/
	double fit_bestPoint;
	bool fea_bestPoint;
	double Sumvio_bestPoint;
	int tempNEval_bestPoint;
	int tempNConst_bestPoint;
	int tempGen_bestPoint;
	/*****record the information related to best found particle*****/
	
	void testOutput();
	void updateMeasure();
	void resetParameters();
	ofstream ofProInfo;
	ofstream ofMFRBInfo;
	
	deque<Record> errorInfo;
	ofstream ofErrorInfo;

public:
	ModelInfo(int Pro,int run,int dim,double S0,double k0,int NumEvalEveryPeriod,int _maxChangeNum);
	ModelInfo(ChangeType mpb_ChangeType,ChangeType mfrb_ChangeType,int Pro,int run,int dim,double S0,double k0,int NumEvalEveryPeriod,int numRegions,int numPeaks,int rtimes_con=4,int rtimes_len=2,float changingRatio_peak=1.0,float changingRatio_region=1.0,bool FlagNumRegionsChange=false,bool FlagNumPeakChange=false,bool FlagDimChange=false,const Encoding rEncoding=C_UNSER_DEFINED);
	ModelInfo(const ModelInfo& tempM); // copy constructor
	ModelInfo& operator=(const ModelInfo &P);	//assignment operator
	double getBound();          //return artificial bound value
	double getInfty();          //return infinity value
	double getNegInfty();       //return -infinity value
	double getRandomDoubleFrom0To1();
	int getRandomInt(int num);
	double getBestFitInActual();
	int getMaxStep();
	void setMaxStep(int num);
	
	double p_i(int index);
	double q_i(int index);
	double r_i(int index);
	double s_i(int index);
	double X(int index,double*x);
	double Y(int index,double*x);
	void updateNumVar();
	double calculateDis(double *x1,double*x2);
	double calculateDis(vector<double> x1,double *x2);
	void EvaluateF(double*x,double& fitness);
	double dummyEvaluateF(double*x);
	double dummyEvaluateF(vector<double> x);
	void EvaluateC(double*x,double * c);
	void EvaluateNabla(double*x,double*c,double**nabla);
	bool IsInRegion(double*x,int regionID);
	bool dummyIsFeasible(double *x);
	bool dummyIsFeasible(vector<double> x);
	void ConstraintViolation(double*x,double *c,double*v,double& SumVio,double& MaxVio,bool& feasible);
	void OpenOutputFile(int value);
	void calculateDynamicGlobalOptimum();
	void SetLUv();	
	void updateBest(double fitness, bool isfea, double * loc, double vio);
	void setOfflineError();	
	//ThanhNT added 08 July 09
	//We need to define the following method to update whether the landscape has one/two or three 
	//disconnected feasible regions.
	//- this will be called after every change and at the initial stage. 
	void updateSegmentPivotPoints();
		//end of ThanhNT
	
	~ModelInfo(void);
};
#endif