#include "../stdafx.h"
#include "ModelInfo.h"

#define Delta 0.0001
#define pi PI
#define c1 1.470561702
#define c2 3.442094786232
#define ra 0.858958496
#define  m1 0.611603206382
#define m2 1.637497
#define m3 2.32952019747762
#define n1 3.442094786232
#define n2 2.712499
#define n3 3.17849307411774
#define w PI/2

//parameter: 
//        Pro - the problem number
//        run - identifier of the fun
//        S0, k0 - parameter related to benchmark problems
//        NumEvalEveryPeriod - the number of function evaluations for each period
//        _maxChangeNum - the maximum number of changes
ModelInfo::ModelInfo(int Pro,int run,int dim,double S0,double k0,int NumEvalEveryPeriod, int _maxChangeNum){
#ifdef DEBUG
	cout<<"ModelInfo constructor"<<endl;
#endif
	/****problem information*****/	
	this->NEvalEveryPeroid=NumEvalEveryPeriod;
	this->maxChangeNum=_maxChangeNum;	
	NEval=0;
	NConst=0;
	NGradient=0;
	this->gen=0;
	this->changeStep=0;	
	this->Problem=Pro;
	this->S=S0;
	this->k=k0;	
	this->val_1=0.0;
	this->val_2=0.0;
	this->val_3=0.0;		
	this->runID=run;
	this->informedChange=false;	
	this->has_change=false;	
	this->_disconnectedFeasibleRegionsNum=0;		
	this->globalValue=0.0;
	/****problem information end*****/

	/*****measure*****/
#ifndef G24
	this->numIndEachRegion.resize(50);
#endif
	this->NumALS=0;
	this->NEvalALS=0;
	this->NumRepair=0;
	this->NConstRepair=0;
	this->NumCoverALS=0;
#ifdef G24
	this->numALSInEachRegion.resize(4);
	for(int i=0;i<4;i++){
		this->numALSInEachRegion[i]=0;
	}
#else
	this->numALSInEachRegion.resize(50);
	for(int i=0;i<50;i++){
		this->numALSInEachRegion[i]=0;
	}
#endif
	this->TotalNumOfRegions=0;
	this->bestError=0.0;	
	this->bestFitPerPeriod=0.;	
	this->numGenInfeasible=0;
	this->meanDis=0.;
	this->numGenInfeasible=0;
	this->trackingSpeed_globalRegion=0.;
	this->RegionCover=0.;	
	this->ARR=0.;
	this->ARR_all=0.;
	this->trackingError=0.0;
	this->peak_found=0;
	this->mean_offline_error=0.0;
	this->offline_error=0.0;	
	this->gen_in_a_period=0;


	this->tempGen_bestPoint=0;
	this->found_globalRegion=false;	
	//has_x=NULL;
	abound=10000;                           //artificial bound 10^4
	Infinity=DBL_MAX;                       //infinity
	negInfinity=-Infinity;



	char str[200];
#ifdef TestMFRB
	sprintf(str,"data\\MFRB_Info_%d_run_%d.txt",this->Problem,this->runID);
	this->ofMFRBInfo.open(str,ofstream::out|ofstream::app);
#endif
#ifdef ProInfo
	sprintf(str,"data\\GlobalInfo_Pro_%d_run_%d.txt",this->Problem,this->runID);

	this->ofProInfo.open(str,ofstream::out|ofstream::app);
#endif
	if((this->Problem>=1&&this->Problem<=18)||(this->Problem>=3001&&this->Problem<=8003)){
		//ThanhNT added 08 July 09
		//In my experiment I need a measure to decide how many individuals is in a certain disconnected feasible region.
		//In order to implement that, I need to create a vector<pair<double,bool>> _segmentPivotPoints 
		//to store the segments of each disconnected region
		//The first element is the coordination of the segment point, 
		//and the second is a boolean value to decide whether that segment point really divide the 
		//landscape into disconnected regions.
		//The segment pivot points are (0,0) - (1,0) - (2,0) - (3,0). In the case of G24 the pivot
		//points always lie on the x axis.
		_segmentPivotPoints.resize(4);
		//pair<double, bool> myPair;
		_segmentPivotPoints[0].first=0.0; //the x coord is 0
		_segmentPivotPoints[0].second=true; //the first point is the search boundary, hence the value is always true
		_segmentPivotPoints[1].first=1.0; //the x coord is 1.0
		_segmentPivotPoints[1].second=true; //the second point by default is always a segment point
		_segmentPivotPoints[2].first=2.0; //the x coord is 2.0
		_segmentPivotPoints[2].second=true; //the third point by default is not a segment point
		_segmentPivotPoints[3].first=3.0; //the x coord is 3.0
		_segmentPivotPoints[3].second=true; //the final point is the search boundary, hence the value is always true	

		//end of ThanhNT
	}
	//set the number of variables
	if(this->Problem>=1&&this->Problem<=18){
		n_var=2;// for the unimodal dynamic continuous constrained optimization benchmark problems
		maxNumVar=2;
	}
	else if(this->Problem<=8003&&this->Problem>=3001){
		n_var=2;
		maxNumVar=2;
	}	
	else if(this->Problem>=10000){

		this->n_var=dim;
		this->maxNumVar=dim;
		this->mpb=MovingPeak::getMPs();
		//
#ifdef MFRB_C
		this->mfrb=RotationDBG::getMFRs();
#else
		this->mfrb=MovingPeak::getMFRs();		
#endif
		this->delta_t=this->mfrb->get_delta_t();
	}
	else{
		cout<<"wrong Problem Number!!"<<endl;
		n_var=2;
		maxNumVar=2;
		system("pause");
		exit(0);
	} 

	maxVelocity=new double[maxNumVar];
	minVelocity=new double[maxNumVar];	
	LUv=new double[maxNumVar*2];//lower and upper bounds of variables
	this->SetLUv();
	this->loc_bestPoint=new double[maxNumVar];//location of current best individual
	for(int i=0;i<maxNumVar;i++){
		loc_bestPoint[i]=0.0;
	}
#ifdef G24
	this->fit_bestPoint=2.5;//this->getInfty();
#else
	this->fit_bestPoint=0;
#endif
	this->fea_bestPoint=false;
	this->tempNEval_bestPoint=0;
	this->tempNConst_bestPoint=0;
	this->Sumvio_bestPoint=this->getInfty();


	//set the number of constraints (i.e. n_con)
	// n_con : total number of constraints
	// Inequalities : number of inequality constraints
	// Equalities : number of equality constraints
	if(this->Problem==1||this->Problem==4||this->Problem==6||this->Problem==17){
		n_con=0;
		this->Inequalities=0;
		this->Equalities=0;
	}
	else if(this->Problem==13){
		n_con=1;
		this->Inequalities=1;
		this->Equalities=0;
	}
	else if(this->Problem<=18&&this->Problem>=1){
		n_con=2;
		this->Inequalities=2;
		this->Equalities=0;
	}
	else if(this->Problem<=8003&&this->Problem>=3001&&this->Problem%1000==1){
		n_con=3;
		this->Inequalities=3;
		this->Equalities=0;
	}else if(this->Problem<=8003&&this->Problem>=3001&&this->Problem%1000==3){
		n_con=4;
		this->Inequalities=4;
		this->Equalities=0;
	}else if(this->Problem>=10000){
		n_con=1;
		this->Inequalities=1;
		this->Equalities=0;
	}


	this->output=new char[35];	
	int i=0;
	sprintf(output,"data\\function_%d_run_%d.txt",this->Problem,this->runID);
	int j;
	if(n_con>0){
		//hax_x: indicate that for each constraint which variables are included
		//define for constraint consensus method, which is a constraint handling strategy
		//has_x=new int*[n_con];
		//lower and upper bounds of constraints
		LUrhs=new double[n_con*2];
		//for(i=0;i<n_con;i++){
			//has_x[i]=new int[n_var];
		//}
		/*for(i=0;i<n_con;i++){
			for(j=0;j<n_var;j++)
			{
				has_x[i][j]=1;
			}
		}*/
		for(i=0;i<n_con;i++){
			LUrhs[2*i]=negInfinity;
			LUrhs[2*i+1]=0;
		}
		this->c_bestPoint=new double[n_con];
		for(i=0;i<n_con;i++)
			this->c_bestPoint[i]=0.0;
	}
	this->_listOfOptima.resize(2);
	_listOfOptima[0].resize(2);
	_listOfOptima[1].resize(2);
	//hard code the known global optimum 1
	_listOfOptima[0][0]=2.32952019747762;
	_listOfOptima[0][1]=3.17849307411774;

	//hard code the known global optimum 2
	//x[0]=0.611603206382;		 x[1]=3.442094786232; 
	_listOfOptima[1][0]=0.611603206382;
	_listOfOptima[1][1]=3.442094786232;
	if(this->Problem==11||(this->Problem>=5001&&this->Problem<=5100))
	{
		vector<double> globalOpt(2);
		//manually hard code the global optimum at change 15, small severity case:
		globalOpt[0]=2.686184820801;    
		globalOpt[1]=0.000000428893;
		//global opt value for the above optimum: -1.899419502309
		_listOfOptima.push_back(globalOpt);

		//manually hard code the global optimum at change 9, medium severity case:
		globalOpt[0]=2.606240766744;
		globalOpt[1]=0.000083603741;
		//global opt value for the above optimum: -2.606240766744
		_listOfOptima.push_back(globalOpt);

		//manually hard code the global optimum at change 5, large severity case:
		globalOpt[0]=2.606254442428;
		globalOpt[1]=0.000000000000;
		//global opt value for the above optimum: -2.606254442428	
		_listOfOptima.push_back(globalOpt);
	}else if(this->Problem>=12 && this->Problem<=15){
		//hard code the known global optimum 1	
		_listOfOptima[0][0]=3;
		_listOfOptima[0][1]=1;

		//hard code the known global optimum 2

		_listOfOptima[1][0]=0;
		_listOfOptima[1][1]=3;
	}

#ifdef DEBUG
	cout<<"ModelInfo constructor end"<<endl;
#endif

};

//not used
ModelInfo::ModelInfo(ChangeType mpb_ChangeType,ChangeType mfrb_ChangeType,int Pro,int run,int dim,double S0,double k0,int NumEvalEveryPeriod,int numRegions,int numPeaks,int rtimes_con,int rtimes_len,float changingRatio_region,float changingRatio_peak,bool FlagNumRegionsChange,bool FlagNumPeakChange,bool FlagDimChange,const Encoding rEncoding){
#ifdef DEBUG
	cout<<"ModelInfo constructor"<<endl;
#endif
	this->trackingError=0.0;
	this->bestError=0.0;
	this->val_1=0.0;
	this->meanDis=0.0;
	this->peak_found=0;
	this->numGenInfeasible=0;
	this->bestFitPerPeriod=0.0;
	this->val_2=0.0;
	this->ARR=0.;
	this->found_globalRegion=false;
	this->trackingSpeed_globalRegion=0.;
	this->RegionCover=0.;
	this->ARR_all=0.0;
	this->val_3=0.0;
	this->tempGen_bestPoint=0;
	this->runID=run;

	//parameter: control the maximum repeated times of a local search (use sqp)

	this->_disconnectedFeasibleRegionsNum=0;
	this->mean_offline_error=0.0;	
	this->offline_error=0.0;
	this->Problem=Pro;
	this->S=S0;
	this->k=k0;
	this->gen_in_a_period=0;
	//has_x=NULL;
	abound=10000;                           //artificial bound 10^4
	Infinity=DBL_MAX;                       //infinity
	negInfinity=-Infinity;
	this->NEvalEveryPeroid=NumEvalEveryPeriod;
	NEval=0;
	NConst=0;
	NGradient=0;
	this->gen=0;
	this->has_change=false;
	this->informedChange=false;
	this->changeStep=0;

	char str[200];
#ifdef TestMFRB
	sprintf(str,"data\\MFRB_Info_%d_run_%d.txt",this->Problem,this->runID);
	this->ofMFRBInfo.open(str,ofstream::out|ofstream::app);
#endif

#ifdef ProInfo
	sprintf(str,"data\\GlobalInfo_Pro_%d_run_%d.txt",this->Problem,this->runID);
	this->ofProInfo.open(str,ofstream::out|ofstream::app);
#endif
	if((this->Problem>=1&&this->Problem<=18)||(this->Problem>=3001&&this->Problem<=8003)){
		//ThanhNT added 08 July 09
		//In my experiment I need a measure to decide how many individuals is in a certain disconnected feasible region.
		//In order to implement that, I need to create a vector<pair<double,bool>> _segmentPivotPoints 
		//to store the segments of each disconnected region
		//The first element is the coordination of the segment point, 
		//and the second is a boolean value to decide whether that segment point really divide the 
		//landscape into disconnected regions.
		//The segment pivot points are (0,0) - (1,0) - (2,0) - (3,0). In the case of G24 the pivot
		//points always lie on the x axis.
		_segmentPivotPoints.resize(4);
		//pair<double, bool> myPair;
		_segmentPivotPoints[0].first=0.0; //the x coord is 0
		_segmentPivotPoints[0].second=true; //the first point is the search boundary, hence the value is always true
		_segmentPivotPoints[1].first=1.0; //the x coord is 1.0
		_segmentPivotPoints[1].second=true; //the second point by default is always a segment point
		_segmentPivotPoints[2].first=2.0; //the x coord is 2.0
		_segmentPivotPoints[2].second=true; //the third point by default is not a segment point
		_segmentPivotPoints[3].first=3.0; //the x coord is 3.0
		_segmentPivotPoints[3].second=true; //the final point is the search boundary, hence the value is always true	

		//end of ThanhNT
	}
	//set the number of variables
	if(this->Problem>=1&&this->Problem<=18){
		n_var=2;// for the unimodal dynamic continuous constrained optimization benchmark problems
		maxNumVar=2;
	}
	else if(this->Problem<=8003&&this->Problem>=3001){
		n_var=2;
		maxNumVar=2;
	}
	else if(this->Problem==101){
		n_var=13;
		maxNumVar=13;
	}
	else if(this->Problem==21||this->Problem==22){
		this->n_var=dim;
		this->maxNumVar=dim;

	}
	//moving feasible regions benchmark
	else if(this->Problem>=10000){
		this->n_var=dim;
		this->maxNumVar=dim;
		this->mpb=MovingPeak::getMPs();
#ifdef MFRB_C
		this->mfrb=RotationDBG::getMFRs();		
#else
		this->mfrb=MovingPeak::getMFRs();		
#endif
		this->delta_t=this->mfrb->get_delta_t();		
	}
	else{
		cout<<"wrong Problem Number!!"<<endl;
		n_var=2;
		maxNumVar=2;
		system("pause");
		exit(0);
	} 

	maxVelocity=new double[maxNumVar];
	minVelocity=new double[maxNumVar];
	//lower and upper bounds of variables
	LUv=new double[maxNumVar*2];
	this->SetLUv();
	//set values of current best individual
	this->loc_bestPoint=new double[maxNumVar];
	for(int i=0;i<maxNumVar;i++){
		loc_bestPoint[i]=0.0;
	}

#ifdef G24
	this->fit_bestPoint=2.5;//this->getInfty();
#else
	this->fit_bestPoint=0;
#endif
	this->fea_bestPoint=false;
	this->tempNEval_bestPoint=0;
	this->tempNConst_bestPoint=0;
	this->Sumvio_bestPoint=this->getInfty();

	//set the number of constraints 
	// n_con : total number 
	// Inequalities : number of inequality constraints
	// Equalities : number of equality constraints
	if(this->Problem==1||this->Problem==4||this->Problem==6||this->Problem==17){
		n_con=0;
		this->Inequalities=0;
		this->Equalities=0;
	}
	else if(this->Problem==13){
		n_con=1;
		this->Inequalities=1;
		this->Equalities=0;
	}
	else if(this->Problem<=18&&this->Problem>=1){
		n_con=2;
		this->Inequalities=2;
		this->Equalities=0;
	}
	else if(this->Problem<=8003&&this->Problem>=3001){
		n_con=4;
		this->Inequalities=4;
		this->Equalities=0;
	}else if(this->Problem>=10000){
		n_con=1;
		this->Inequalities=n_con;
		this->Equalities=0;
	}

	this->output=new char[35];	
	int i=0;
	sprintf(output,"data\\function_%d_run_%d.txt",this->Problem,this->runID);
	int j;
	if(n_con>0){
		//hax_x: indicate that for each constraint which variables are included
		//define for constraint consensus method, which is a constraint handling strategy
		//has_x=new int*[n_con];
		//lower and upper bounds of constraints
		LUrhs=new double[n_con*2];
		/*for(i=0;i<n_con;i++){
			has_x[i]=new int[n_var];
		}
		for(i=0;i<n_con;i++){
			for(j=0;j<n_var;j++)
			{
				has_x[i][j]=1;
			}
		}*/
		for(i=0;i<n_con;i++){
			LUrhs[2*i]=negInfinity;
			LUrhs[2*i+1]=0;
		}
		this->c_bestPoint=new double[n_con];
		for(i=0;i<n_con;i++)
			this->c_bestPoint[i]=0.0;
	}
	this->_listOfOptima.resize(2);
	_listOfOptima[0].resize(2);
	_listOfOptima[1].resize(2);
	//hard code the known global optimum 1
	_listOfOptima[0][0]=2.32952019747762;
	_listOfOptima[0][1]=3.17849307411774;

	//hard code the known global optimum 2
	//x[0]=0.611603206382;		 x[1]=3.442094786232; 
	_listOfOptima[1][0]=0.611603206382;
	_listOfOptima[1][1]=3.442094786232;
	if(this->Problem==5||(this->Problem>=5001&&this->Problem<=5100))
	{
		vector<double> globalOpt(2);
		//manually hard code the global optimum at change 15, small severity case:
		globalOpt[0]=2.686184820801;    
		globalOpt[1]=0.000000428893;
		//global opt value for the above optimum: -1.899419502309
		_listOfOptima.push_back(globalOpt);

		//manually hard code the global optimum at change 9, medium severity case:
		globalOpt[0]=2.606240766744;
		globalOpt[1]=0.000083603741;
		//global opt value for the above optimum: -2.606240766744
		_listOfOptima.push_back(globalOpt);

		//manually hard code the global optimum at change 5, large severity case:
		globalOpt[0]=2.606254442428;
		globalOpt[1]=0.000000000000;
		//global opt value for the above optimum: -2.606254442428	
		_listOfOptima.push_back(globalOpt);
		globalOpt.shrink_to_fit();
	}
	this->globalValue=0.0;
#ifdef DEBUG
	cout<<"ModelInfo constructor end"<<endl;
#endif

};

ModelInfo::ModelInfo(const ModelInfo& tempM){
	/****problem information*****/
	this->mpb=tempM.mpb;
	this->mfrb=tempM.mfrb;
	n_var=tempM.n_var;// for the unimodal dynamic continuous constrained optimization benchmark problems
	this->n_con=tempM.n_con;
	this->Inequalities=tempM.Inequalities;
	this->Equalities=tempM.Equalities;
	NEval=tempM.NEval;
	NConst=tempM.NConst;
	NGradient=tempM.NGradient;
	this->changeStep=tempM.changeStep;
	gen=tempM.gen;
	this->NEvalEveryPeroid=tempM.NEvalEveryPeroid;
	this->Problem=tempM.Problem;	
	this->S=tempM.S;
	this->k=tempM.k;
	this->maxNumVar=tempM.maxNumVar;
	this->val_1=tempM.val_1;
	this->val_2=tempM.val_2;
	this->val_3=tempM.val_3;
	this->globalValue=tempM.globalValue;
	this->delta_t=tempM.delta_t;
	this->runID=tempM.runID;
	this->has_change=tempM.has_change;
	this->informedChange=tempM.informedChange;	
	this->maxChangeNum=tempM.maxChangeNum;	
	if((this->Problem>=1&&this->Problem<=18)||(this->Problem>=3001&&this->Problem<=8003)){
		this->_segmentPivotPoints.resize(4);
		this->_segmentPivotPoints=tempM._segmentPivotPoints;

	}	
	this->_disconnectedFeasibleRegionsNum=tempM._disconnectedFeasibleRegionsNum;	
	this->_listOfOptima=tempM._listOfOptima;
	this->_staticGlobalOptimum=tempM._staticGlobalOptimum;
	this->globalOptimum=tempM.globalOptimum;
	/****problem information end*****/
	/*****measure*****/
	this->NumALS=tempM.NumALS;
	this->NEvalALS=tempM.NEvalALS;
	this->NumRepair=tempM.NumRepair;
	this->NConstRepair=tempM.NConstRepair;
	this->NumCoverALS=tempM.NumCoverALS;
#ifdef G24
	this->numALSInEachRegion.resize(4);
	for(int i=0;i<4;i++){
		this->numALSInEachRegion[i]=0;
	}
#else
	this->numALSInEachRegion.resize(50);
	for(int i=0;i<50;i++){
		this->numALSInEachRegion[i]=0;
	}
#endif
	this->numALSInEachRegion=tempM.numALSInEachRegion;
	this->TotalNumOfRegions=tempM.TotalNumOfRegions;
	this->trackingError=tempM.trackingError;
	this->offline_error=tempM.offline_error;
	this->mean_offline_error=tempM.mean_offline_error;
	this->bestError=tempM.bestError;
	this->meanDis=tempM.meanDis;
	this->bestFitPerPeriod=tempM.bestFitPerPeriod;		
	this->ARR=tempM.ARR;
	this->ARR_all=tempM.ARR_all;
	this->RegionCover=tempM.RegionCover;
	this->numGenInfeasible=tempM.numGenInfeasible;
	this->peak_found=tempM.peak_found;	
	this->found_globalRegion=tempM.found_globalRegion;
	this->trackingSpeed_globalRegion=tempM.trackingSpeed_globalRegion;	
	this->gen_in_a_period=tempM.gen_in_a_period;
	this->errorInfo=tempM.errorInfo;
	this->numIndEachRegion=tempM.numIndEachRegion;
	/*****measure end*****/

	abound=tempM.abound;                           //artificial bound 10^4
	Infinity=tempM.Infinity;                       //infinity
	negInfinity=tempM.negInfinity;

	char str[200];
#ifdef TestMFRB
	sprintf(str,"data\\MFRB_Info_%d_run_%d.txt",this->Problem,this->runID);
	this->ofMFRBInfo.open(str,ofstream::out|ofstream::app);
#endif
#ifdef ProInfo
	sprintf(str,"data\\GlobalInfo_Pro_%d_run_%d.txt",this->Problem,this->runID);

	this->ofProInfo.open(str,ofstream::out|ofstream::app);
#endif
	/*****record the information related to best found particle*****/	
	this->fit_bestPoint=tempM.fit_bestPoint;
	this->fea_bestPoint=tempM.fea_bestPoint;
	this->Sumvio_bestPoint=tempM.Sumvio_bestPoint;
	this->tempNEval_bestPoint=tempM.tempNEval_bestPoint;
	this->tempNConst_bestPoint=tempM.tempNConst_bestPoint;	
	this->tempGen_bestPoint=tempM.tempGen_bestPoint;
	/*****record the information related to best found particle end*****/	


	//allocate memory
	this->output=new char[35];	
	LUv=new double[2*this->maxNumVar];
	maxVelocity=new double[this->maxNumVar];
	minVelocity=new double[this->maxNumVar];
	this->loc_bestPoint=new double[this->maxNumVar];

	if(n_con>0){
		//has_x=new int*[n_con];
		LUrhs=new double[n_con*2];
		/*for(int i=0;i<n_con;i++){
			has_x[i]=new int[n_var];
		}*/
		this->c_bestPoint=new double[n_con];
	}

	int i=0;
	strcpy(this->output,tempM.output);		
	for(i=0;i<2*this->n_var;i++){
		this->LUv[i]=tempM.LUv[i];
	}
	if(this->maxNumVar!=this->n_var){
		for(;i<this->maxNumVar*2;i++){
			this->LUv[i]=0.0;
		}
	}	
	for(i=0;i<n_var;i++){
		loc_bestPoint[i]=tempM.loc_bestPoint[i];

	}

	if(this->maxNumVar!=this->n_var){
		for(;i<this->maxNumVar;i++){
			this->loc_bestPoint[i]=0.0;

		}
	}

	for(i=0;i<n_var;i++){
		maxVelocity[i]=tempM.maxVelocity[i];
		minVelocity[i]=tempM.minVelocity[i];
	}
	if(this->n_var!=this->maxNumVar){
		for(;i<this->maxNumVar;i++){
			this->maxVelocity[i]=0.0;
			this->minVelocity[i]=0.0;
		}
	}

	int j;
	if(n_con>0){		
		/*for(i=0;i<n_con;i++){
			for(j=0;j<n_var;j++)
			{
				has_x[i][j]=1;
			}
		}*/
		for(i=0;i<n_con;i++){
			LUrhs[2*i]=negInfinity;
			LUrhs[2*i+1]=0;
		}

		for(int i=0;i<n_con;i++){
			this->c_bestPoint[i]=tempM.c_bestPoint[i];
		}

	}

}
ModelInfo& ModelInfo::operator=(const ModelInfo &tempM){
	if(this!=&tempM){		
		/****problem information*****/
		this->mpb=tempM.mpb;
		this->mfrb=tempM.mfrb;
		n_var=tempM.n_var;// for the unimodal dynamic continuous constrained optimization benchmark problems
		this->n_con=tempM.n_con;
		this->Inequalities=tempM.Inequalities;
		this->Equalities=tempM.Equalities;
		NEval=tempM.NEval;
		NConst=tempM.NConst;
		NGradient=tempM.NGradient;
		this->changeStep=tempM.changeStep;
		gen=tempM.gen;
		this->NEvalEveryPeroid=tempM.NEvalEveryPeroid;
		this->Problem=tempM.Problem;	
		this->S=tempM.S;
		this->k=tempM.k;
		this->maxNumVar=tempM.maxNumVar;
		this->val_1=tempM.val_1;
		this->val_2=tempM.val_2;
		this->val_3=tempM.val_3;
		this->globalValue=tempM.globalValue;
		this->delta_t=tempM.delta_t;
		this->runID=tempM.runID;
		this->has_change=tempM.has_change;
		this->informedChange=tempM.informedChange;	
		this->maxChangeNum=tempM.maxChangeNum;	
		if((this->Problem>=1&&this->Problem<=18)||(this->Problem>=3001&&this->Problem<=8003)){
			this->_segmentPivotPoints.resize(4);
			this->_segmentPivotPoints=tempM._segmentPivotPoints;

		}	
		this->_disconnectedFeasibleRegionsNum=tempM._disconnectedFeasibleRegionsNum;	
		this->_listOfOptima=tempM._listOfOptima;
		this->_staticGlobalOptimum=tempM._staticGlobalOptimum;
		this->globalOptimum=tempM.globalOptimum;
		/****problem information end*****/
		/*****measure*****/
		this->NumALS=tempM.NumALS;
		this->NEvalALS=tempM.NEvalALS;
		this->NumRepair=tempM.NumRepair;
		this->NConstRepair=tempM.NConstRepair;
		this->NumCoverALS=tempM.NumCoverALS;
		this->numALSInEachRegion=tempM.numALSInEachRegion;
		this->TotalNumOfRegions=tempM.TotalNumOfRegions;
		this->trackingError=tempM.trackingError;
		this->offline_error=tempM.offline_error;
		this->mean_offline_error=tempM.mean_offline_error;
		this->bestError=tempM.bestError;
		this->meanDis=tempM.meanDis;
		this->bestFitPerPeriod=tempM.bestFitPerPeriod;		
		this->ARR=tempM.ARR;
		this->ARR_all=tempM.ARR_all;
		this->RegionCover=tempM.RegionCover;
		this->numGenInfeasible=tempM.numGenInfeasible;
		this->peak_found=tempM.peak_found;	
		this->found_globalRegion=tempM.found_globalRegion;
		this->trackingSpeed_globalRegion=tempM.trackingSpeed_globalRegion;	
		this->gen_in_a_period=tempM.gen_in_a_period;
		this->errorInfo=tempM.errorInfo;
		this->numIndEachRegion=tempM.numIndEachRegion;
		/*****measure end*****/





		//
		abound=tempM.abound;                           //artificial bound 10^4
		Infinity=tempM.Infinity;                       //infinity
		negInfinity=tempM.negInfinity;

		char str[200];
#ifdef TestMFRB
		sprintf(str,"data\\MFRB_Info_%d_run_%d.txt",this->Problem,this->runID);
		this->ofMFRBInfo.open(str,ofstream::out|ofstream::app);
#endif
#ifdef ProInfo
		this->ofProInfo.close();
		sprintf(str,"data\\GlobalInfo_Pro_%d_run_%d.txt",this->Problem,this->runID);

		this->ofProInfo.open(str,ofstream::out|ofstream::app);
#endif
		/*****record the information related to best found particle*****/	
		this->fit_bestPoint=tempM.fit_bestPoint;
		this->fea_bestPoint=tempM.fea_bestPoint;
		this->Sumvio_bestPoint=tempM.Sumvio_bestPoint;
		this->tempNEval_bestPoint=tempM.tempNEval_bestPoint;
		this->tempNConst_bestPoint=tempM.tempNConst_bestPoint;	
		this->tempGen_bestPoint=tempM.tempGen_bestPoint;
		/*****record the information related to best found particle end*****/	

		int i=0;
		strcpy(this->output,tempM.output);		
		for(i=0;i<2*this->n_var;i++){
			this->LUv[i]=tempM.LUv[i];
		}
		if(this->maxNumVar!=this->n_var){
			for(;i<this->maxNumVar*2;i++){
				this->LUv[i]=0.0;
			}
		}	
		for(i=0;i<n_var;i++){
			loc_bestPoint[i]=tempM.loc_bestPoint[i];

		}

		if(this->maxNumVar!=this->n_var){
			for(;i<this->maxNumVar;i++){
				this->loc_bestPoint[i]=0.0;

			}
		}

		for(i=0;i<n_var;i++){
			maxVelocity[i]=tempM.maxVelocity[i];
			minVelocity[i]=tempM.minVelocity[i];
		}
		if(this->n_var!=this->maxNumVar){
			for(;i<this->maxNumVar;i++){
				this->maxVelocity[i]=0.0;
				this->minVelocity[i]=0.0;
			}
		}

		int j;
		if(n_con>0){		
			/*for(i=0;i<n_con;i++){
				for(j=0;j<n_var;j++)
				{
					has_x[i][j]=1;
				}
			}*/
			for(i=0;i<n_con;i++){
				LUrhs[2*i]=negInfinity;
				LUrhs[2*i+1]=0;
			}

			for(int i=0;i<n_con;i++){
				this->c_bestPoint[i]=tempM.c_bestPoint[i];
			}

		}
	}

	return *this;

}

ModelInfo::~ModelInfo(void)
{
#ifdef DEBUG
	cout<<"~ModelInfo\n";
#endif
	this->trackingError=0.0;
	this->mean_offline_error=0.0;
	delete[] maxVelocity;
	maxVelocity=NULL;
	delete[] minVelocity;
	minVelocity=NULL;
	delete [] LUv;
	LUv=NULL;
	delete[]this->loc_bestPoint;	
	this->loc_bestPoint=NULL;



	if(n_con>0){
		delete [] LUrhs;
		LUrhs=NULL;
		/*for(int i=0;i<n_con;i++){
			delete[] has_x[i];
			has_x[i]=NULL;
		}*/
		//delete [] has_x;
		//has_x=NULL;
		delete[]this->c_bestPoint;
		this->c_bestPoint=NULL;
	}
	this->_segmentPivotPoints.clear();
	for(int i=0;i<this->_listOfOptima.size();i++){
		this->_listOfOptima[i].clear();
		this->_listOfOptima[i].shrink_to_fit();
	}
	this->_listOfOptima.clear();
	this->_staticGlobalOptimum.clear();
	this->globalOptimum.clear();
	this->numALSInEachRegion.clear();
	this->numALSInEachRegion.shrink_to_fit();
	this->_segmentPivotPoints.shrink_to_fit();
	this->_listOfOptima.shrink_to_fit();
	this->_staticGlobalOptimum.shrink_to_fit();
	this->globalOptimum.shrink_to_fit();
	this->numIndEachRegion.clear();
	this->numIndEachRegion.shrink_to_fit();
	delete []output;
	output=NULL;
#ifdef TestMFRB
	this->ofMFRBInfo.close();
#endif

#ifdef ProInfo
	this->ofProInfo.close();
#endif
}

double ModelInfo::getBound(){
	return rand();//abound	

};

double ModelInfo::getRandomDoubleFrom0To1(){
	//return (double)rand()/(double)RAND_MAX;	
	return Global::gp_uniformAlg->Next();
}

int ModelInfo::getRandomInt(int num){	
	//return (int)rand()%num;	
	return gRandInt(0,num);
}

double ModelInfo::getInfty(){
	return Infinity;
};

double ModelInfo::getNegInfty(){
	return negInfinity;
};

double ModelInfo::getBestFitInActual(){		
	return globalValue;
}

bool ModelInfo::IsInRegion(double*x,int regionID){

	if(this->Problem>=10000)
		return this->mfrb->isInRegion(x,regionID);
	else
		return false;//no use
}
double ModelInfo::calculateDis(double*x1,double*x2){
	double dis=0.0;
	for(int i=0;i<this->n_var;i++){
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	}
	return sqrt(dis);
}
void ModelInfo::calculateDynamicGlobalOptimum(){
	//cout<<this->NEval<<endl;
	if(this->Problem>=10000){
#define Test
#ifdef TestMFRB
		this->ofMFRBInfo<<"Period: "<<this->changeStep<<", "<<this->mpb->getChangeCounter()<<", "<<this->mfrb->getChangeCounter()<<endl;
		this->ofMFRBInfo<<"current peaks:\n";
		this->mpb->printPeaks(this->ofMFRBInfo);
		this->ofMFRBInfo<<"current regions:\n";
		this->mfrb->printPeaks(this->ofMFRBInfo);
		this->ofMFRBInfo<<"radius:\n";
		for(int i=0;i<this->mfrb->getNumberofPeak();i++){
			double radius=sqrt(((this->mfrb->getPeakHeight(i))/this->delta_t-1.0)/this->mfrb->getPeakWidth(i));
			this->ofMFRBInfo<<"radius "<<i<<": "<<radius<<endl;
		}
#endif		
		this->globalOptimum.clear();
		double min=100000,temp;
		int regionID=0;
		int numPeaks=this->mpb->getNumberofPeak();
		int numRegions=this->mfrb->getNumberofPeak();
		double * Z=new double[this->n_var];
		for(int i=0;i<numRegions;i++){
			for(int j=0;j<numPeaks;j++){
				double *x=const_cast<double *>(this->mpb->getPeak(j));
				if(this->IsInRegion(x,i)){//if the center of Peak j is in Region i
					temp=-1*this->mpb->getPeakHeight(j);
					if(temp<min){
						regionID=i;
						min=temp;
						this->globalOptimum.clear();
						for(int loop=0;loop<this->n_var;loop++)
							this->globalOptimum.push_back(this->mpb->getPeak(j)[loop]);
					}
				}else{//the center of Peak j is not in Region i
					/*calculate the nearest point in region i to the center of Peak j*/
					double disCenter=0.;					
					disCenter=this->calculateDis(const_cast<double *>(this->mpb->getPeak(j)),const_cast<double *>(this->mfrb->getPeak(i)));
#ifdef TestMFRB
					this->ofMFRBInfo<<"Peak:"<<j<<", Region: "<<i<<endl;
					//this->ofMFRBInfo<<"Peak:"<<endl;
					//this->mpb->printPeak(j);
					//this->ofMFRBInfo<<"Region:"<<endl;
					//this->mfrb->printPeak(i);
					this->ofMFRBInfo<<"disCenter: "<<disCenter<<endl;
#endif
#ifdef MFRB_C
					double radius=(this->mfrb->getPeakHeight(i)/this->delta_t-1.0)*sqrt((double)this->n_var)/this->mfrb->getPeakWidth(i);
#else
					double radius=sqrt(((this->mfrb->getPeakHeight(i))/this->delta_t-1.0)/this->mfrb->getPeakWidth(i));

#endif
					double par=radius/disCenter;
#ifdef TestMFRB
					this->ofMFRBInfo<<"radius: "<<radius<<", "<<"par: "<<par<<endl;
#endif		
					for(int loop=0;loop<this->n_var;loop++){
						Z[loop]=(1-par)*this->mfrb->getPeak(i)[loop]+par*(this->mpb->getPeak(j)[loop]);
#ifdef TestMFRB
						this->ofMFRBInfo<<"Z[loop]: "<<Z[loop]<<endl;
#endif
					}
					temp=this->dummyEvaluateF(Z);
#ifdef TestMFRB
					this->ofMFRBInfo<<"temp: "<<temp<<endl;
#endif
#undef Test
					if(temp<min){
						regionID=i;
						min=temp;
						this->globalOptimum.clear();
						for(int loop=0;loop<this->n_var;loop++)
							this->globalOptimum.push_back(Z[loop]);
					}

				}
			}
		}
		this->globalValue=min;
		this->mfrb->setGlobalRegion(regionID);
		delete[] Z;
		return;
	}	
	vector<double> globOpt(2);
	double tempValue, globOptValue;
	vector<double> tempVector(2);
	bool isDummy=true;
	int optNum=this->_listOfOptima.end()-this->_listOfOptima.begin();
	for(int i=0;i<2;i++){		
		globOpt[i]=this->_listOfOptima[0][i]/this->p_i(i+1)-this->q_i(i+1);		
	}
	if(this->dummyIsFeasible(globOpt)){
		globOptValue=this->dummyEvaluateF(globOpt);
	}else
		globOptValue=this->getInfty();

	for(int j=1;j<optNum;j++){
		for(int i=0;i<2;i++){
			tempVector[i]=this->_listOfOptima[j][i]/this->p_i(i+1)-this->q_i(i+1);			
		}
		if(this->dummyIsFeasible(tempVector)){
			tempValue=this->dummyEvaluateF(tempVector);
		}else
			tempValue=this->getInfty();
		if(tempValue<globOptValue){
			globOptValue=tempValue;
			globOpt=tempVector;
		}
	}

	//now select the best glob opt that could be brought by either the unconstrained objective function or the constraints
	for(int j=0;j<optNum;j++){
		for(int i=0;i<2;i++){
			tempVector[i]=this->_listOfOptima[j][i]/this->r_i(i+1)-this->s_i(i+1);			
		}
		if(this->dummyIsFeasible(tempVector)){
			tempValue=this->dummyEvaluateF(tempVector);
		}else
			tempValue=this->getInfty();
		if(tempValue<globOptValue){
			globOptValue=tempValue;
			globOpt=tempVector;
		}
	}

	//for some instances of G24, the global optimum can also be at one of the corners at some points
	//as a result it would be useful to check this here as well
	double x[4][2]; //coordinations at four corners
	x[0][0]=0; x[0][1]=0;
	x[1][0]=0; x[1][1]=4;//x[1]=0; y[1]=4;
	x[2][0]=3; x[2][1]=0;//x[2]=3; y[2]=0;
	x[3][0]=3; x[3][1]=4;//x[3]=3; y[3]=4;
	for (int i=0;i<4;i++)
	{
		if (this->dummyIsFeasible(x[i]))
		{
			tempValue=this->dummyEvaluateF(x[i]);
			if (tempValue<globOptValue)
			{
				globOptValue=tempValue;
				globOpt[0]=x[i][0];
				globOpt[1]=x[i][1];
			}
		}		
	}
	this->globalValue=globOptValue;
	this->globalOptimum=globOpt;
	globOpt.shrink_to_fit();
	tempVector.shrink_to_fit();

}
bool ModelInfo::dummyIsFeasible(std::vector<double> x){
	double* loc=new double[this->n_var];
	for(int i=0;i<this->n_var;i++){
		loc[i]=x[i];
	}
	bool flag=this->dummyIsFeasible(loc);
	delete[] loc;
	return flag;

}
int ModelInfo::getMaxStep(){
#ifdef TestOneStep
	return 1;
#endif
	return this->maxChangeNum;
}
void ModelInfo::setMaxStep(int num){
	this->maxChangeNum=num;
}
double ModelInfo::X(int index,double*x){	
	return p_i(index)*(x[index-1]+q_i(index));

}
double ModelInfo::Y(int index,double*x){
	//if(this->Problem>=1&&this->Problem<=19)
	//return r_i(index)*(x[index-1]+s_i(index));
	if(this->Problem==101)
		return x[index-1];
	else		
		return r_i(index)*(x[index-1]+s_i(index));
}
void ModelInfo:: EvaluateNabla(double*x,double*c,double**nabla){
#ifdef Test
	cout<<"EvaluateNabla\n";
#endif
	NGradient++;
	double* c_dash=new double[n_con];
	double xj;
	int i,j;

	for(j=0;j<n_var;j++){
		xj=x[j];
		x[j]+=DELTA;

		EvaluateC(x,c_dash);	
		this->NConstRepair++;
		x[j]=xj;
		for(i=0;i<n_con;i++){			
			nabla[i][j]=(c_dash[i]-c[i])*DELTA_1;			
		}

	}
	delete[] c_dash;
	c_dash=NULL;

#ifdef Test
	cout<<"EvaluateNabla end\n";
#endif

}
double ModelInfo::dummyEvaluateF(double*x){
	if(this->Problem>=10000)
		return -1.*this->mpb->dummyEval(x);
	double fitness=0.0;
	if((this->Problem<=16&&this->Problem>0)||(this->Problem<=8003&&this->Problem>=3001)){
		fitness=-1*(X(1,x)+X(2,x)); 
	}else if(this->Problem==17||this->Problem==18){
		double tmp1=X(1,x);
		double tmp2=X(2,x);
		fitness=-3*exp(-1*sqrt(sqrt(tmp1*tmp1+tmp2*tmp2)));
	}
	else{
		cout<<"Please input a correct problem number!\n";
		system("pause");
		exit(0);

	}
	return fitness;

}
double ModelInfo::dummyEvaluateF(std::vector<double> x){
	double* loc=new double[this->n_var];
	for(int i=0;i<this->n_var;i++){
		loc[i]=x[i];
	}
	double fitness=this->dummyEvaluateF(loc);
	delete[] loc;
	return fitness;
}
double ModelInfo::calculateDis(vector<double> x1,double *x2){
	double dis=0.0;
	for(int i=0;i<this->n_var;i++){
		dis+=(x1[i]-x2[i])*(x1[i]-x2[i]);
	}
	return sqrt(dis);
}
void ModelInfo::EvaluateF(double *x, double &fitness){
	NEval++;
	if(this->NEval>0&&NEvalEveryPeroid>0&&this->NEval%this->NEvalEveryPeroid==0){
		
		//update measures to analyze the performance
		if(this->NEval <= (this->getMaxStep()*this->NEvalEveryPeroid)){
			updateMeasure();		
		}
		this->changeStep++;
		//change the landscape of moving feasible regions benchmark
		if(this->Problem>=10000){			
			this->mfrb->mfr_change();			
			this->mpb->mpb_change();			
			this->delta_t=this->mfrb->get_delta_t();

		}			
		this->calculateDynamicGlobalOptimum();
		updateSegmentPivotPoints();
		resetParameters();

	}

	if(this->Problem>=10000){
		fitness=-1*this->mpb->evaluate(x);

		if(this->found_globalRegion==false&&this->mfrb->isInGlobalRegion(x)){
			this->found_globalRegion=true;
			this->trackingSpeed_globalRegion+=this->NEval%this->NEvalEveryPeroid;
		}
	}
	else if((this->Problem<=16&&this->Problem>0)||(this->Problem<=8003&&this->Problem>=3001)){
		fitness=-1*(X(1,x)+X(2,x)); 
	}else if(this->Problem==17||this->Problem==18){
		double tmp1=X(1,x);
		double tmp2=X(2,x);
		fitness=-3*exp(-1*sqrt(sqrt(tmp1*tmp1+tmp2*tmp2)));
	}else{
		cout<<"Please input a correct problem number!\n";
		system("pause");
		exit(0);

	}
#ifdef outputErrorInfo1
	if(NEval<=(this->getMaxStep()*this->NEvalEveryPeroid)){
		//update best error
		Record tmp;

		if(this->fea_bestPoint==true){
			if(this->globalValue>fit_bestPoint)
				tmp.error=0.0;
			else{
				tmp.error=fabs(this->globalValue-this->fit_bestPoint);				
			}
		}
		else{
			if(this->Problem>=10000){
				tmp.error=fabs(this->globalValue-0.0);				
			}
			else
				tmp.error=fabs(this->globalValue-2.5);
		}
		tmp.NEval=this->NEval;
		this->errorInfo.push_back(tmp);
	}
	if(this->NEval==(this->NEvalEveryPeroid*this->getMaxStep())){
		char str[200];
#ifdef G24
		sprintf(str,"data\\Error_Info_%d_run_%d.txt",this->Problem,this->runID);
#else
		sprintf(str,"data\\Error_Info_%d_run_%d_obj_%d.txt",this->Problem,this->runID,(int)this->mpb->getChangeType());
#endif
		this->ofErrorInfo.open(str,ofstream::out|ofstream::app);
		for(int i=0;i<this->errorInfo.size();i++){
			this->ofErrorInfo<<this->errorInfo[i].NEval<<"  "<<this->errorInfo[i].error<<endl;
		}
		this->ofErrorInfo.close();
	}
#endif

}
void ModelInfo::updateNumVar(){
	if(this->Problem==102){
		this->n_var=20+floor(20*fabs(sin((double)this->k*pi*(double)this->changeStep/2)));
	}
	else
		return;
}
bool ModelInfo::dummyIsFeasible(double*x){
	for(int i=0; i<n_var; i++){		//for each variable	
		if(x[i] < LUv[2*i]) {
			return false;
		}
		else if(x[i] > LUv[2*i+1]){
			return false;
		}
	}

	if(this->Problem>=10000){
		double conValue=this->mfrb->dummyEval(x);
		if(this->delta_t-conValue<=0)
			return true;
		else 
			return false;
	}
	if(this->n_con==0)
		return true;
	for(int i=0;i<this->n_var;i++){
		if(x[i]<this->LUv[2*i])
			return false;
		if(x[i]>this->LUv[2*i+1])
			return false;
	}
	double* c=new double[this->n_con];
	for(int i=0;i<this->n_con;i++){
		c[i]=0.0;
	}
	/****************evaulate the constraints*********************/
	double tmp1=Y(1,x),tmp2=Y(2,x);
	if(this->Problem>=1&&this->Problem<=18){

		if(this->Problem==12){	
			c[0]=2*tmp1+3*tmp2-9;
			if((0<=tmp1&&tmp1<=1&&2<=tmp2&&tmp2<=3)||(2<=tmp1&&tmp1<=3)){
				c[1]=-1;
			}else
				c[1]=1;

		}
		else if(this->Problem==13){
			c[0]=2*tmp1+3*tmp2-9;
		}
		else if(this->Problem==14){
			c[0]=2*tmp1+3*tmp2-9;
			if((0<=tmp1&&tmp1<=1)||(2<=tmp1&&tmp1<=3)){
				c[1]=-1;
			}else
				c[1]=1;
		}
		else if(this->Problem==15){
			if((0<=tmp1&&tmp1<=0.5)||(2.5<=tmp1&&tmp1<=3.0))
			{
				c[0]=-1;
			}else
				c[0]=1;
			/*if((0<=tmp1&&tmp1<=1&&2<=tmp2&&tmp2<=3)||(2<=tmp1&&tmp1<=3)){
			c[1]=-1;
			}else
			c[1]=1;*/
			c[1]=2*tmp1+3*tmp2-9;
		}
		else if(this->Problem==1||this->Problem==4||this->Problem==6||this->Problem==17){
			cout<<"The problem does not has a constraint!\n";
			//system("pause");
			//exit(0);

		}else{
			c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
			c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;
		}
	}else if(this->Problem>=3001&&this->Problem<=8003&&this->Problem%1000==1){//(this->Problem==3003||this->Problem==4003||this->Problem==5003||this->Problem==7003){
		c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
		c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;		
		c[2]=val_1-tmp2;
	}
	else if(this->Problem>=3001&&this->Problem<=8003&&this->Problem%1000==3){//(this->Problem==3003||this->Problem==4003||this->Problem==5003||this->Problem==7003){
		double val[3][2]={{m1,(n1-val_1)},{m2,(n2-val_2)},{m3,(n3-val_3)}};		
		c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
		c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;
		c[2]=(val[1][1]-val[0][1])/(val[1][0]-val[0][0])*(tmp1-val[0][0])+val[0][1]-tmp2;
		c[3]=(val[1][1]-val[2][1])/(val[1][0]-val[2][0])*(tmp1-val[2][0])+val[2][1]-tmp2;		
	}
	/****************evaulate the constraints end*********************/	

	/***************decide whether the point is feasible or not***************/
	int i=0;
	double e;	
	for(;i<this->Inequalities;i++){		
#ifdef G24
		if(c[i]>0.0001){
#else
		if(c[i]>0.00000001){
#endif
			delete[] c;
			c=NULL;
			return false;
		}

	}
	for(; i<this->n_con; i++) {
		e=(c[i]>=0? c[i] : -c[i]);		
		if(e>Delta){
			delete[] c;
			c=NULL;
			return false;
		}			
	}
	delete[] c;
	c=NULL;
	return true;
	/***************end decide whether the point is feasible or not***************/



}
void ModelInfo::EvaluateC(double *x, double *c){
	//if(this->NEval>(this->getMaxStep()*this->NEvalEveryPeroid))return;
	NConst++;
	//for(int i=0; i<n_var; i++){		//for each variable	
	//	if(x[i] < LUv[2*i]) {
	//		return false;
	//	}
	//	else if(x[i] > LUv[2*i+1]){
	//		return false;
	//	}
	//}
	if(this->Problem>=10000){
		c[0]=this->delta_t-this->mfrb->dummyEval(x);
		return;
	}
	double tmp1=Y(1,x),tmp2=Y(2,x);
	if(this->Problem>=1&&this->Problem<=18){

		if(this->Problem==12){	
			c[0]=2*tmp1+3*tmp2-9;
			if((0<=tmp1&&tmp1<=1&&2<=tmp2&&tmp2<=3)||(2<=tmp1&&tmp1<=3)){
				c[1]=-1;
			}else
				c[1]=1;

		}
		else if(this->Problem==13){
			c[0]=2*tmp1+3*tmp2-9;
		}
		else if(this->Problem==14){
			c[0]=2*tmp1+3*tmp2-9;
			if((0<=tmp1&&tmp1<=1)||(2<=tmp1&&tmp1<=3)){
				c[1]=-1;
			}else
				c[1]=1;
		}
		else if(this->Problem==15){
			/*if((0<=tmp1&&tmp1<=0.5)||(2.5<=tmp1&&tmp1<=3.0)){
			c[0]=-1;
			}else
			c[0]=1;
			if((0<=tmp1&&tmp1<=1&&2<=tmp2&&tmp2<=3)||(2<=tmp1&&tmp1<=3)){
			c[1]=-1;
			}else
			c[1]=1;*/

			if((0<=tmp1&&tmp1<=0.5)||(2.5<=tmp1&&tmp1<=3.0))
			{
				c[0]=-1;
			}else
				c[0]=1;
			/*if((0<=tmp1&&tmp1<=1&&2<=tmp2&&tmp2<=3)||(2<=tmp1&&tmp1<=3)){
			c[1]=-1;
			}else
			c[1]=1;*/
			c[1]=2*tmp1+3*tmp2-9;

		}
		else if(this->Problem==1||this->Problem==4||this->Problem==6||this->Problem==17){
			cout<<"The problem does not has a constraint!\n";
			//system("pause");
			//	exit(0);

		}else{
			c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
			c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;
		}
	}
	else if(this->Problem>=3001&&this->Problem<=8003&&this->Problem%1000==1){//(this->Problem==3003||this->Problem==4003||this->Problem==5003||this->Problem==7003){
		c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
		c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;		
		c[2]=val_1-tmp2;
	}
	else if(this->Problem>=3001&&this->Problem<=8003&&this->Problem%1000==3){//(this->Problem==3003||this->Problem==4003||this->Problem==5003||this->Problem==7003){
		double val[3][2]={{m1,(n1-val_1)},{m2,(n2-val_2)},{m3,(n3-val_3)}};		
		c[0]=-2*pow(tmp1,4)+8*pow(tmp1,3)-8*pow(tmp1,2)+tmp2-2;
		c[1]=-4*pow(tmp1,4)+32*pow(tmp1,3)-88*pow(tmp1,2)+96*tmp1+tmp2-36;
		c[2]=(val[1][1]-val[0][1])/(val[1][0]-val[0][0])*(tmp1-val[0][0])+val[0][1]-tmp2;
		c[3]=(val[1][1]-val[2][1])/(val[1][0]-val[2][0])*(tmp1-val[2][0])+val[2][1]-tmp2;		
	}
}
void ModelInfo::ConstraintViolation(double *x, double *c, double *v, double &SumVio, double &MaxVio, bool &feasible){
	if(this->n_con>0){
		feasible=true;
		int i=0;
		double e;
		MaxVio=SumVio=0.0;
		for(;i<this->Inequalities;i++){
			v[i]=0.0;
			if(c[i]>0.0){
				v[i]=c[i];
				if(c[i]>MaxVio)MaxVio=c[i];
				SumVio+=v[i];
				//feasible=false;
			}
		}
		for(; i<this->n_con; i++) {
			e=(c[i]>=0? c[i] : -c[i]);
			if(e>MaxVio) MaxVio=e;
			if(e>Delta) {
				SumVio+=(e-Delta);
			}
		}

		if(SumVio>0.0)
			feasible=false;


		//MaxVio=v[0];
		//SumVio=0.0;
		/*for(int i=0;i<n_con;i++){
		if(v[i]>MaxVio)MaxVio=v[i];
		SumVio+=v[i];
		}*/

	}else{
		cout<<"The problem does not has a constraint!\n";

		system("pause");
		exit(0);
	}
}
double ModelInfo::p_i(int index){	
	if(this->Problem<=2){
		if(index==1){
			return sin((double)this->k*pi*(double)this->changeStep+pi/2);
		}
		else{			
			return 1.0;
		}
	}
	else if(this->Problem==3||this->Problem==4||this->Problem==7||this->Problem==9||this->Problem==16){
		return 1.0;
	}
	else if(this->Problem==3001||this->Problem==3003||this->Problem==7001||this->Problem==7003){
		return 1.0;
	}
	else if(this->Problem==5||this->Problem==6||this->Problem==11||this->Problem==5001||this->Problem==5003){
		if(this->changeStep%2==0){
			if(index==1)
				return sin((double)this->k*pi*(double)this->changeStep/2+pi/2);
			else{
				if(this->changeStep==0)
					return 0.0;
				else
					return sin((double)this->k*pi*((double)this->changeStep-2)/2+pi/2);
			}
		}
		else{
			if(index==1)
				return sin((double)this->k*pi*(double)(this->changeStep-1)/2+pi/2);//-1
			else
				return sin((double)this->k*pi*((double)this->changeStep-1)/2+pi/2);
		}
	}
	else if(this->Problem==8||this->Problem==10||this->Problem==4001||this->Problem==4003||this->Problem==8001||this->Problem==8003){
		if(index==1)
			return sin((double)this->k*pi*(double)this->changeStep+pi/2);
		else
			return 1.0;
	}
	else if(this->Problem>=12&&this->Problem<=15){
		/*if(this->Problem==15&&index==1)
		return sin(this->k*pi*(double)this->changeStep+pi/2);;*/
		if(index==1)
			return sin(pi*(double)this->changeStep+pi/2);
		else
			return 1.0;
	}else if(this->Problem==17||this->Problem==18)
		return -1.0;
	else if(this->Problem==19){
		return 1;
	}
	else if(this->Problem==21||this->Problem==22){
		return 1.0;
	}
	else{
		/*cout<<"wrong problem number!\n";
		system("pause");
		exit(0);*/
#ifdef TestStaticObj
		return 1.0;
#endif
#ifdef TestDynamicObj1
		if(index==1)
			return sin((double)this->k*pi*(double)this->changeStep+pi/2);
		else
			return 1.0;
#endif
#ifdef TestDynamicObj2
		if(this->changeStep%2==0){
			if(index==1)
				return sin((double)this->k*pi*(double)this->changeStep/2+pi/2);
			else{
				if(this->changeStep==0)
					return 0.0;
				else
					return sin((double)this->k*pi*((double)this->changeStep-2)/2+pi/2);
			}
		}
		else{
			if(index==1)
				return sin((double)this->k*pi*(double)(this->changeStep-1)/2+pi/2);//-1
			else
				return sin((double)this->k*pi*((double)this->changeStep-1)/2+pi/2);
		}
#endif
	}
}
double ModelInfo::q_i(int index){
	if(this->Problem==4)
		return 1.0;
	else if(this->Problem==17||this->Problem==18){
		if(index==1)
			return -1*(c1+ra*cos((double)this->k*pi*(double)this->changeStep));
		else
			return -1*(c2+ra*sin(k*pi*(double)this->changeStep));
	}
	else if(this->Problem==19){
		return 0.0;
	}
	else if(this->Problem==22){
		return -(double)((double)this->changeStep*(LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->k;
	}
	else
		return 0.0;
}
double ModelInfo::r_i(int index){
	return 1.0;
}
double ModelInfo::s_i(int index){
	if(this->Problem==7||this->Problem==8||this->Problem==3001||this->Problem==3003||this->Problem==8001||this->Problem==8003){
		if(index==1)return 0.0;
		else 
			return 2.0-(double)((double)this->changeStep*(LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S;

	}
	//cyclic change
	else if(this->Problem==3010){
		if(index==1)return 0.0;
		else
			return (double)((LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S*sin(w*(double)this->changeStep);
	}
	//cyclic change
	else if(this->Problem==3011){
		if(index==1)return 0.0;
		else
			return 2-(double)((LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S*sin(w*(double)this->changeStep);
	}
	//decay oscilation change
	else if(this->Problem==3020){
		if(index==1)return 0.0;
		else
			return (double)((LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S*exp(-0.1*(double)this->changeStep*sin(w*(double)this->changeStep));
	}
	else if(this->Problem==3021){
		if(index==1)return 0.0;
		else
			return 2.0-(double)((LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S*exp(-0.1*(double)this->changeStep*sin(w*(double)this->changeStep));
	}

	else if(this->Problem==9){
		if(index==1)return 0.0;
		else return 2.0;
	}
	else if(this->Problem==10||this->Problem==11||this->Problem==16||this->Problem==4001||this->Problem==4003||this->Problem==5001||this->Problem==5003||this->Problem==7001||this->Problem==7003){
		if(index==1)return 0.0;
		else
			return (double)((double)this->changeStep*(LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S;
	}else if(this->Problem==19){
		return -1.0*((double)this->changeStep*(LUv[(index-1)*2+1]-LUv[2*(index-1)])/(double)this->S);
	}
	else if(this->Problem==21||this->Problem==22){
		return -(double)((double)this->changeStep*(LUv[(index-1)*2+1]-LUv[2*(index-1)]))/(double)this->S;
	}
	else
		return 0.0;
}
void ModelInfo::SetLUv(){
	if(this->Problem==101){
		double tmp=sin((double)this->k*pi*(double)this->changeStep/2.0);
		for(int i=0;i<9;i++){
			LUv[i*2]=-tmp;
			LUv[i*2+1]=1+tmp;
			//this->maxVelocity[i]=0.5*(LUv[2*i+1]-LUv[2*i]);
			this->maxVelocity[i]=LUv[i*2+1];
			minVelocity[i]=LUv[i*2];
		}
		for(int i=9;i<12;i++){
			LUv[i*2]=-tmp;
			LUv[i*2+1]=100+tmp;
			this->maxVelocity[i]=LUv[i*2+1];
			minVelocity[i]=LUv[i*2];
			//this->maxVelocity[i]=0.5*(LUv[2*i+1]-LUv[2*i]);
		}
		LUv[12*2]=-tmp;
		LUv[12*2+1]=1+tmp;
		this->maxVelocity[12*2+1]=tmp;
		minVelocity[12*2]=-tmp;
		//this->maxVelocity[12]=0.5*(LUv[2*12+1]-LUv[2*12]);
	}
	else if((this->Problem>=1&&this->Problem<=18)||(this->Problem<=8003&&this->Problem>=3001)){
		LUv[0]=0.0;
		LUv[1]=3.0;
		LUv[2]=0.0;
		LUv[3]=4.0;
		maxVelocity[0]=3;maxVelocity[1]=4.0;
		minVelocity[0]=-3.0;minVelocity[1]=-4.0;
		//maxVelocity[0]=0.5*(LUv[1]-LUv[0]);
		//maxVelocity[1]=0.5*(LUv[3]-LUv[2]);
	}
	else if(this->Problem==21||this->Problem==22){
		for(int i=0;i<this->n_var;i++){
			this->LUv[2*i]=0.0;
			this->LUv[2*i+1]=10.0;
			this->maxVelocity[i]=LUv[i*2+1];
			minVelocity[i]=LUv[i*2];
			//this->maxVelocity[i]=0.5*(LUv[2*i+1]-LUv[2*i]);
		}

	}
	else if(this->Problem>=10000){
		for(int i=0;i<this->n_var;i++){
			this->LUv[i*2]=0;
			this->LUv[i*2+1]=100;
			this->maxVelocity[i]=LUv[i*2+1];
			minVelocity[i]=LUv[i*2];
			//this->maxVelocity[i]=0.5*(LUv[2*i+1]-LUv[2*i]);
		}
	}
	if(this->maxNumVar!=this->n_var){
		for(int i=this->n_var*2;i<this->maxNumVar*2;i++){
			this->LUv[i]=0.0;
			this->maxVelocity[i]=0.0;
			minVelocity[i]=0.0;
		}
	}
}
//ThanhNT added 08 July 09
//We need to define the following method to update whether the landscape has one/two or three 
//disconnected feasible regions.
//- this will be called after every change and at the initial stage. 
void ModelInfo::updateSegmentPivotPoints()
{
	if(!((this->Problem>=1&&this->Problem<=18)||(this->Problem>=3001&&this->Problem<=8003))){
		this->_disconnectedFeasibleRegionsNum=this->mfrb->getNumberOfDisconnectedFeasibleRegions();
		if(this->changeStep < this->getMaxStep()){
			TotalNumOfRegions+=_disconnectedFeasibleRegionsNum;
		}
		return;
	}	
#ifdef ProInfo
	this->ofProInfo<<"Period:  "<<this->changeStep<<endl;
#endif
	int size=_segmentPivotPoints.size();
	double pivotPoint[2];
	pivotPoint[1]=0.0001; //the y coord is always 0 in the case of G24
	//ThanhNT added 24 Aug 09
	//we also need to update the variable _disconnectedFeasibleRegionsNum
	_disconnectedFeasibleRegionsNum=1;//the problem always has at least one feasible region
	//end of ThanhNT
	for (int i=1;i<size-1;i++) //we exclude the two end points because they are the search boundary
	{
		pivotPoint[0]=_segmentPivotPoints[i].first;

		if (this->dummyIsFeasible(pivotPoint)){
			_segmentPivotPoints[i].second=false; //disable this pivot point because it does not separate the landscape into disconnected regions
#ifdef ProInfo
			this->ofProInfo<<_segmentPivotPoints[i].first<<" --> NO \n";
#endif
		}
		else
		{
			_segmentPivotPoints[i].second=true; //enable this pivot point because it does separate the landscape into disconnected regions
#ifdef ProInfo
			this->ofProInfo<<_segmentPivotPoints[i].first<<" --> YES \n";
#endif
			//ThanhNT added 24 Aug 09 - If the pivot point belong to the line separate the landscape into disconnected region,
			//increase the counter
			_disconnectedFeasibleRegionsNum++;
			//end of ThanhNT
		}
	}	
#ifdef ProInfo
	//ThanhNT added 24 Aug 09 for testing only
	this->ofProInfo<<"Number of feasible regions: "<<_disconnectedFeasibleRegionsNum<<"\n";
	//end of ThanhNT
#endif
	if(this->changeStep < this->getMaxStep()){
		TotalNumOfRegions+=_disconnectedFeasibleRegionsNum;
	}

}; 

void ModelInfo::updateBest(double fitness, bool isfea, double * loc, double vio){
	////update the best point if the individual is feasible
	//if(this->is_feasible()&&(this->m_pModel->fea_bestPoint==false||fitness<this->m_pModel->fit_bestPoint)){				
	//	this->m_pModel->updateBest(fitness,true,x,0.0);
	//}
	////update the best point if both the individual and the current best are infeasible
	//else if(this->is_feasible()==false&&this->m_pModel->fea_bestPoint==false&&SumVio<this->m_pModel->Sumvio_bestPoint){		
	//	this->m_pModel->updateBest(fitness,false,x,this->SumVio);
	//	

	if(isfea && (this->fea_bestPoint==false || fitness < this->fit_bestPoint)){
		this->fit_bestPoint=fitness;
		this->fea_bestPoint=isfea;
		this->tempGen_bestPoint=this->gen;
		this->tempNEval_bestPoint=this->NEval;
		this->tempNConst_bestPoint=this->NConst;
		this->Sumvio_bestPoint=vio;
		for(int i=0;i<this->n_var;i++){
			this->loc_bestPoint[i]=loc[i];
		}
	}else if(!isfea && this->fea_bestPoint==false && vio < this->Sumvio_bestPoint){
		this->fit_bestPoint=this->getInfty();
		this->fea_bestPoint=isfea;
		this->tempGen_bestPoint=this->gen;
		this->tempNEval_bestPoint=this->NEval;
		this->tempNConst_bestPoint=this->NConst;
		this->Sumvio_bestPoint=vio;
		for(int i=0;i<this->n_var;i++){
			this->loc_bestPoint[i]=loc[i];
		}
	}
}
void ModelInfo::setOfflineError(){
	if(this->gen_in_a_period==0){
		if(this->fea_bestPoint)
			this->bestFitPerPeriod=this->fit_bestPoint;
		else{
			if(this->Problem>=10000)
				this->bestFitPerPeriod=0.0;
			else 
				this->bestFitPerPeriod=2.5;
		}
	}	

	this->gen_in_a_period++;
	if(this->fea_bestPoint){
		this->ARR+=fabs(this->globalValue-this->bestFitPerPeriod);
	}else{
		//this->ARR+=fabs(0-this->bestFitPerPeriod);
	}

	if(this->Problem>=10000){
		if(this->fea_bestPoint&&this->fit_bestPoint<=this->getBestFitInActual())//this->fea_bestPoint&&this->fit_bestPoint<=this->getBestFitInActual()
			this->offline_error+=0.0;
		else if(this->fea_bestPoint)
			this->offline_error+=fabs(this->globalValue-this->fit_bestPoint);
		else
			this->offline_error+=fabs(this->globalValue);
		return;
	}
	else {
		if(this->fea_bestPoint&&this->fit_bestPoint<=this->getBestFitInActual())//this->fea_bestPoint&&this->fit_bestPoint<=this->getBestFitInActual()
			this->offline_error+=0.0;
		else if(this->fea_bestPoint)
			this->offline_error+=fabs(this->globalValue-this->fit_bestPoint);
		else
			this->offline_error+=2.5;
		return;
	}


}

void ModelInfo::testOutput(){
#ifdef OutputInfomationPerChange
	ofstream outfile;
	outfile.open(this->output,ofstream::out|ofstream::app);
	if(!outfile){
		outfile<<"cannot open the outfile!"<<endl;
		system("pasue");
		exit(0);

	}
	outfile.precision(32);
	outfile<<"\nChange  "<<this->changeStep<<endl;
	outfile<<"bestPoint:  fitness"<<this->fit_bestPoint<<"  is_feasible:  "<<this->fea_bestPoint<<endl<<"NEval:  "<<this->tempNEval_bestPoint<<" gen: "<<this->tempGen_bestPoint<<" NConst:"<<this->tempNConst_bestPoint<<endl;
	outfile<<"location:  ";
	for(int i=0;i<this->n_var;i++){
		outfile<<this->loc_bestPoint[i]<<"  ";
	}	
	
	outfile<<"the offline error:  "<<this->offline_error<<endl;
	
	outfile<<"NConst in the end of the period:  "<<this->NConst<<endl;
	outfile<<"gen in the end of the period:  "<<this->gen<<endl;

	outfile<<"tracking error: "<<this->trackingError/(double)this->changeStep<<endl;
	outfile<<"best error: "<<this->bestError/(double)this->changeStep<<endl;
	outfile<<"ARR: "<<this->ARR<<endl;
	outfile<<"tracking speed (global region): "<<this->trackingSpeed_globalRegion/this->changeStep<<endl;	
	if((this->Problem>=3001&&this->Problem<=8003)||(this->Problem>=1&&this->Problem<=18)||this->Problem>=10000){
		outfile<<"global solution: ";
		for(int i=0;i<this->n_var;i++){
			outfile<<this->globalOptimum[i]<<"  ";
		}
		outfile<<"global value: "<<this->globalValue<<endl;		
	}
	if(this->Problem>=10000){
		outfile<<"delta_t: "<<this->delta_t<<endl;
		outfile<<"regions:\n";
		this->mfrb->printPeaks(outfile);
		outfile<<"Region radius:\n";
		outfile<<this->mfrb->getRegionRadius();
		outfile<<"peaks:\n";
		this->mpb->printPeaks(outfile);

		outfile<<"global region: "<<this->mfrb->getGlobalRegion()<<endl;
		outfile<<"distance to the region center: "<<this->calculateDis(this->globalOptimum,const_cast<double*> (this->mfrb->getPeak(this->mfrb->getGlobalRegion())))<<endl;
		
	}
	outfile.close();
#endif
#ifdef ProInfo
	//
	this->ofProInfo.precision(32);
	this->ofProInfo<<"time: "<<this->changeStep<<endl;
	ofProInfo<<"global solution: ";
	for(int i=0;i<this->n_var;i++){
		ofProInfo<<this->globalOptimum[i]<<"  ";
	}
	ofProInfo<<"global optimum value: "<<this->globalValue<<endl;
	
	if(this->Problem>=10000){
		ofProInfo<<"delta(t): "<<this->delta_t<<endl;
		ofProInfo<<"regions:\n";
		this->mfrb->printPeaks(ofProInfo);		
		ofProInfo<<"region radius:\n";
		ofProInfo<<this->mfrb->getRegionRadius();
		ofProInfo<<"peaks:\n";
		this->mpb->printPeaks(ofProInfo);
		ofProInfo<<"optimal region index (start from 0): "<<this->mfrb->getGlobalRegion()<<endl;
		ofProInfo<<"number of disconnected feasible regions: "<<this->_disconnectedFeasibleRegionsNum<<endl<<endl;
	}
#endif
}
void ModelInfo::updateMeasure(){
	//update best error
	if(this->fea_bestPoint==true){
		if(this->globalValue>fit_bestPoint)
			this->bestError+=0.0;
		else
			this->bestError+=fabs(this->globalValue-this->fit_bestPoint);
	}
	else{
		if(this->Problem>=10000)
			this->bestError+=fabs(this->globalValue-0.0);
		else
			this->bestError+=fabs(this->globalValue-2.5);
	}
	//update tracking error
	if(this->fea_bestPoint==true){
		if(this->globalValue>fit_bestPoint)
			this->trackingError+=0.0;
		else
			this->trackingError+=fabs((this->globalValue-this->fit_bestPoint)/this->globalValue);
	}
	else
		this->trackingError+=1.0;
	//update mean minimum distance to the global optimum		
	this->meanDis+=this->calculateDis(this->globalOptimum,this->loc_bestPoint);
	//update ARR
	this->ARR=this->ARR/fabs((this->globalValue-this->bestFitPerPeriod))/(double)this->gen_in_a_period;
	this->ARR_all+=this->ARR;		

	this->RegionCover+=this->peak_found;
	this->peak_found=0;

	int testNum=0;
	for(int i=0;i<this->_disconnectedFeasibleRegionsNum;i++){
		if(this->numALSInEachRegion[i]>0){
			this->NumCoverALS++;
			testNum++;

		}
	}
	
	if(this->NEval == (this->getMaxStep()*this->NEvalEveryPeroid)){
		//this->offline_error=this->offline_error/(double)this->gen;
		this->bestError=this->bestError/(double)this->changeStep;
		this->trackingError=this->trackingError/(double)this->changeStep;
		this->meanDis/=(double)this->changeStep;
		this->ARR_all/=(double)this->changeStep;
		this->RegionCover/=(double)this->TotalNumOfRegions;
		trackingSpeed_globalRegion/=(double)this->changeStep;


		//return;
	}
	testOutput();
}
void ModelInfo::resetParameters(){
	//reset the best point
	if(this->n_con>0){
		if(this->Problem!=3&&this->Problem!=4&&this->Problem!=9){
			this->fea_bestPoint=false;
		}
	}
	else{
		this->fea_bestPoint=true;			
	}		
#ifdef G24
	if(this->Problem!=3&&this->Problem!=4&&this->Problem!=9){
		this->fit_bestPoint=2.5;//this->getInfty();			
	}
#else
	this->fit_bestPoint=0;
#endif
	this->Sumvio_bestPoint=this->getInfty();

	for(int i=0;i<numALSInEachRegion.size();i++){
		this->numALSInEachRegion[i]=0;
	}


	this->informedChange=true;	
	this->has_change=true;
	this->gen_in_a_period=0;
	this->bestFitPerPeriod=0;
	this->found_globalRegion=false;
	this->ARR=0.;
	//the dimensions could vary with time
	this->updateNumVar();	
#ifndef G24
	for(int i=0;i<this->mfrb->getNumberofPeak();i++)
		this->numIndEachRegion[i]=0;
#endif

}